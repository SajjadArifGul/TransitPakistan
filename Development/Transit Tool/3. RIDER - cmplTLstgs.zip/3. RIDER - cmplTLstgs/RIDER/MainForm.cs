﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace RIDER
{
    public partial class MainForm : Form
    {
        Vehicles vehicles; //Object of Vehicle Class
        Locations locations; //Object of Locations Class
        XMLHandler xmlHandler; //object of XMLHandler class
        Filer filer; //Object of Filer class
        Settings settings;  //Object of Settings class
        ArrayList globaldetails;

        public MainForm()
        {
            InitializeComponent();

            _InitilizeVariables();
        }

        private void _InitilizeVariables()
        {
            vehicles = new Vehicles();
            locations = new Locations();
            xmlHandler = new XMLHandler();
            filer = new Filer();
            settings = new Settings();
            globaldetails = new ArrayList();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            //method for Loading data in comoboboxes
            LoadComboBoxes();
        }

        //Load data in Comoboxes
        public void LoadComboBoxes()
        {
            //First clear all items in combo boxes if there are any.
            VehicleTypeComboBox.Items.Clear();
            StartPointNameComboBox.Items.Clear();
            EndPointNameComboBox.Items.Clear();
            DeleteVehicleTypeCBox.Items.Clear();
            AddNewVehicleVehicleTypeCBox.Items.Clear();
            DeleteVehicleVehicleTypeCBox.Items.Clear();
            UpdateLocNameCBox.Items.Clear();
            DeleteLocNameCBox.Items.Clear();

            //Add Data in Vehicle Type Comobobox
            VehicleTypeComboBox.Items.AddRange(vehicles.GetVehicleTypes());

            //Creating an array of Location Name.
            //Not doing it directly in comoboboxes because that would take extra iterations
            string[] LocationsArray = locations.GetLocationNames();

            //StartPoints Combobox Populating
            StartPointNameComboBox.Items.AddRange(LocationsArray);

            //BusStops Combobox Populating
            BusStopComboBox.Items.AddRange(LocationsArray);

            //EndPoints Combobox Populating
            EndPointNameComboBox.Items.AddRange(LocationsArray);

            DeleteVehicleTypeCBox.Items.AddRange(vehicles.GetVehicleTypes());
            AddNewVehicleVehicleTypeCBox.Items.AddRange(vehicles.GetVehicleTypes());
            DeleteVehicleVehicleTypeCBox.Items.AddRange(vehicles.GetVehicleTypes());

            UpdateLocNameCBox.Items.AddRange(locations.GetLocationNames());
            DeleteLocNameCBox.Items.AddRange(locations.GetLocationNames());

            UpdateFileJoinBox.Text = settings.GetFileJoin();
            UpdateFileExtensionBox.Text = settings.GetFileExtension();
            UpdateRootFolderBox.Text = settings.GetRootFolder();
        }

        //This method will be used to send back statuses according to its severity
        public void Status(string Message, int Severity)
        {
            //Severity should be from between 1-5
            //1-Success 2-Warning 3-Error 4-Remember 5-Important
            //tailor the message box according to severity

            MessageBox.Show(Message);
        }

        //To scroll down the routes richbox when new text added.
        public void ScrollDown()
        {
            RoutesRichBox.ScrollToCaret();
        }

        private void addNewVehicleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Tabs.SelectedTab = VehiclesTab;
        }

        private void addNewVehicleTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Tabs.SelectedTab = VehiclesTab;
        }

        private void addNewLocationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Tabs.SelectedTab = LocationsTab;
        }

        private void deleteVehicleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Tabs.SelectedTab = VehiclesTab;
        }

        private void deleteVehicleTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Tabs.SelectedTab = VehiclesTab;
        }

        private void deleteLocationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Tabs.SelectedTab = LocationsTab;
        }

        private void setFileJoinToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Tabs.SelectedTab = SettingsTab;
        }

        private void setFileExtensionToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Tabs.SelectedTab = SettingsTab;
        }

        private void setRootFolderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Tabs.SelectedTab = SettingsTab;
        }

        //vehicle type comobobox value is changed so change the value
        //in vehicle name combox according to it & add text to routes rich box.
        private void VehicleTypeComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Clear if already populated data from Vehicle Name comobobox
            VehicleNameComboBox.Items.Clear();

            //Populate Vehicle Name comobobox with new selected vehicle type
            VehicleNameComboBox.Items.AddRange(vehicles.GetVehiclesByTypeName(VehicleTypeComboBox.Text));

            try
            {
                //Now Select a new first value by default becuase the previous vehicle type name is selected in combobox
                VehicleNameComboBox.SelectedIndex = 0;
            }
            catch
            {
                //This means there are no vehicles added to this vehcicle type in Database
                Status("No vehicle data available for " + VehicleTypeComboBox.SelectedItem.ToString() + ".", 3);
            }

            RoutesRichBox.Text = xmlHandler.SetVehicleType(RoutesRichBox.Text, VehicleTypeComboBox.SelectedItem.ToString());
            ScrollDown();
        }

        //vehicle name box value is changed so add/change it in the routesrichbox
        private void VehicleNameComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            RoutesRichBox.Text = xmlHandler.SetVehicleName(RoutesRichBox.Text, VehicleNameComboBox.SelectedItem.ToString());
            ScrollDown();
        }

        //start point name changed. add new co-ordinates to start point co-ordinates boxes
        private void StartPointNameComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            decimal StartPointLatitude, StartPointLongitude;

            locations.GetCoordinates(StartPointNameComboBox.Text, out StartPointLatitude, out StartPointLongitude);

            StartPointLatBox.Text = StartPointLatitude.ToString();
            StartPointLongBox.Text = StartPointLongitude.ToString();
        }
        //Add start point info in routes richbox
        private void AddStartPointBtn_Click(object sender, EventArgs e)
        {
            RoutesRichBox.Text = xmlHandler.SetStartPoint(RoutesRichBox.Text, StartPointNameComboBox.SelectedItem.ToString(), StartPointLatBox.Text, StartPointLongBox.Text);
        }

        //end point name changed. add new co-ordinates to end point co-ordinates boxes
        private void BusStopComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            decimal BusStopLatitude, BusStopLongitude;

            locations.GetCoordinates(BusStopComboBox.Text, out BusStopLatitude, out BusStopLongitude);

            BusStopLatitudeBox.Text = BusStopLatitude.ToString();
            BusStopLongitudeBox.Text = BusStopLongitude.ToString();
        }
        //add bus stop info in routes rich box
        private void AddBusStopBtn_Click(object sender, EventArgs e)
        {
            //this variable is taken separately because we need to scroll down
            //the route rich box. Which doesnt work without AppenText method.
            //So i took this separetely, then empty the rich box & send this value to our bus stop method.
            string RichTextBoxText = RoutesRichBox.Text;
            RoutesRichBox.Text = null;
            RoutesRichBox.AppendText(xmlHandler.SetBusStop(RichTextBoxText, BusStopComboBox.SelectedItem.ToString(), BusStopLatitudeBox.Text, BusStopLongitudeBox.Text));
            ScrollDown();
        }

        //end point name changed. add new co-ordinates to start point co-ordinates boxes
        private void EndPointNameComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            decimal EndPointLatitude, EndPointLongitude;

            locations.GetCoordinates(EndPointNameComboBox.Text, out EndPointLatitude, out EndPointLongitude);

            EndPointLatBox.Text = EndPointLatitude.ToString();
            EndPointLongBox.Text = EndPointLongitude.ToString();
        }
        //add end point info in routes richbox
        private void AddEndPointBtn_Click(object sender, EventArgs e)
        {
            //this variable is taken separately because we need to scroll down
            //the route rich box. Which doesnt work without AppendText method.
            //So i took this separetely, then empty the rich box & send this value to our bus stop method.
            string RichTextBoxText = RoutesRichBox.Text;
            RoutesRichBox.Text = null;
            RoutesRichBox.AppendText(xmlHandler.SetEndPoint(RichTextBoxText, EndPointNameComboBox.SelectedItem.ToString(), EndPointLatBox.Text, EndPointLongBox.Text));
            ScrollDown();
        }

        private void FormatXMLBtn_Click(object sender, EventArgs e)
        {
            try
            {
                RoutesRichBox.Text = xmlHandler.IdentateXML(xmlHandler.FormatVehicleXML(RoutesRichBox.Text));
            }
            catch (Exception ee)
            {
                Status(ee.Message, 3);
            }
        }

        private void GenerateVehicleXMLBtn_Click(object sender, EventArgs e)
        {
            try
            {
                filer.CreateVehicleFile(RoutesRichBox.Text, xmlHandler.GetVehicleName(RoutesRichBox.Text), settings.GetFileExtension());
            }
            catch (Exception ee)
            {
                Status(ee.Message, 3);
            }
        }

        private void GenerateRoutesXMLBtn_Click(object sender, EventArgs e)
        {
            FilesGridView.Rows.Clear();

            Tabs.SelectedTab = RoutesTab;

            string VehicleType = xmlHandler.GetVehicleType(RoutesRichBox.Text);
            string VehicleName = xmlHandler.GetVehicleName(RoutesRichBox.Text);

            RouteGenerator.RunWorkerAsync(new Details() { VehicleType = VehicleType, VehicleName = VehicleName });
        }

        private void FilesGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                if (FilesGridView.Columns[e.ColumnIndex].Name == "RouteDataColumn")
                {
                    Status(FilesGridView.Rows[e.RowIndex].Cells["RouteDataColumn"].Value.ToString(), 1);
                }
                else if (FilesGridView.Columns[e.ColumnIndex].Name == "StatusColumn")
                {
                    //Status(FilesGridView.Rows[e.RowIndex].Cells["RouteDataColumn"].Value.ToString(), 1);

                    BackgroundWorker RouteFileCreator = new BackgroundWorker();
                    RouteFileCreator.DoWork += new DoWorkEventHandler(RouteFileCreator_DoWork);
                    RouteFileCreator.RunWorkerCompleted += (RouteFileCreator_RunWorkerCompleted);
                    RouteFileCreator.RunWorkerAsync(new Details() { RowNumber = e.RowIndex, VehicleName = xmlHandler.GetVehicleName(FilesGridView.Rows[e.RowIndex].Cells["RouteDataColumn"].Value.ToString()), Content = FilesGridView.Rows[e.RowIndex].Cells["RouteDataColumn"].Value.ToString(), StartPoint = FilesGridView.Rows[e.RowIndex].Cells["StartPointColumn"].Value.ToString(), EndPoint = FilesGridView.Rows[e.RowIndex].Cells["EndPointColumn"].Value.ToString(), RootFolder = settings.GetRootFolder(), Join = settings.GetFileJoin(), Extension = settings.GetFileExtension() });
                }
            }
        }

        private void RouteGenerator_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            Details details = (Details)e.Argument;

            string VehicleType = details.VehicleType;
            string VehicleName = details.VehicleName;

            e.Result = xmlHandler.GenerateRoutes(RoutesRichBox.Lines, VehicleType, VehicleName);
        }

        private void RouteGenerator_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                // handle the error

                Status(e.Error.Message + e.Error.StackTrace, 1);
            }
            else if (e.Cancelled)
            {
                // handle cancellation
            }
            else
            {
                ArrayList DataList = (ArrayList)e.Result;

                RouteCombinationsLabel.Text = DataList.Count.ToString();

                foreach (Details details in DataList)
                {
                    FilesGridView.Rows.Add(true, details.StartPoint, details.EndPoint, details.Content);
                }
            }
        }

        private void StartCreatingFilesButton_Click(object sender, EventArgs e)
        {
            RoutesIterator.RunWorkerAsync();
        }

        private void RoutesIterator_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            foreach (DataGridViewRow Row in FilesGridView.Rows)
            {
                if (Convert.ToBoolean(FilesGridView.Rows[Row.Index].Cells["SelectAllColumn"].Value))
                {
                    BackgroundWorker RouteFileCreator = new BackgroundWorker();
                    RouteFileCreator.DoWork += new DoWorkEventHandler(RouteFileCreator_DoWork);
                    RouteFileCreator.RunWorkerCompleted += (RouteFileCreator_RunWorkerCompleted);
                    RouteFileCreator.RunWorkerAsync(new Details() { RowNumber = Row.Index, VehicleName = xmlHandler.GetVehicleName(Row.Cells["RouteDataColumn"].Value.ToString()), Content = Row.Cells["RouteDataColumn"].Value.ToString(), StartPoint = Row.Cells["StartPointColumn"].Value.ToString(), EndPoint = Row.Cells["EndPointColumn"].Value.ToString(), RootFolder = settings.GetRootFolder(), Join = settings.GetFileJoin(), Extension = settings.GetFileExtension() });
                }
            }
        }

        private void RouteFileCreator_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            Details details = (Details)e.Argument;

            e.Result = (new Details() { FileCreatedStatus = filer.CreateRouteFile(details.VehicleName, details.Content, details.StartPoint, details.EndPoint, details.RootFolder, details.Join, details.Extension), RowNumber = details.RowNumber });
        }

        private void RouteFileCreator_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                // handle the error

                Status(e.Error.Message + e.Error.StackTrace, 1);
            }
            else if (e.Cancelled)
            {
                // handle cancellation
            }
            else
            {
                Details details = (Details)e.Result;

                FilesGridView.Rows[details.RowNumber].Cells["StatusColumn"].Value = details.FileCreatedStatus;

                if (details.FileCreatedStatus == "Not Created")
                {
                    FilesGridView.Rows[details.RowNumber].DefaultCellStyle.BackColor = Color.Red;
                }
                else if ((details.FileCreatedStatus == "Created") || (details.FileCreatedStatus == "Merged"))
                {
                    if (FilesGridView.Rows[details.RowNumber].DefaultCellStyle.BackColor == Color.Red)
                    {
                        FilesGridView.Rows[details.RowNumber].DefaultCellStyle.BackColor = Color.FromArgb(76, 175, 80);
                    }
                }
            }
        }

        private void RoutesIterator_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                // handle the error

                Status(e.Error.Message + e.Error.StackTrace, 1);
            }
            else if (e.Cancelled)
            {
                // handle cancellation
            }
        }

        private void AddSelectedVehicleTypeBtn_Click(object sender, EventArgs e)
        {
            if (vehicles.AddNewVehicleType(AddVehicleTypeBox.Text))
            {
                Status("Vehicle Type Added to Database.", 1);

                _InitilizeVariables();
                LoadComboBoxes();
            }
        }

        private void DeleteSelectedVehicleTypeBtn_Click(object sender, EventArgs e)
        {
            if (vehicles.DeleteVehicleType(DeleteVehicleTypeCBox.SelectedItem.ToString()))
            {
                Status("Vehicle Type Deleted from Database.", 1);

                _InitilizeVariables();
                LoadComboBoxes();
            }
        }

        private void AddNewVehicleBtn_Click(object sender, EventArgs e)
        {
            if (vehicles.AddNewVehicle(AddNewVehicleNameBox.Text, vehicles.GetVehicleTypeID(AddNewVehicleVehicleTypeCBox.SelectedItem.ToString()), AddNewVehicleStartPointBox.Text, AddNewVehicleEndPointBox.Text))
            {
                Status("New Vehicle added to Database.", 1);

                _InitilizeVariables();
                LoadComboBoxes();
            }
        }

        private void DeleteVehicleVehicleTypeCBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            DeleteVehicleNameCBox.Items.AddRange(vehicles.GetVehiclesByTypeName(DeleteVehicleVehicleTypeCBox.SelectedItem.ToString()));
        }

        private void DeleteSelectedVehicleBtn_Click(object sender, EventArgs e)
        {
            if (vehicles.DeleteVehicle(vehicles.GetVehicleTypeID(DeleteVehicleVehicleTypeCBox.SelectedItem.ToString()), DeleteVehicleNameCBox.SelectedItem.ToString()))
            {
                Status("Selected Vehicle deleted from Database.", 1);

                _InitilizeVariables();
                LoadComboBoxes();
            }
        }

        private void AddNewLocBtn_Click(object sender, EventArgs e)
        {
            if (locations.AddNewLocation(AddLocNameBox.Text, Convert.ToDecimal(AddLocLatitudeBox.Text), Convert.ToDecimal(AddLocLongitudeBox.Text)))
            {
                Status("New Location Details added to Database.", 1);

                _InitilizeVariables();
                LoadComboBoxes();
            }
        }

        private void UpdateLocNameCBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            decimal LocationLatitude, LocationLongitude;

            locations.GetCoordinates(UpdateLocNameCBox.SelectedItem.ToString(), out LocationLatitude, out LocationLongitude);

            UpdateLocLatitudeBox.Text = LocationLatitude.ToString();
            UpdateLocLongitudeBox.Text = LocationLongitude.ToString();
        }

        private void UpdateSelectedLocBtn_Click(object sender, EventArgs e)
        {
            int WhoShouldBeUpdated = 0;

            if (UpdateLocationNameRBtn.Checked)
            {
                WhoShouldBeUpdated = 1;
            }
            else if (UpdateLocationLatitudeRBtn.Checked)
            {
                WhoShouldBeUpdated = 2;
            }
            else if (UpdateLocationLongitudeRBtn.Checked)
            {
                WhoShouldBeUpdated = 3;
            }

            if (locations.UpdateLocation(UpdateLocNameCBox.Text, Convert.ToDecimal(UpdateLocLatitudeBox.Text), Convert.ToDecimal(UpdateLocLongitudeBox.Text), WhoShouldBeUpdated))
            {
                Status("Selected Location Details Updated.", 1);

                _InitilizeVariables();
                LoadComboBoxes();
            }
        }

        private void DeleteLocNameCBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            decimal LocationLatitude, LocationLongitude;

            locations.GetCoordinates(DeleteLocNameCBox.SelectedItem.ToString(), out LocationLatitude, out LocationLongitude);

            DeleteLocLatitudeBox.Text = LocationLatitude.ToString();
            DeleteLocLongitudeBox.Text = LocationLongitude.ToString();
        }

        private void DeleteSelectedLocBtn_Click(object sender, EventArgs e)
        {
            decimal LocationLatitude, LocationLongitude;

            locations.GetCoordinates(DeleteLocNameCBox.SelectedItem.ToString(), out LocationLatitude, out LocationLongitude);

            if (locations.DeleteLocation(DeleteLocNameCBox.SelectedItem.ToString(), LocationLatitude, LocationLongitude))
            {
                Status("Selected Location Details Deleted.", 1);

                _InitilizeVariables();
                LoadComboBoxes();
            }
        }

        private void UpdateFileJoinBtn_Click(object sender, EventArgs e)
        {
            if (settings.SetFileJoin(UpdateFileJoinBox.Text))
            {
                Status("File Join Setting Updated.", 1);

                _InitilizeVariables();
                LoadComboBoxes();
            }
        }

        private void UpdateFileExtensionBtn_Click(object sender, EventArgs e)
        {
            if (settings.SetFileExtension(UpdateFileExtensionBox.Text))
            {
                Status("File Extension Setting Updated.", 1);

                _InitilizeVariables();
                LoadComboBoxes();
            }
        }

        private void UpdateRootFolderBtn_Click(object sender, EventArgs e)
        {
            if (settings.SetRootFolder(UpdateRootFolderBox.Text))
            {
                Status("Root Folder Setting Updated.", 1);

                _InitilizeVariables();
                LoadComboBoxes();
            }
        }

        private void SelectRootFolderDialogBtn_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();

            if (fbd.ShowDialog() == DialogResult.OK)
            {
                UpdateRootFolderBox.Text = fbd.SelectedPath;
            }
        }
    }
}
