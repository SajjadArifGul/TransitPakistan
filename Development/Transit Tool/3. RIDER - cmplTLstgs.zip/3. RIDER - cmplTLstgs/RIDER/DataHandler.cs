﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace RIDER
{
    class DataHandler
    {
        /// <summary>
        /// it is connection of our database. initilized in InitilizeVariables()
        /// </summary>
        string ConnectionString;

        /// <summary>
        /// default constructor
        /// </summary>
        public DataHandler()
        {
            _InitilizeVariables();
        }

        /// <summary>
        /// method to initilize important variables
        /// </summary>
        private void _InitilizeVariables()
        {
            ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["RideDatabaseConnectionString"].ConnectionString;
        }

        /// <summary>
        /// will return arrays of Location Info with name & coordinates
        /// </summary>
        /// <param name="LocationNames">Location Names Array</param>
        /// <param name="LocationLatitudes">Location Latutudes Array</param>
        /// <param name="LocationLongitudes">Location Longitudes Array</param>
        public void GetAllLocationsInfo(out string[] LocationNames, out string[] LocationLatitudes, out string[] LocationLongitudes)
        {
            _GetAllLocationsInfo(out LocationNames, out LocationLatitudes, out LocationLongitudes);
        }
        //private : will return arrays of Location Info with name & coordinates
        private void _GetAllLocationsInfo(out string[] LocationNames, out string[] LocationLatitudes, out string[] LocationLongitudes)
        {
            List<string> LocationNamesList = new List<string>();
            List<string> LocationLatitudesList = new List<string>();
            List<string> LocationLongitudesList = new List<string>();

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();
                //Table name is Locations
                using (SqlCommand command = new SqlCommand("SelectAllLocations", con))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            //since Columns 0 is ID, Column 1 is Name, Column 2 is Latitude, Column 3 is Longitude
                            LocationNamesList.Add(reader.GetString(1));
                            LocationLatitudesList.Add(reader.GetDecimal(2).ToString());
                            LocationLongitudesList.Add(reader.GetDecimal(3).ToString());
                        }
                    }
                    con.Close();
                }
            }

            LocationNames = LocationNamesList.ToArray();
            LocationLatitudes = LocationLatitudesList.ToArray();
            LocationLongitudes = LocationLongitudesList.ToArray();

        }

        /// <summary>
        /// will return all available vehicle types from database
        /// </summary>
        /// <returns>VehicleTypes array</returns>
        public string[] GetAllVehicleTypes()
        {
            return _GetAllVehicleTypes();
        }
        //private : this will return all available vehicle types from database
        private string[] _GetAllVehicleTypes()
        {
            List<string> dataList = new List<string>();

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("SelectAllVehicleTypes", con))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            //since We want to return Vehicle Type Names only
                            //therefore sending 1. because column 0 is ID and column 1 is Name
                            dataList.Add(reader.GetString(1));
                        }
                    }
                    con.Close();
                }
            }

            return dataList.ToArray();
        }

        /// <summary>
        /// will return Array of vehicle names of given VehicleType from Database
        /// </summary>
        /// <param name="VehicleTypeName">VehicleType Name</param>
        /// <returns>Returns string array of Vehicle Type Names.</returns>
        public string[] GetVehiclesByTypeName(string VehicleTypeName)
        {
            return _GetVehiclesByTypeName(VehicleTypeName);
        }
        public string[] _GetVehiclesByTypeName(string VehicleTypeName)
        {
            //Get VehicleTypeID first & then send it to GetVehiclesByTypeID 
            return GetVehiclesByTypeID(GetVehicleTypeID(VehicleTypeName));
        }

        /// <summary>
        /// will return an Integer as ID of given VehicleType
        /// </summary>
        /// <param name="VehicleTypeName">Vehicle Type Name for which TypeID is required.</param>
        /// <returns>Integer TypeID of VehicleType Name</returns>
        public int GetVehicleTypeID(string VehicleTypeName)
        {
            return _GetVehicleTypeID(VehicleTypeName);
        }
        private int _GetVehicleTypeID(string VehicleTypeName)
        {
            //if there isnt any matching vehicle Type in DB
            //it will return 0 which is of Bus
            int ID = 0;

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("SELECT * FROM VehicleTypes where Name='" + VehicleTypeName + "'", con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        //column 0 is ID, column1 is Name
                        ID = reader.GetInt32(0);
                    }
                }
                con.Close();
            }

            return ID;
        }

        /// <summary>
        /// will return array of Vehicles name of given Vehicle TypeID
        /// </summary>
        /// <param name="TypeID">TypeID for which Vehicles are required.</param>
        /// <returns>Will return string array of Vehicle</returns>
        public string[] GetVehiclesByTypeID(int TypeID)
        {
            return _GetVehiclesByTypeID(TypeID);
        }
        private string[] _GetVehiclesByTypeID(int TypeID)
        {
            List<string> dataList = new List<string>();

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("SELECT * FROM Vehicles where TypeID='" + TypeID + "'", con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        //coulmn 0 is ID, coulmn 1 is TypeID & column 2 is Name.
                        //we need vehicle names thatswhy sending 2.
                        dataList.Add(reader.GetString(2));
                    }
                }
                con.Close();
            }

            return dataList.ToArray();
        }

        /// <summary>
        /// Will return settings from Database
        /// </summary>
        /// <param name="FileJoin">Join between 2 names of Locations for File Naming</param>
        /// <param name="FileExtension">Extension for the files to be created</param>
        /// <param name="RootFolder">Root folder is where all the files will be saved</param>
        public void GetSettings(out string FileJoin, out string FileExtension, out string RootFolder)
        {
            _GetSettings(out FileJoin, out FileExtension, out RootFolder);
        }
        private void _GetSettings(out string FileJoin, out string FileExtension, out string RootFolder)
        {
            int ID = 0;

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("SELECT MAX(ID) FROM Settings", con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        //column 0 is ID, column1 is Name
                        ID = reader.GetInt32(0);
                    }
                }
                con.Close();
            }

            //we now have Max ID. send it to get all other records
            string TempFileJoin = "", TempFileExtension = "", TempRootFolder = "";

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("SELECT * FROM Settings where ID=" + ID + "", con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        TempFileJoin = reader.GetString(1);
                        TempFileExtension = reader.GetString(2);
                        TempRootFolder = reader.GetString(3);
                    }
                }
                con.Close();
            }

            FileJoin = TempFileJoin;
            FileExtension = TempFileExtension;
            RootFolder = TempRootFolder;
        }

        public bool AddVehicleType(string VehicleType)
        {
            return _AddVehicleType(VehicleType);
        }
        private bool _AddVehicleType(string VehicleType)
        {
            int NumberOfRowsAffected = 0;
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("Insert into VehicleTypes (Name) values ('" + VehicleType + "')", con))
                {
                    NumberOfRowsAffected = command.ExecuteNonQuery();
                }
                con.Close();
            }

            if (NumberOfRowsAffected > 0)
            {
                return true;
            }
            else return false;
        }

        public bool DeleteVehicleType(string VehicleType)
        {
            return _DeleteVehicleType(VehicleType);
        }
        private bool _DeleteVehicleType(string VehicleType)
        {
            int NumberOfRowsAffected = 0;
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("Delete from VehicleTypes where Name='" + VehicleType + "'", con))
                {
                    NumberOfRowsAffected = command.ExecuteNonQuery();
                }
                con.Close();
            }

            if (NumberOfRowsAffected > 0)
            {
                return true;
            }
            else return false;
        }

        public bool AddNewVehicle(string VehicleName, int TypeID, string StartPoint, string EndPoint)
        {
            return _AddNewVehicle(VehicleName, TypeID, StartPoint, EndPoint);
        }
        private bool _AddNewVehicle(string VehicleName, int TypeID, string StartPoint, string EndPoint)
        {
            int NumberOfRowsAffected = 0;
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("Insert into Vehicles (TypeID, Name, StartPoint, EndPoint) values ('" + TypeID + "','" + VehicleName + "','" + StartPoint + "', '" + EndPoint + "')", con))
                {
                    NumberOfRowsAffected = command.ExecuteNonQuery();
                }
                con.Close();
            }

            if (NumberOfRowsAffected > 0)
            {
                return true;
            }
            else return false;
        }

        public bool DeleteVehicle(int TypeID, string VehicleName)
        {
            return _DeleteVehicle(TypeID, VehicleName);
        }
        private bool _DeleteVehicle(int TypeID, string VehicleName)
        {
            int NumberOfRowsAffected = 0;
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("Delete from Vehicles where TypeID='" + TypeID + "' and Name='" + VehicleName + "'", con))
                {
                    NumberOfRowsAffected = command.ExecuteNonQuery();
                }
                con.Close();
            }

            if (NumberOfRowsAffected > 0)
            {
                return true;
            }
            else return false;
        }

        public int GetLocationID(string LocationName, decimal Latitude, decimal Longitude)
        {
            return _GetLocationID(LocationName, Latitude, Longitude);
        }
        private int _GetLocationID(string LocationName, decimal Latitude, decimal Longitude)
        {
            int ID = 0;

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("SELECT * FROM Locations where Name='" + LocationName + "'  and Latitude='" + Latitude + "' and Longitude='" + Longitude + "' ", con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        //column 0 is ID, column1 is Name
                        ID = reader.GetInt32(0);
                    }
                }
                con.Close();
            }

            return ID;
        }

        public bool AddNewLocation(string LocationName, decimal Latitude, decimal Longitude)
        {
            return _AddNewLocation(LocationName, Latitude, Longitude);
        }
        private bool _AddNewLocation(string LocationName, decimal Latitude, decimal Longitude)
        {
            int NumberOfRowsAffected = 0;
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("Insert into Locations (Name, Latitude, Longitude) values ('" + LocationName + "', '" + Latitude + "', '" + Longitude + "')", con))
                {
                    NumberOfRowsAffected = command.ExecuteNonQuery();
                }
                con.Close();
            }

            if (NumberOfRowsAffected > 0)
            {
                return true;
            }
            else return false;
        }

        public bool UpdateLocationName(string LocationName, decimal Latitude, decimal Longitude)
        {
            return _UpdateLocationName(LocationName, Latitude, Longitude);
        }
        private bool _UpdateLocationName(string LocationName, decimal Latitude, decimal Longitude)
        {
            int NumberOfRowsAffected = 0;
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("Update Locations set Name='" + LocationName + "' where Latitude='" + Latitude + "' and Longitude='" + Longitude + "'", con))
                {
                    NumberOfRowsAffected = command.ExecuteNonQuery();
                }
                con.Close();
            }

            if (NumberOfRowsAffected > 0)
            {
                return true;
            }
            else return false;
        }

        public bool UpdateLocationLatitude(int LocationID, decimal Latitude)
        {
            return _UpdateLocationLatitude(LocationID, Latitude);
        }
        private bool _UpdateLocationLatitude(int LocationID, decimal Latitude)
        {
            int NumberOfRowsAffected = 0;
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("Update Locations set Latitude='" + Latitude + "' where ID='" + LocationID + "'", con))
                {
                    NumberOfRowsAffected = command.ExecuteNonQuery();
                }
                con.Close();
            }

            if (NumberOfRowsAffected > 0)
            {
                return true;
            }
            else return false;
        }

        public bool UpdateLocationLongitude(int LocationID, decimal Longitude)
        {
            return _UpdateLocationLongitude(LocationID, Longitude);
        }
        private bool _UpdateLocationLongitude(int LocationID, decimal Longitude)
        {
            int NumberOfRowsAffected = 0;
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("Update Locations set Longitude='" + Longitude + "' where ID='" + LocationID + "'", con))
                {
                    NumberOfRowsAffected = command.ExecuteNonQuery();
                }
                con.Close();
            }

            if (NumberOfRowsAffected > 0)
            {
                return true;
            }
            else return false;
        }

        public bool DeleteLocation(int LocationID)
        {
            return _DeleteLocation(LocationID);
        }
        private bool _DeleteLocation(int LocationID)
        {
            int NumberOfRowsAffected = 0;
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("Delete from Locations where ID='" + LocationID + "'", con))
                {
                    NumberOfRowsAffected = command.ExecuteNonQuery();
                }
                con.Close();
            }

            if (NumberOfRowsAffected > 0)
            {
                return true;
            }
            else return false;
        }

        public bool SetFileJoin(string FileJoin)
        {
            return _SetFileJoin(FileJoin);
        }
        private bool _SetFileJoin(string FileJoin)
        {
            int SettingsID = 0;

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("SELECT MAX(ID) FROM Settings", con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        //column 0 is ID, column1 is Name
                        SettingsID = reader.GetInt32(0);
                    }
                }
                con.Close();
            }

            int NumberOfRowsAffected = 0;
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("Update Settings set FileJoin='" + FileJoin + "' where ID='" + SettingsID + "'", con))
                {
                    NumberOfRowsAffected = command.ExecuteNonQuery();
                }
                con.Close();
            }

            if (NumberOfRowsAffected > 0)
            {
                return true;
            }
            else return false;
        }

        public bool SetFileExtension(string FileExtension)
        {
            return _SetFileExtension(FileExtension);
        }
        private bool _SetFileExtension(string FileExtension)
        {
            int SettingsID = 0;

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("SELECT MAX(ID) FROM Settings", con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        //column 0 is ID, column1 is Name
                        SettingsID = reader.GetInt32(0);
                    }
                }
                con.Close();
            }

            int NumberOfRowsAffected = 0;
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("Update Settings set FileExtension='" + FileExtension + "' where ID='" + SettingsID + "'", con))
                {
                    NumberOfRowsAffected = command.ExecuteNonQuery();
                }
                con.Close();
            }

            if (NumberOfRowsAffected > 0)
            {
                return true;
            }
            else return false;
        }

        public bool SetRootFolder(string RootFolder)
        {
            return _SetRootFolder(RootFolder);
        }
        private bool _SetRootFolder(string RootFolder)
        {
            int SettingsID = 0;

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("SELECT MAX(ID) FROM Settings", con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        //column 0 is ID, column1 is Name
                        SettingsID = reader.GetInt32(0);
                    }
                }
                con.Close();
            }

            int NumberOfRowsAffected = 0;
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("Update Settings set RootFolder='" + RootFolder + "' where ID='" + SettingsID + "'", con))
                {
                    NumberOfRowsAffected = command.ExecuteNonQuery();
                }
                con.Close();
            }

            if (NumberOfRowsAffected > 0)
            {
                return true;
            }
            else return false;
        }
    }
}
