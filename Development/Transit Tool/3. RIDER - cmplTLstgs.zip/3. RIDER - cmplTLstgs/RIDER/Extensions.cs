﻿using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace RIDER
{
    static class Extensions
    {
        /// <summary>
        /// Returns first occurance of string between two specified string
        /// </summary>
        /// <param name="Source">Complete Source</param>
        /// <param name="StartingPoint">Starting Point of String to find</param>
        /// <param name="EndingPoint">Ending Point of String to find</param>
        /// <returns></returns>
        public static string Between(this string Source, string StartingPoint, string EndingPoint)
        {
            int start = Source.IndexOf(StartingPoint);
            int to = Source.IndexOf(EndingPoint, start + StartingPoint.Length);
            if (start < 0 || to < 0) return "";
            string s = Source.Substring(
                           start + StartingPoint.Length,
                           to - start - StartingPoint.Length);
            return s;
        }

        /// <summary>
        /// Converts ArrayList to List
        /// </summary>
        /// <typeparam name="T">datatype of List</typeparam>
        /// <param name="givenArrayList">ArrayList to convert</param>
        /// <returns></returns>
        public static List<T> ArrayListToList<T>(this ArrayList givenArrayList)
        {
            List<T> list = new List<T>(givenArrayList.Count);

            foreach (T instance in givenArrayList)
            {
                list.Add(instance);
            }
            return list;
        }

        /// <summary>
        /// Returns standard name for files by removing unwanted characters
        /// </summary>
        /// <param name="Name">Name to Standardize</param>
        /// <returns>Standardize name</returns>
        public static string Standard(this string Name)
        {
            Name = Regex.Replace(Name, @"\s+", "");
            Name = Name.Replace("(", "");
            Name = Name.Replace(")", "");

            return Name;
        }
    }
}
