﻿
namespace RIDER
{
    class Settings
    {
        /// <summary>
        /// Object of DataHandler class to get data from database
        /// </summary>
        DataHandler dataHandler;

        /// <summary>
        /// default constructor
        /// </summary>
        public Settings()
        {
            _InitilizeVariables();
        }

        /// <summary>
        /// setting variables to get
        /// </summary>
        private string FileJoin, FileExtension, RootFolder;

        /// <summary>
        /// method to initialize important variables
        /// </summary>
        public void _InitilizeVariables()
        {
            dataHandler = new DataHandler();

            dataHandler.GetSettings(out FileJoin, out FileExtension, out RootFolder);
        }

        /// <summary>
        /// Will return Setting for File join from database
        /// </summary>
        /// <returns>Returns String containing File Join</returns>
        public string GetFileJoin()
        {
            return FileJoin;
        }

        /// <summary>
        /// Will return File extension from database
        /// </summary>
        /// <returns>Returns string containing File Extension setting</returns>
        public string GetFileExtension()
        {
            return FileExtension;
        }

        /// <summary>
        /// Will return Roor folder settings from database
        /// </summary>
        /// <returns>Returns string containing Root Folder details</returns>
        public string GetRootFolder()
        {
            return RootFolder;
        }

        public bool SetFileJoin(string FileJoin)
        {
            return _SetFileJoin(FileJoin);
        }
        private bool _SetFileJoin(string FileJoin)
        {
            return dataHandler.SetFileJoin(FileJoin);
        }

        public bool SetFileExtension(string FileExtension)
        {
            return _SetFileExtension(FileExtension);
        }
        private bool _SetFileExtension(string FileExtension)
        {
            return dataHandler.SetFileExtension(FileExtension);
        }

        public bool SetRootFolder(string RootFolder)
        {
            return _SetRootFolder(RootFolder);
        }
        private bool _SetRootFolder(string RootFolder)
        {
            return dataHandler.SetRootFolder(RootFolder);
        }
    }
}
