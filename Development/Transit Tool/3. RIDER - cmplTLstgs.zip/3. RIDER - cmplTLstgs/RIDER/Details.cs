﻿namespace RIDER
{
    class Details
    {
        public string FilePath;
        public string Content;
        public string Repeated;
        public string Status;
        public string Uploaded;
        public string StartPoint;
        public string EndPoint;
        public string VehicleType;
        public string VehicleName;
        public string Join;
        public string Extension;
        public bool Override;
        public int RowNumber;
        public string FileCreatedStatus;
        public int FileCreated;
        public int FileNotCreated;
        public string RootFolder;
    }
}
