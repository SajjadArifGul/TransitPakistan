﻿namespace RIDER
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.menu1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewVehicleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewVehicleTypeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewLocationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menu2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteVehicleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteVehicleTypeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteLocationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menu3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setFileJoinToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setFileExtensionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setRootFolderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MainMenu = new System.Windows.Forms.MenuStrip();
            this.Tabs = new System.Windows.Forms.TabControl();
            this.VehicleRouteTab = new System.Windows.Forms.TabPage();
            this.MainPanel = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.RoutesRichBox = new System.Windows.Forms.RichTextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.VehicleNameComboBox = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.VehicleTypeComboBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.FormatXMLBtn = new System.Windows.Forms.Button();
            this.GenerateRoutesXMLBtn = new System.Windows.Forms.Button();
            this.GenerateVehicleXMLBtn = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.AddEndPointBtn = new System.Windows.Forms.Button();
            this.EndPointLongBox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.EndPointLatBox = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.EndPointNameComboBox = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.AddBusStopBtn = new System.Windows.Forms.Button();
            this.BusStopLongitudeBox = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.BusStopComboBox = new System.Windows.Forms.ComboBox();
            this.BusStopLatitudeBox = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.AddStartPointBtn = new System.Windows.Forms.Button();
            this.StartPointLongBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.StartPointLatBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.StartPointNameComboBox = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.RoutesTab = new System.Windows.Forms.TabPage();
            this.ProcessPanel = new System.Windows.Forms.Panel();
            this.FilesNotCreatedLabel = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.FilesCreatedLabel = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.StartCreatingFilesButton = new System.Windows.Forms.Button();
            this.RouteCombinationsLabel = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.FilesGridPanel = new System.Windows.Forms.Panel();
            this.FilesGridView = new System.Windows.Forms.DataGridView();
            this.SelectAllColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.StartPointColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EndPointColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RouteDataColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StatusColumn = new System.Windows.Forms.DataGridViewButtonColumn();
            this.UploadedColumn = new System.Windows.Forms.DataGridViewButtonColumn();
            this.VehiclesTab = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.DeleteVehicleNameCBox = new System.Windows.Forms.ComboBox();
            this.DeleteSelectedVehicleBtn = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.DeleteVehicleVehicleTypeCBox = new System.Windows.Forms.ComboBox();
            this.panel11 = new System.Windows.Forms.Panel();
            this.AddNewVehicleEndPointBox = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.AddNewVehicleStartPointBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.AddNewVehicleNameBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.AddNewVehicleVehicleTypeCBox = new System.Windows.Forms.ComboBox();
            this.AddNewVehicleBtn = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.DeleteSelectedVehicleTypeBtn = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.DeleteVehicleTypeCBox = new System.Windows.Forms.ComboBox();
            this.panel13 = new System.Windows.Forms.Panel();
            this.AddSelectedVehicleTypeBtn = new System.Windows.Forms.Button();
            this.AddVehicleTypeBox = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.LocationsTab = new System.Windows.Forms.TabPage();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.DeleteLocLongitudeBox = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.DeleteLocLatitudeBox = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.DeleteLocNameCBox = new System.Windows.Forms.ComboBox();
            this.DeleteSelectedLocBtn = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.UpdateLocLongitudeBox = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.UpdateLocLatitudeBox = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.UpdateLocNameCBox = new System.Windows.Forms.ComboBox();
            this.UpdateSelectedLocBtn = new System.Windows.Forms.Button();
            this.label30 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.AddLocLongitudeBox = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.AddLocLatitudeBox = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.AddNewLocBtn = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.SettingsTab = new System.Windows.Forms.TabPage();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.UpdateRootFolderBox = new System.Windows.Forms.TextBox();
            this.UpdateRootFolderBtn = new System.Windows.Forms.Button();
            this.label34 = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.UpdateFileExtensionBox = new System.Windows.Forms.TextBox();
            this.UpdateFileExtensionBtn = new System.Windows.Forms.Button();
            this.label38 = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.UpdateFileJoinBtn = new System.Windows.Forms.Button();
            this.UpdateFileJoinBox = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.RouteGenerator = new System.ComponentModel.BackgroundWorker();
            this.RoutesIterator = new System.ComponentModel.BackgroundWorker();
            this.AddLocNameBox = new System.Windows.Forms.TextBox();
            this.UpdateLocationNameRBtn = new System.Windows.Forms.RadioButton();
            this.UpdateLocationLongitudeRBtn = new System.Windows.Forms.RadioButton();
            this.UpdateLocationLatitudeRBtn = new System.Windows.Forms.RadioButton();
            this.SelectRootFolderDialogBtn = new System.Windows.Forms.Button();
            this.MainMenu.SuspendLayout();
            this.Tabs.SuspendLayout();
            this.VehicleRouteTab.SuspendLayout();
            this.MainPanel.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.RoutesTab.SuspendLayout();
            this.ProcessPanel.SuspendLayout();
            this.FilesGridPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FilesGridView)).BeginInit();
            this.VehiclesTab.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            this.LocationsTab.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel14.SuspendLayout();
            this.SettingsTab.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel20.SuspendLayout();
            this.SuspendLayout();
            // 
            // menu1ToolStripMenuItem
            // 
            this.menu1ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addNewVehicleToolStripMenuItem,
            this.addNewVehicleTypeToolStripMenuItem,
            this.addNewLocationToolStripMenuItem});
            this.menu1ToolStripMenuItem.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.menu1ToolStripMenuItem.Name = "menu1ToolStripMenuItem";
            this.menu1ToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.menu1ToolStripMenuItem.Text = "Add";
            // 
            // addNewVehicleToolStripMenuItem
            // 
            this.addNewVehicleToolStripMenuItem.Name = "addNewVehicleToolStripMenuItem";
            this.addNewVehicleToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.addNewVehicleToolStripMenuItem.Text = "Add New Vehicle";
            this.addNewVehicleToolStripMenuItem.Click += new System.EventHandler(this.addNewVehicleToolStripMenuItem_Click);
            // 
            // addNewVehicleTypeToolStripMenuItem
            // 
            this.addNewVehicleTypeToolStripMenuItem.Name = "addNewVehicleTypeToolStripMenuItem";
            this.addNewVehicleTypeToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.addNewVehicleTypeToolStripMenuItem.Text = "Add New Vehicle Type";
            this.addNewVehicleTypeToolStripMenuItem.Click += new System.EventHandler(this.addNewVehicleTypeToolStripMenuItem_Click);
            // 
            // addNewLocationToolStripMenuItem
            // 
            this.addNewLocationToolStripMenuItem.Name = "addNewLocationToolStripMenuItem";
            this.addNewLocationToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.addNewLocationToolStripMenuItem.Text = "Add New Location";
            this.addNewLocationToolStripMenuItem.Click += new System.EventHandler(this.addNewLocationToolStripMenuItem_Click);
            // 
            // menu2ToolStripMenuItem
            // 
            this.menu2ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteVehicleToolStripMenuItem,
            this.deleteVehicleTypeToolStripMenuItem,
            this.deleteLocationToolStripMenuItem});
            this.menu2ToolStripMenuItem.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.menu2ToolStripMenuItem.Name = "menu2ToolStripMenuItem";
            this.menu2ToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.menu2ToolStripMenuItem.Text = "Delete";
            // 
            // deleteVehicleToolStripMenuItem
            // 
            this.deleteVehicleToolStripMenuItem.Name = "deleteVehicleToolStripMenuItem";
            this.deleteVehicleToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.deleteVehicleToolStripMenuItem.Text = "Delete Vehicle";
            this.deleteVehicleToolStripMenuItem.Click += new System.EventHandler(this.deleteVehicleToolStripMenuItem_Click);
            // 
            // deleteVehicleTypeToolStripMenuItem
            // 
            this.deleteVehicleTypeToolStripMenuItem.Name = "deleteVehicleTypeToolStripMenuItem";
            this.deleteVehicleTypeToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.deleteVehicleTypeToolStripMenuItem.Text = "Delete Vehicle Type";
            this.deleteVehicleTypeToolStripMenuItem.Click += new System.EventHandler(this.deleteVehicleTypeToolStripMenuItem_Click);
            // 
            // deleteLocationToolStripMenuItem
            // 
            this.deleteLocationToolStripMenuItem.Name = "deleteLocationToolStripMenuItem";
            this.deleteLocationToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.deleteLocationToolStripMenuItem.Text = "Delete Location";
            this.deleteLocationToolStripMenuItem.Click += new System.EventHandler(this.deleteLocationToolStripMenuItem_Click);
            // 
            // menu3ToolStripMenuItem
            // 
            this.menu3ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.setFileJoinToolStripMenuItem,
            this.setFileExtensionToolStripMenuItem,
            this.setRootFolderToolStripMenuItem});
            this.menu3ToolStripMenuItem.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.menu3ToolStripMenuItem.Name = "menu3ToolStripMenuItem";
            this.menu3ToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.menu3ToolStripMenuItem.Text = "Settings";
            // 
            // setFileJoinToolStripMenuItem
            // 
            this.setFileJoinToolStripMenuItem.Name = "setFileJoinToolStripMenuItem";
            this.setFileJoinToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.setFileJoinToolStripMenuItem.Text = "Set File Join";
            this.setFileJoinToolStripMenuItem.Click += new System.EventHandler(this.setFileJoinToolStripMenuItem_Click);
            // 
            // setFileExtensionToolStripMenuItem
            // 
            this.setFileExtensionToolStripMenuItem.Name = "setFileExtensionToolStripMenuItem";
            this.setFileExtensionToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.setFileExtensionToolStripMenuItem.Text = "Set File Extension";
            this.setFileExtensionToolStripMenuItem.Click += new System.EventHandler(this.setFileExtensionToolStripMenuItem_Click);
            // 
            // setRootFolderToolStripMenuItem
            // 
            this.setRootFolderToolStripMenuItem.Name = "setRootFolderToolStripMenuItem";
            this.setRootFolderToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.setRootFolderToolStripMenuItem.Text = "Set Root Folder";
            this.setRootFolderToolStripMenuItem.Click += new System.EventHandler(this.setRootFolderToolStripMenuItem_Click);
            // 
            // MainMenu
            // 
            this.MainMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(142)))), ((int)(((byte)(60)))));
            this.MainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu1ToolStripMenuItem,
            this.menu2ToolStripMenuItem,
            this.menu3ToolStripMenuItem});
            this.MainMenu.Location = new System.Drawing.Point(0, 0);
            this.MainMenu.Name = "MainMenu";
            this.MainMenu.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.MainMenu.Size = new System.Drawing.Size(917, 24);
            this.MainMenu.TabIndex = 0;
            this.MainMenu.Text = "menuStrip1";
            // 
            // Tabs
            // 
            this.Tabs.Controls.Add(this.VehicleRouteTab);
            this.Tabs.Controls.Add(this.RoutesTab);
            this.Tabs.Controls.Add(this.VehiclesTab);
            this.Tabs.Controls.Add(this.LocationsTab);
            this.Tabs.Controls.Add(this.SettingsTab);
            this.Tabs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Tabs.Location = new System.Drawing.Point(0, 24);
            this.Tabs.Name = "Tabs";
            this.Tabs.SelectedIndex = 0;
            this.Tabs.Size = new System.Drawing.Size(917, 451);
            this.Tabs.TabIndex = 1;
            // 
            // VehicleRouteTab
            // 
            this.VehicleRouteTab.Controls.Add(this.MainPanel);
            this.VehicleRouteTab.Location = new System.Drawing.Point(4, 25);
            this.VehicleRouteTab.Name = "VehicleRouteTab";
            this.VehicleRouteTab.Padding = new System.Windows.Forms.Padding(3);
            this.VehicleRouteTab.Size = new System.Drawing.Size(909, 422);
            this.VehicleRouteTab.TabIndex = 0;
            this.VehicleRouteTab.Text = "Add Vehicle Route Data";
            this.VehicleRouteTab.UseVisualStyleBackColor = true;
            // 
            // MainPanel
            // 
            this.MainPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.MainPanel.Controls.Add(this.panel7);
            this.MainPanel.Controls.Add(this.panel6);
            this.MainPanel.Controls.Add(this.panel5);
            this.MainPanel.Controls.Add(this.panel4);
            this.MainPanel.Controls.Add(this.panel3);
            this.MainPanel.Controls.Add(this.panel2);
            this.MainPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainPanel.Location = new System.Drawing.Point(3, 3);
            this.MainPanel.Name = "MainPanel";
            this.MainPanel.Size = new System.Drawing.Size(903, 416);
            this.MainPanel.TabIndex = 2;
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.RoutesRichBox);
            this.panel7.Location = new System.Drawing.Point(547, 12);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(351, 402);
            this.panel7.TabIndex = 34;
            // 
            // RoutesRichBox
            // 
            this.RoutesRichBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.RoutesRichBox.Location = new System.Drawing.Point(3, 3);
            this.RoutesRichBox.Name = "RoutesRichBox";
            this.RoutesRichBox.Size = new System.Drawing.Size(343, 394);
            this.RoutesRichBox.TabIndex = 0;
            this.RoutesRichBox.Text = "";
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.VehicleNameComboBox);
            this.panel6.Controls.Add(this.label2);
            this.panel6.Controls.Add(this.VehicleTypeComboBox);
            this.panel6.Controls.Add(this.label1);
            this.panel6.Location = new System.Drawing.Point(6, 12);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(535, 38);
            this.panel6.TabIndex = 33;
            // 
            // VehicleNameComboBox
            // 
            this.VehicleNameComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.VehicleNameComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.VehicleNameComboBox.FormattingEnabled = true;
            this.VehicleNameComboBox.Location = new System.Drawing.Point(362, 5);
            this.VehicleNameComboBox.Name = "VehicleNameComboBox";
            this.VehicleNameComboBox.Size = new System.Drawing.Size(165, 24);
            this.VehicleNameComboBox.TabIndex = 7;
            this.VehicleNameComboBox.SelectedIndexChanged += new System.EventHandler(this.VehicleNameComboBox_SelectedIndexChanged);
            this.VehicleNameComboBox.TextChanged += new System.EventHandler(this.VehicleNameComboBox_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(264, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "Vehicle Name";
            // 
            // VehicleTypeComboBox
            // 
            this.VehicleTypeComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.VehicleTypeComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.VehicleTypeComboBox.FormattingEnabled = true;
            this.VehicleTypeComboBox.Location = new System.Drawing.Point(98, 5);
            this.VehicleTypeComboBox.Name = "VehicleTypeComboBox";
            this.VehicleTypeComboBox.Size = new System.Drawing.Size(165, 24);
            this.VehicleTypeComboBox.TabIndex = 5;
            this.VehicleTypeComboBox.SelectedIndexChanged += new System.EventHandler(this.VehicleTypeComboBox_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "Vehicle Type";
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.FormatXMLBtn);
            this.panel5.Controls.Add(this.GenerateRoutesXMLBtn);
            this.panel5.Controls.Add(this.GenerateVehicleXMLBtn);
            this.panel5.Location = new System.Drawing.Point(6, 350);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(535, 64);
            this.panel5.TabIndex = 32;
            // 
            // FormatXMLBtn
            // 
            this.FormatXMLBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(142)))), ((int)(((byte)(60)))));
            this.FormatXMLBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.FormatXMLBtn.FlatAppearance.BorderSize = 0;
            this.FormatXMLBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.FormatXMLBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(117)))), ((int)(((byte)(50)))));
            this.FormatXMLBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FormatXMLBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.FormatXMLBtn.Location = new System.Drawing.Point(9, 6);
            this.FormatXMLBtn.Name = "FormatXMLBtn";
            this.FormatXMLBtn.Size = new System.Drawing.Size(160, 50);
            this.FormatXMLBtn.TabIndex = 14;
            this.FormatXMLBtn.Text = "Format XML";
            this.FormatXMLBtn.UseVisualStyleBackColor = false;
            this.FormatXMLBtn.Click += new System.EventHandler(this.FormatXMLBtn_Click);
            // 
            // GenerateRoutesXMLBtn
            // 
            this.GenerateRoutesXMLBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(142)))), ((int)(((byte)(60)))));
            this.GenerateRoutesXMLBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.GenerateRoutesXMLBtn.FlatAppearance.BorderSize = 0;
            this.GenerateRoutesXMLBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.GenerateRoutesXMLBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(117)))), ((int)(((byte)(50)))));
            this.GenerateRoutesXMLBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.GenerateRoutesXMLBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.GenerateRoutesXMLBtn.Location = new System.Drawing.Point(367, 6);
            this.GenerateRoutesXMLBtn.Name = "GenerateRoutesXMLBtn";
            this.GenerateRoutesXMLBtn.Size = new System.Drawing.Size(160, 50);
            this.GenerateRoutesXMLBtn.TabIndex = 13;
            this.GenerateRoutesXMLBtn.Text = "Generate Routes XML";
            this.GenerateRoutesXMLBtn.UseVisualStyleBackColor = false;
            this.GenerateRoutesXMLBtn.Click += new System.EventHandler(this.GenerateRoutesXMLBtn_Click);
            // 
            // GenerateVehicleXMLBtn
            // 
            this.GenerateVehicleXMLBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(142)))), ((int)(((byte)(60)))));
            this.GenerateVehicleXMLBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.GenerateVehicleXMLBtn.FlatAppearance.BorderSize = 0;
            this.GenerateVehicleXMLBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.GenerateVehicleXMLBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(117)))), ((int)(((byte)(50)))));
            this.GenerateVehicleXMLBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.GenerateVehicleXMLBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.GenerateVehicleXMLBtn.Location = new System.Drawing.Point(188, 6);
            this.GenerateVehicleXMLBtn.Name = "GenerateVehicleXMLBtn";
            this.GenerateVehicleXMLBtn.Size = new System.Drawing.Size(160, 50);
            this.GenerateVehicleXMLBtn.TabIndex = 12;
            this.GenerateVehicleXMLBtn.Text = "Generate Vehicle XML";
            this.GenerateVehicleXMLBtn.UseVisualStyleBackColor = false;
            this.GenerateVehicleXMLBtn.Click += new System.EventHandler(this.GenerateVehicleXMLBtn_Click);
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.AddEndPointBtn);
            this.panel4.Controls.Add(this.EndPointLongBox);
            this.panel4.Controls.Add(this.label13);
            this.panel4.Controls.Add(this.EndPointLatBox);
            this.panel4.Controls.Add(this.label15);
            this.panel4.Controls.Add(this.EndPointNameComboBox);
            this.panel4.Controls.Add(this.label16);
            this.panel4.Location = new System.Drawing.Point(6, 252);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(535, 92);
            this.panel4.TabIndex = 31;
            // 
            // AddEndPointBtn
            // 
            this.AddEndPointBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(142)))), ((int)(((byte)(60)))));
            this.AddEndPointBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.AddEndPointBtn.FlatAppearance.BorderSize = 0;
            this.AddEndPointBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.AddEndPointBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(117)))), ((int)(((byte)(50)))));
            this.AddEndPointBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddEndPointBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.AddEndPointBtn.Location = new System.Drawing.Point(98, 61);
            this.AddEndPointBtn.Name = "AddEndPointBtn";
            this.AddEndPointBtn.Size = new System.Drawing.Size(430, 23);
            this.AddEndPointBtn.TabIndex = 19;
            this.AddEndPointBtn.Text = "Add End Point";
            this.AddEndPointBtn.UseVisualStyleBackColor = false;
            this.AddEndPointBtn.Click += new System.EventHandler(this.AddEndPointBtn_Click);
            // 
            // EndPointLongBox
            // 
            this.EndPointLongBox.Location = new System.Drawing.Point(362, 34);
            this.EndPointLongBox.Name = "EndPointLongBox";
            this.EndPointLongBox.Size = new System.Drawing.Size(165, 22);
            this.EndPointLongBox.TabIndex = 18;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(271, 37);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(67, 16);
            this.label13.TabIndex = 17;
            this.label13.Text = "Longitude";
            // 
            // EndPointLatBox
            // 
            this.EndPointLatBox.Location = new System.Drawing.Point(98, 34);
            this.EndPointLatBox.Name = "EndPointLatBox";
            this.EndPointLatBox.Size = new System.Drawing.Size(165, 22);
            this.EndPointLatBox.TabIndex = 16;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 37);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(55, 16);
            this.label15.TabIndex = 15;
            this.label15.Text = "Latitude";
            // 
            // EndPointNameComboBox
            // 
            this.EndPointNameComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.EndPointNameComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.EndPointNameComboBox.FormattingEnabled = true;
            this.EndPointNameComboBox.Location = new System.Drawing.Point(98, 5);
            this.EndPointNameComboBox.Name = "EndPointNameComboBox";
            this.EndPointNameComboBox.Size = new System.Drawing.Size(430, 24);
            this.EndPointNameComboBox.TabIndex = 14;
            this.EndPointNameComboBox.SelectedIndexChanged += new System.EventHandler(this.EndPointNameComboBox_SelectedIndexChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 9);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(65, 16);
            this.label16.TabIndex = 13;
            this.label16.Text = "End Point";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.AddBusStopBtn);
            this.panel3.Controls.Add(this.BusStopLongitudeBox);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.BusStopComboBox);
            this.panel3.Controls.Add(this.BusStopLatitudeBox);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Location = new System.Drawing.Point(6, 154);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(535, 92);
            this.panel3.TabIndex = 30;
            // 
            // AddBusStopBtn
            // 
            this.AddBusStopBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(142)))), ((int)(((byte)(60)))));
            this.AddBusStopBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.AddBusStopBtn.FlatAppearance.BorderSize = 0;
            this.AddBusStopBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.AddBusStopBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(117)))), ((int)(((byte)(50)))));
            this.AddBusStopBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddBusStopBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.AddBusStopBtn.Location = new System.Drawing.Point(98, 62);
            this.AddBusStopBtn.Name = "AddBusStopBtn";
            this.AddBusStopBtn.Size = new System.Drawing.Size(430, 23);
            this.AddBusStopBtn.TabIndex = 12;
            this.AddBusStopBtn.Text = "Add Bus Stop";
            this.AddBusStopBtn.UseVisualStyleBackColor = false;
            this.AddBusStopBtn.Click += new System.EventHandler(this.AddBusStopBtn_Click);
            // 
            // BusStopLongitudeBox
            // 
            this.BusStopLongitudeBox.Location = new System.Drawing.Point(362, 35);
            this.BusStopLongitudeBox.Name = "BusStopLongitudeBox";
            this.BusStopLongitudeBox.Size = new System.Drawing.Size(165, 22);
            this.BusStopLongitudeBox.TabIndex = 7;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(5, 10);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(92, 16);
            this.label14.TabIndex = 0;
            this.label14.Text = "Next Bus Stop";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(271, 38);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(67, 16);
            this.label11.TabIndex = 6;
            this.label11.Text = "Longitude";
            // 
            // BusStopComboBox
            // 
            this.BusStopComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.BusStopComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.BusStopComboBox.FormattingEnabled = true;
            this.BusStopComboBox.Location = new System.Drawing.Point(98, 6);
            this.BusStopComboBox.Name = "BusStopComboBox";
            this.BusStopComboBox.Size = new System.Drawing.Size(430, 24);
            this.BusStopComboBox.TabIndex = 1;
            this.BusStopComboBox.SelectedIndexChanged += new System.EventHandler(this.BusStopComboBox_SelectedIndexChanged);
            // 
            // BusStopLatitudeBox
            // 
            this.BusStopLatitudeBox.Location = new System.Drawing.Point(98, 35);
            this.BusStopLatitudeBox.Name = "BusStopLatitudeBox";
            this.BusStopLatitudeBox.Size = new System.Drawing.Size(165, 22);
            this.BusStopLatitudeBox.TabIndex = 5;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 38);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(55, 16);
            this.label12.TabIndex = 4;
            this.label12.Text = "Latitude";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.AddStartPointBtn);
            this.panel2.Controls.Add(this.StartPointLongBox);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.StartPointLatBox);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.StartPointNameComboBox);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Location = new System.Drawing.Point(6, 56);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(535, 92);
            this.panel2.TabIndex = 29;
            // 
            // AddStartPointBtn
            // 
            this.AddStartPointBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(142)))), ((int)(((byte)(60)))));
            this.AddStartPointBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.AddStartPointBtn.FlatAppearance.BorderSize = 0;
            this.AddStartPointBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.AddStartPointBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(117)))), ((int)(((byte)(50)))));
            this.AddStartPointBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddStartPointBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.AddStartPointBtn.Location = new System.Drawing.Point(98, 61);
            this.AddStartPointBtn.Name = "AddStartPointBtn";
            this.AddStartPointBtn.Size = new System.Drawing.Size(430, 23);
            this.AddStartPointBtn.TabIndex = 19;
            this.AddStartPointBtn.Text = "Add Start Point";
            this.AddStartPointBtn.UseVisualStyleBackColor = false;
            this.AddStartPointBtn.Click += new System.EventHandler(this.AddStartPointBtn_Click);
            // 
            // StartPointLongBox
            // 
            this.StartPointLongBox.Location = new System.Drawing.Point(363, 34);
            this.StartPointLongBox.Name = "StartPointLongBox";
            this.StartPointLongBox.Size = new System.Drawing.Size(165, 22);
            this.StartPointLongBox.TabIndex = 18;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(272, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 16);
            this.label3.TabIndex = 17;
            this.label3.Text = "Longitude";
            // 
            // StartPointLatBox
            // 
            this.StartPointLatBox.Location = new System.Drawing.Point(98, 34);
            this.StartPointLatBox.Name = "StartPointLatBox";
            this.StartPointLatBox.Size = new System.Drawing.Size(165, 22);
            this.StartPointLatBox.TabIndex = 16;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 37);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 16);
            this.label4.TabIndex = 15;
            this.label4.Text = "Latitude";
            // 
            // StartPointNameComboBox
            // 
            this.StartPointNameComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.StartPointNameComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.StartPointNameComboBox.FormattingEnabled = true;
            this.StartPointNameComboBox.Location = new System.Drawing.Point(98, 5);
            this.StartPointNameComboBox.Name = "StartPointNameComboBox";
            this.StartPointNameComboBox.Size = new System.Drawing.Size(430, 24);
            this.StartPointNameComboBox.TabIndex = 14;
            this.StartPointNameComboBox.SelectedIndexChanged += new System.EventHandler(this.StartPointNameComboBox_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 8);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 16);
            this.label5.TabIndex = 13;
            this.label5.Text = "Start Point";
            // 
            // RoutesTab
            // 
            this.RoutesTab.Controls.Add(this.ProcessPanel);
            this.RoutesTab.Location = new System.Drawing.Point(4, 22);
            this.RoutesTab.Name = "RoutesTab";
            this.RoutesTab.Padding = new System.Windows.Forms.Padding(3);
            this.RoutesTab.Size = new System.Drawing.Size(909, 425);
            this.RoutesTab.TabIndex = 1;
            this.RoutesTab.Text = "Routes";
            this.RoutesTab.UseVisualStyleBackColor = true;
            // 
            // ProcessPanel
            // 
            this.ProcessPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.ProcessPanel.Controls.Add(this.FilesNotCreatedLabel);
            this.ProcessPanel.Controls.Add(this.label9);
            this.ProcessPanel.Controls.Add(this.FilesCreatedLabel);
            this.ProcessPanel.Controls.Add(this.label8);
            this.ProcessPanel.Controls.Add(this.StartCreatingFilesButton);
            this.ProcessPanel.Controls.Add(this.RouteCombinationsLabel);
            this.ProcessPanel.Controls.Add(this.label6);
            this.ProcessPanel.Controls.Add(this.FilesGridPanel);
            this.ProcessPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ProcessPanel.Location = new System.Drawing.Point(3, 3);
            this.ProcessPanel.Name = "ProcessPanel";
            this.ProcessPanel.Size = new System.Drawing.Size(903, 419);
            this.ProcessPanel.TabIndex = 3;
            // 
            // FilesNotCreatedLabel
            // 
            this.FilesNotCreatedLabel.AutoSize = true;
            this.FilesNotCreatedLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.FilesNotCreatedLabel.Location = new System.Drawing.Point(857, 386);
            this.FilesNotCreatedLabel.Name = "FilesNotCreatedLabel";
            this.FilesNotCreatedLabel.Size = new System.Drawing.Size(15, 16);
            this.FilesNotCreatedLabel.TabIndex = 36;
            this.FilesNotCreatedLabel.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(774, 386);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 16);
            this.label9.TabIndex = 35;
            this.label9.Text = "Not Created";
            // 
            // FilesCreatedLabel
            // 
            this.FilesCreatedLabel.AutoSize = true;
            this.FilesCreatedLabel.Location = new System.Drawing.Point(700, 386);
            this.FilesCreatedLabel.Name = "FilesCreatedLabel";
            this.FilesCreatedLabel.Size = new System.Drawing.Size(15, 16);
            this.FilesCreatedLabel.TabIndex = 34;
            this.FilesCreatedLabel.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(611, 386);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 16);
            this.label8.TabIndex = 33;
            this.label8.Text = "Files Created";
            // 
            // StartCreatingFilesButton
            // 
            this.StartCreatingFilesButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(142)))), ((int)(((byte)(60)))));
            this.StartCreatingFilesButton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.StartCreatingFilesButton.FlatAppearance.BorderSize = 0;
            this.StartCreatingFilesButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.StartCreatingFilesButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(117)))), ((int)(((byte)(50)))));
            this.StartCreatingFilesButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.StartCreatingFilesButton.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.StartCreatingFilesButton.Location = new System.Drawing.Point(310, 379);
            this.StartCreatingFilesButton.Name = "StartCreatingFilesButton";
            this.StartCreatingFilesButton.Size = new System.Drawing.Size(295, 29);
            this.StartCreatingFilesButton.TabIndex = 32;
            this.StartCreatingFilesButton.Text = "Start Creating Routes Combination Files";
            this.StartCreatingFilesButton.UseVisualStyleBackColor = false;
            this.StartCreatingFilesButton.Click += new System.EventHandler(this.StartCreatingFilesButton_Click);
            // 
            // RouteCombinationsLabel
            // 
            this.RouteCombinationsLabel.AutoSize = true;
            this.RouteCombinationsLabel.Location = new System.Drawing.Point(135, 386);
            this.RouteCombinationsLabel.Name = "RouteCombinationsLabel";
            this.RouteCombinationsLabel.Size = new System.Drawing.Size(15, 16);
            this.RouteCombinationsLabel.TabIndex = 31;
            this.RouteCombinationsLabel.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 386);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(129, 16);
            this.label6.TabIndex = 30;
            this.label6.Text = "Route Combinations";
            // 
            // FilesGridPanel
            // 
            this.FilesGridPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.FilesGridPanel.Controls.Add(this.FilesGridView);
            this.FilesGridPanel.Location = new System.Drawing.Point(5, 7);
            this.FilesGridPanel.Name = "FilesGridPanel";
            this.FilesGridPanel.Size = new System.Drawing.Size(895, 366);
            this.FilesGridPanel.TabIndex = 29;
            // 
            // FilesGridView
            // 
            this.FilesGridView.AllowUserToAddRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(142)))), ((int)(((byte)(60)))));
            this.FilesGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.FilesGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.FilesGridView.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.FilesGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.FilesGridView.CausesValidation = false;
            this.FilesGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(142)))), ((int)(((byte)(60)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.FilesGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.FilesGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.FilesGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SelectAllColumn,
            this.StartPointColumn,
            this.EndPointColumn,
            this.RouteDataColumn,
            this.StatusColumn,
            this.UploadedColumn});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(229)))), ((int)(((byte)(252)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.FilesGridView.DefaultCellStyle = dataGridViewCellStyle3;
            this.FilesGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FilesGridView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke;
            this.FilesGridView.EnableHeadersVisualStyles = false;
            this.FilesGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(187)))), ((int)(((byte)(102)))));
            this.FilesGridView.Location = new System.Drawing.Point(0, 0);
            this.FilesGridView.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.FilesGridView.Name = "FilesGridView";
            this.FilesGridView.RowHeadersVisible = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.FilesGridView.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.FilesGridView.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.FilesGridView.Size = new System.Drawing.Size(893, 364);
            this.FilesGridView.TabIndex = 23;
            this.FilesGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.FilesGridView_CellContentClick);
            // 
            // SelectAllColumn
            // 
            this.SelectAllColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.SelectAllColumn.FillWeight = 35F;
            this.SelectAllColumn.HeaderText = "All";
            this.SelectAllColumn.Name = "SelectAllColumn";
            this.SelectAllColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.SelectAllColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.SelectAllColumn.Width = 35;
            // 
            // StartPointColumn
            // 
            this.StartPointColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.StartPointColumn.FillWeight = 200F;
            this.StartPointColumn.HeaderText = "Start Point";
            this.StartPointColumn.Name = "StartPointColumn";
            this.StartPointColumn.Width = 200;
            // 
            // EndPointColumn
            // 
            this.EndPointColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.EndPointColumn.FillWeight = 200F;
            this.EndPointColumn.HeaderText = "End Point";
            this.EndPointColumn.Name = "EndPointColumn";
            this.EndPointColumn.Width = 200;
            // 
            // RouteDataColumn
            // 
            this.RouteDataColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.RouteDataColumn.FillWeight = 300F;
            this.RouteDataColumn.HeaderText = "Route Data";
            this.RouteDataColumn.Name = "RouteDataColumn";
            // 
            // StatusColumn
            // 
            this.StatusColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.StatusColumn.FillWeight = 80F;
            this.StatusColumn.HeaderText = "Status";
            this.StatusColumn.Name = "StatusColumn";
            this.StatusColumn.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.StatusColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.StatusColumn.Width = 80;
            // 
            // UploadedColumn
            // 
            this.UploadedColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.UploadedColumn.FillWeight = 80F;
            this.UploadedColumn.HeaderText = "Upload";
            this.UploadedColumn.Name = "UploadedColumn";
            this.UploadedColumn.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.UploadedColumn.Width = 80;
            // 
            // VehiclesTab
            // 
            this.VehiclesTab.Controls.Add(this.panel1);
            this.VehiclesTab.Location = new System.Drawing.Point(4, 25);
            this.VehiclesTab.Name = "VehiclesTab";
            this.VehiclesTab.Padding = new System.Windows.Forms.Padding(3);
            this.VehiclesTab.Size = new System.Drawing.Size(909, 422);
            this.VehiclesTab.TabIndex = 2;
            this.VehiclesTab.Text = "Vehicles";
            this.VehiclesTab.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Controls.Add(this.panel11);
            this.panel1.Controls.Add(this.panel12);
            this.panel1.Controls.Add(this.panel13);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(903, 416);
            this.panel1.TabIndex = 3;
            // 
            // panel8
            // 
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.label21);
            this.panel8.Controls.Add(this.DeleteVehicleNameCBox);
            this.panel8.Controls.Add(this.DeleteSelectedVehicleBtn);
            this.panel8.Controls.Add(this.label18);
            this.panel8.Controls.Add(this.DeleteVehicleVehicleTypeCBox);
            this.panel8.Location = new System.Drawing.Point(6, 309);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(892, 100);
            this.panel8.TabIndex = 32;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(2, 38);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(93, 16);
            this.label21.TabIndex = 13;
            this.label21.Text = "Vehicle Name";
            // 
            // DeleteVehicleNameCBox
            // 
            this.DeleteVehicleNameCBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.DeleteVehicleNameCBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.DeleteVehicleNameCBox.FormattingEnabled = true;
            this.DeleteVehicleNameCBox.Location = new System.Drawing.Point(98, 36);
            this.DeleteVehicleNameCBox.Name = "DeleteVehicleNameCBox";
            this.DeleteVehicleNameCBox.Size = new System.Drawing.Size(787, 24);
            this.DeleteVehicleNameCBox.TabIndex = 14;
            // 
            // DeleteSelectedVehicleBtn
            // 
            this.DeleteSelectedVehicleBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(142)))), ((int)(((byte)(60)))));
            this.DeleteSelectedVehicleBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.DeleteSelectedVehicleBtn.FlatAppearance.BorderSize = 0;
            this.DeleteSelectedVehicleBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.DeleteSelectedVehicleBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(117)))), ((int)(((byte)(50)))));
            this.DeleteSelectedVehicleBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DeleteSelectedVehicleBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.DeleteSelectedVehicleBtn.Location = new System.Drawing.Point(98, 67);
            this.DeleteSelectedVehicleBtn.Name = "DeleteSelectedVehicleBtn";
            this.DeleteSelectedVehicleBtn.Size = new System.Drawing.Size(787, 23);
            this.DeleteSelectedVehicleBtn.TabIndex = 12;
            this.DeleteSelectedVehicleBtn.Text = "Delete Selected Vehicle";
            this.DeleteSelectedVehicleBtn.UseVisualStyleBackColor = false;
            this.DeleteSelectedVehicleBtn.Click += new System.EventHandler(this.DeleteSelectedVehicleBtn_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(2, 8);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(88, 16);
            this.label18.TabIndex = 0;
            this.label18.Text = "Vehicle Type";
            // 
            // DeleteVehicleVehicleTypeCBox
            // 
            this.DeleteVehicleVehicleTypeCBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.DeleteVehicleVehicleTypeCBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.DeleteVehicleVehicleTypeCBox.FormattingEnabled = true;
            this.DeleteVehicleVehicleTypeCBox.Location = new System.Drawing.Point(98, 6);
            this.DeleteVehicleVehicleTypeCBox.Name = "DeleteVehicleVehicleTypeCBox";
            this.DeleteVehicleVehicleTypeCBox.Size = new System.Drawing.Size(787, 24);
            this.DeleteVehicleVehicleTypeCBox.TabIndex = 1;
            this.DeleteVehicleVehicleTypeCBox.SelectedIndexChanged += new System.EventHandler(this.DeleteVehicleVehicleTypeCBox_SelectedIndexChanged);
            // 
            // panel11
            // 
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.AddNewVehicleEndPointBox);
            this.panel11.Controls.Add(this.label17);
            this.panel11.Controls.Add(this.AddNewVehicleStartPointBox);
            this.panel11.Controls.Add(this.label10);
            this.panel11.Controls.Add(this.AddNewVehicleNameBox);
            this.panel11.Controls.Add(this.label7);
            this.panel11.Controls.Add(this.AddNewVehicleVehicleTypeCBox);
            this.panel11.Controls.Add(this.AddNewVehicleBtn);
            this.panel11.Controls.Add(this.label19);
            this.panel11.Location = new System.Drawing.Point(6, 151);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(892, 152);
            this.panel11.TabIndex = 31;
            // 
            // AddNewVehicleEndPointBox
            // 
            this.AddNewVehicleEndPointBox.Location = new System.Drawing.Point(98, 92);
            this.AddNewVehicleEndPointBox.Name = "AddNewVehicleEndPointBox";
            this.AddNewVehicleEndPointBox.Size = new System.Drawing.Size(787, 22);
            this.AddNewVehicleEndPointBox.TabIndex = 26;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(1, 95);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(83, 16);
            this.label17.TabIndex = 25;
            this.label17.Text = "Ending Point";
            // 
            // AddNewVehicleStartPointBox
            // 
            this.AddNewVehicleStartPointBox.Location = new System.Drawing.Point(98, 64);
            this.AddNewVehicleStartPointBox.Name = "AddNewVehicleStartPointBox";
            this.AddNewVehicleStartPointBox.Size = new System.Drawing.Size(787, 22);
            this.AddNewVehicleStartPointBox.TabIndex = 24;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(1, 67);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(68, 16);
            this.label10.TabIndex = 23;
            this.label10.Text = "Start Point";
            // 
            // AddNewVehicleNameBox
            // 
            this.AddNewVehicleNameBox.Location = new System.Drawing.Point(98, 36);
            this.AddNewVehicleNameBox.Name = "AddNewVehicleNameBox";
            this.AddNewVehicleNameBox.Size = new System.Drawing.Size(786, 22);
            this.AddNewVehicleNameBox.TabIndex = 22;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(88, 16);
            this.label7.TabIndex = 20;
            this.label7.Text = "Vehicle Type";
            // 
            // AddNewVehicleVehicleTypeCBox
            // 
            this.AddNewVehicleVehicleTypeCBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.AddNewVehicleVehicleTypeCBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.AddNewVehicleVehicleTypeCBox.FormattingEnabled = true;
            this.AddNewVehicleVehicleTypeCBox.Location = new System.Drawing.Point(98, 6);
            this.AddNewVehicleVehicleTypeCBox.Name = "AddNewVehicleVehicleTypeCBox";
            this.AddNewVehicleVehicleTypeCBox.Size = new System.Drawing.Size(786, 24);
            this.AddNewVehicleVehicleTypeCBox.TabIndex = 21;
            // 
            // AddNewVehicleBtn
            // 
            this.AddNewVehicleBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(142)))), ((int)(((byte)(60)))));
            this.AddNewVehicleBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.AddNewVehicleBtn.FlatAppearance.BorderSize = 0;
            this.AddNewVehicleBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.AddNewVehicleBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(117)))), ((int)(((byte)(50)))));
            this.AddNewVehicleBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddNewVehicleBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.AddNewVehicleBtn.Location = new System.Drawing.Point(98, 121);
            this.AddNewVehicleBtn.Name = "AddNewVehicleBtn";
            this.AddNewVehicleBtn.Size = new System.Drawing.Size(787, 23);
            this.AddNewVehicleBtn.TabIndex = 19;
            this.AddNewVehicleBtn.Text = "Add New Vehicle";
            this.AddNewVehicleBtn.UseVisualStyleBackColor = false;
            this.AddNewVehicleBtn.Click += new System.EventHandler(this.AddNewVehicleBtn_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(2, 39);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(93, 16);
            this.label19.TabIndex = 13;
            this.label19.Text = "Vehicle Name";
            // 
            // panel12
            // 
            this.panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel12.Controls.Add(this.DeleteSelectedVehicleTypeBtn);
            this.panel12.Controls.Add(this.label20);
            this.panel12.Controls.Add(this.DeleteVehicleTypeCBox);
            this.panel12.Location = new System.Drawing.Point(6, 79);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(892, 65);
            this.panel12.TabIndex = 30;
            // 
            // DeleteSelectedVehicleTypeBtn
            // 
            this.DeleteSelectedVehicleTypeBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(142)))), ((int)(((byte)(60)))));
            this.DeleteSelectedVehicleTypeBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.DeleteSelectedVehicleTypeBtn.FlatAppearance.BorderSize = 0;
            this.DeleteSelectedVehicleTypeBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.DeleteSelectedVehicleTypeBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(117)))), ((int)(((byte)(50)))));
            this.DeleteSelectedVehicleTypeBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DeleteSelectedVehicleTypeBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.DeleteSelectedVehicleTypeBtn.Location = new System.Drawing.Point(98, 34);
            this.DeleteSelectedVehicleTypeBtn.Name = "DeleteSelectedVehicleTypeBtn";
            this.DeleteSelectedVehicleTypeBtn.Size = new System.Drawing.Size(787, 23);
            this.DeleteSelectedVehicleTypeBtn.TabIndex = 12;
            this.DeleteSelectedVehicleTypeBtn.Text = "Delete Selected Vehicle Type";
            this.DeleteSelectedVehicleTypeBtn.UseVisualStyleBackColor = false;
            this.DeleteSelectedVehicleTypeBtn.Click += new System.EventHandler(this.DeleteSelectedVehicleTypeBtn_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(2, 8);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(88, 16);
            this.label20.TabIndex = 0;
            this.label20.Text = "Vehicle Type";
            // 
            // DeleteVehicleTypeCBox
            // 
            this.DeleteVehicleTypeCBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.DeleteVehicleTypeCBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.DeleteVehicleTypeCBox.FormattingEnabled = true;
            this.DeleteVehicleTypeCBox.Location = new System.Drawing.Point(98, 6);
            this.DeleteVehicleTypeCBox.Name = "DeleteVehicleTypeCBox";
            this.DeleteVehicleTypeCBox.Size = new System.Drawing.Size(787, 24);
            this.DeleteVehicleTypeCBox.TabIndex = 1;
            // 
            // panel13
            // 
            this.panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel13.Controls.Add(this.AddSelectedVehicleTypeBtn);
            this.panel13.Controls.Add(this.AddVehicleTypeBox);
            this.panel13.Controls.Add(this.label25);
            this.panel13.Location = new System.Drawing.Point(6, 7);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(892, 65);
            this.panel13.TabIndex = 29;
            // 
            // AddSelectedVehicleTypeBtn
            // 
            this.AddSelectedVehicleTypeBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(142)))), ((int)(((byte)(60)))));
            this.AddSelectedVehicleTypeBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.AddSelectedVehicleTypeBtn.FlatAppearance.BorderSize = 0;
            this.AddSelectedVehicleTypeBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.AddSelectedVehicleTypeBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(117)))), ((int)(((byte)(50)))));
            this.AddSelectedVehicleTypeBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddSelectedVehicleTypeBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.AddSelectedVehicleTypeBtn.Location = new System.Drawing.Point(98, 34);
            this.AddSelectedVehicleTypeBtn.Name = "AddSelectedVehicleTypeBtn";
            this.AddSelectedVehicleTypeBtn.Size = new System.Drawing.Size(787, 23);
            this.AddSelectedVehicleTypeBtn.TabIndex = 19;
            this.AddSelectedVehicleTypeBtn.Text = "Add New Vehicle Type";
            this.AddSelectedVehicleTypeBtn.UseVisualStyleBackColor = false;
            this.AddSelectedVehicleTypeBtn.Click += new System.EventHandler(this.AddSelectedVehicleTypeBtn_Click);
            // 
            // AddVehicleTypeBox
            // 
            this.AddVehicleTypeBox.Location = new System.Drawing.Point(98, 6);
            this.AddVehicleTypeBox.Name = "AddVehicleTypeBox";
            this.AddVehicleTypeBox.Size = new System.Drawing.Size(787, 22);
            this.AddVehicleTypeBox.TabIndex = 16;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(2, 8);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(88, 16);
            this.label25.TabIndex = 13;
            this.label25.Text = "Vehicle Type";
            // 
            // LocationsTab
            // 
            this.LocationsTab.Controls.Add(this.panel9);
            this.LocationsTab.Location = new System.Drawing.Point(4, 25);
            this.LocationsTab.Name = "LocationsTab";
            this.LocationsTab.Padding = new System.Windows.Forms.Padding(3);
            this.LocationsTab.Size = new System.Drawing.Size(909, 422);
            this.LocationsTab.TabIndex = 4;
            this.LocationsTab.Text = "Locations";
            this.LocationsTab.UseVisualStyleBackColor = true;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.panel9.Controls.Add(this.panel10);
            this.panel9.Controls.Add(this.panel15);
            this.panel9.Controls.Add(this.panel14);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(3, 3);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(903, 416);
            this.panel9.TabIndex = 4;
            // 
            // panel10
            // 
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.DeleteLocLongitudeBox);
            this.panel10.Controls.Add(this.label22);
            this.panel10.Controls.Add(this.DeleteLocLatitudeBox);
            this.panel10.Controls.Add(this.label23);
            this.panel10.Controls.Add(this.DeleteLocNameCBox);
            this.panel10.Controls.Add(this.DeleteSelectedLocBtn);
            this.panel10.Controls.Add(this.label31);
            this.panel10.Location = new System.Drawing.Point(5, 290);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(892, 122);
            this.panel10.TabIndex = 34;
            // 
            // DeleteLocLongitudeBox
            // 
            this.DeleteLocLongitudeBox.Location = new System.Drawing.Point(98, 64);
            this.DeleteLocLongitudeBox.Name = "DeleteLocLongitudeBox";
            this.DeleteLocLongitudeBox.Size = new System.Drawing.Size(787, 22);
            this.DeleteLocLongitudeBox.TabIndex = 24;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(1, 67);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(67, 16);
            this.label22.TabIndex = 23;
            this.label22.Text = "Longitude";
            // 
            // DeleteLocLatitudeBox
            // 
            this.DeleteLocLatitudeBox.Location = new System.Drawing.Point(98, 36);
            this.DeleteLocLatitudeBox.Name = "DeleteLocLatitudeBox";
            this.DeleteLocLatitudeBox.Size = new System.Drawing.Size(786, 22);
            this.DeleteLocLatitudeBox.TabIndex = 22;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(3, 9);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(45, 16);
            this.label23.TabIndex = 20;
            this.label23.Text = "Name";
            // 
            // DeleteLocNameCBox
            // 
            this.DeleteLocNameCBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.DeleteLocNameCBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.DeleteLocNameCBox.FormattingEnabled = true;
            this.DeleteLocNameCBox.Location = new System.Drawing.Point(98, 6);
            this.DeleteLocNameCBox.Name = "DeleteLocNameCBox";
            this.DeleteLocNameCBox.Size = new System.Drawing.Size(786, 24);
            this.DeleteLocNameCBox.TabIndex = 21;
            this.DeleteLocNameCBox.SelectedIndexChanged += new System.EventHandler(this.DeleteLocNameCBox_SelectedIndexChanged);
            // 
            // DeleteSelectedLocBtn
            // 
            this.DeleteSelectedLocBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(142)))), ((int)(((byte)(60)))));
            this.DeleteSelectedLocBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.DeleteSelectedLocBtn.FlatAppearance.BorderSize = 0;
            this.DeleteSelectedLocBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.DeleteSelectedLocBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(117)))), ((int)(((byte)(50)))));
            this.DeleteSelectedLocBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DeleteSelectedLocBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.DeleteSelectedLocBtn.Location = new System.Drawing.Point(98, 92);
            this.DeleteSelectedLocBtn.Name = "DeleteSelectedLocBtn";
            this.DeleteSelectedLocBtn.Size = new System.Drawing.Size(787, 23);
            this.DeleteSelectedLocBtn.TabIndex = 19;
            this.DeleteSelectedLocBtn.Text = "Delete Selected Location";
            this.DeleteSelectedLocBtn.UseVisualStyleBackColor = false;
            this.DeleteSelectedLocBtn.Click += new System.EventHandler(this.DeleteSelectedLocBtn_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(2, 39);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(55, 16);
            this.label31.TabIndex = 13;
            this.label31.Text = "Latitude";
            // 
            // panel15
            // 
            this.panel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel15.Controls.Add(this.UpdateLocationLatitudeRBtn);
            this.panel15.Controls.Add(this.UpdateLocationLongitudeRBtn);
            this.panel15.Controls.Add(this.UpdateLocationNameRBtn);
            this.panel15.Controls.Add(this.UpdateLocLongitudeBox);
            this.panel15.Controls.Add(this.label24);
            this.panel15.Controls.Add(this.UpdateLocLatitudeBox);
            this.panel15.Controls.Add(this.label29);
            this.panel15.Controls.Add(this.UpdateLocNameCBox);
            this.panel15.Controls.Add(this.UpdateSelectedLocBtn);
            this.panel15.Controls.Add(this.label30);
            this.panel15.Location = new System.Drawing.Point(5, 134);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(892, 150);
            this.panel15.TabIndex = 33;
            // 
            // UpdateLocLongitudeBox
            // 
            this.UpdateLocLongitudeBox.Location = new System.Drawing.Point(98, 64);
            this.UpdateLocLongitudeBox.Name = "UpdateLocLongitudeBox";
            this.UpdateLocLongitudeBox.Size = new System.Drawing.Size(787, 22);
            this.UpdateLocLongitudeBox.TabIndex = 24;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(1, 67);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(67, 16);
            this.label24.TabIndex = 23;
            this.label24.Text = "Longitude";
            // 
            // UpdateLocLatitudeBox
            // 
            this.UpdateLocLatitudeBox.Location = new System.Drawing.Point(98, 36);
            this.UpdateLocLatitudeBox.Name = "UpdateLocLatitudeBox";
            this.UpdateLocLatitudeBox.Size = new System.Drawing.Size(786, 22);
            this.UpdateLocLatitudeBox.TabIndex = 22;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(3, 9);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(45, 16);
            this.label29.TabIndex = 20;
            this.label29.Text = "Name";
            // 
            // UpdateLocNameCBox
            // 
            this.UpdateLocNameCBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.UpdateLocNameCBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.UpdateLocNameCBox.FormattingEnabled = true;
            this.UpdateLocNameCBox.Location = new System.Drawing.Point(98, 6);
            this.UpdateLocNameCBox.Name = "UpdateLocNameCBox";
            this.UpdateLocNameCBox.Size = new System.Drawing.Size(786, 24);
            this.UpdateLocNameCBox.TabIndex = 21;
            this.UpdateLocNameCBox.SelectedIndexChanged += new System.EventHandler(this.UpdateLocNameCBox_SelectedIndexChanged);
            // 
            // UpdateSelectedLocBtn
            // 
            this.UpdateSelectedLocBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(142)))), ((int)(((byte)(60)))));
            this.UpdateSelectedLocBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.UpdateSelectedLocBtn.FlatAppearance.BorderSize = 0;
            this.UpdateSelectedLocBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.UpdateSelectedLocBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(117)))), ((int)(((byte)(50)))));
            this.UpdateSelectedLocBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.UpdateSelectedLocBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.UpdateSelectedLocBtn.Location = new System.Drawing.Point(98, 119);
            this.UpdateSelectedLocBtn.Name = "UpdateSelectedLocBtn";
            this.UpdateSelectedLocBtn.Size = new System.Drawing.Size(787, 23);
            this.UpdateSelectedLocBtn.TabIndex = 19;
            this.UpdateSelectedLocBtn.Text = "Update Selected Location";
            this.UpdateSelectedLocBtn.UseVisualStyleBackColor = false;
            this.UpdateSelectedLocBtn.Click += new System.EventHandler(this.UpdateSelectedLocBtn_Click);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(2, 39);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(55, 16);
            this.label30.TabIndex = 13;
            this.label30.Text = "Latitude";
            // 
            // panel14
            // 
            this.panel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel14.Controls.Add(this.AddLocNameBox);
            this.panel14.Controls.Add(this.AddLocLongitudeBox);
            this.panel14.Controls.Add(this.label26);
            this.panel14.Controls.Add(this.AddLocLatitudeBox);
            this.panel14.Controls.Add(this.label27);
            this.panel14.Controls.Add(this.AddNewLocBtn);
            this.panel14.Controls.Add(this.label28);
            this.panel14.Location = new System.Drawing.Point(6, 7);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(892, 122);
            this.panel14.TabIndex = 31;
            // 
            // AddLocLongitudeBox
            // 
            this.AddLocLongitudeBox.Location = new System.Drawing.Point(98, 64);
            this.AddLocLongitudeBox.Name = "AddLocLongitudeBox";
            this.AddLocLongitudeBox.Size = new System.Drawing.Size(787, 22);
            this.AddLocLongitudeBox.TabIndex = 24;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(1, 67);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(67, 16);
            this.label26.TabIndex = 23;
            this.label26.Text = "Longitude";
            // 
            // AddLocLatitudeBox
            // 
            this.AddLocLatitudeBox.Location = new System.Drawing.Point(98, 36);
            this.AddLocLatitudeBox.Name = "AddLocLatitudeBox";
            this.AddLocLatitudeBox.Size = new System.Drawing.Size(786, 22);
            this.AddLocLatitudeBox.TabIndex = 22;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(3, 9);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(45, 16);
            this.label27.TabIndex = 20;
            this.label27.Text = "Name";
            // 
            // AddNewLocBtn
            // 
            this.AddNewLocBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(142)))), ((int)(((byte)(60)))));
            this.AddNewLocBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.AddNewLocBtn.FlatAppearance.BorderSize = 0;
            this.AddNewLocBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.AddNewLocBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(117)))), ((int)(((byte)(50)))));
            this.AddNewLocBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddNewLocBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.AddNewLocBtn.Location = new System.Drawing.Point(98, 92);
            this.AddNewLocBtn.Name = "AddNewLocBtn";
            this.AddNewLocBtn.Size = new System.Drawing.Size(787, 23);
            this.AddNewLocBtn.TabIndex = 19;
            this.AddNewLocBtn.Text = "Add New Location";
            this.AddNewLocBtn.UseVisualStyleBackColor = false;
            this.AddNewLocBtn.Click += new System.EventHandler(this.AddNewLocBtn_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(2, 39);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(55, 16);
            this.label28.TabIndex = 13;
            this.label28.Text = "Latitude";
            // 
            // SettingsTab
            // 
            this.SettingsTab.Controls.Add(this.panel16);
            this.SettingsTab.Location = new System.Drawing.Point(4, 25);
            this.SettingsTab.Name = "SettingsTab";
            this.SettingsTab.Padding = new System.Windows.Forms.Padding(3);
            this.SettingsTab.Size = new System.Drawing.Size(909, 422);
            this.SettingsTab.TabIndex = 3;
            this.SettingsTab.Text = "Settings";
            this.SettingsTab.UseVisualStyleBackColor = true;
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.panel16.Controls.Add(this.panel18);
            this.panel16.Controls.Add(this.panel19);
            this.panel16.Controls.Add(this.panel20);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel16.Location = new System.Drawing.Point(3, 3);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(903, 416);
            this.panel16.TabIndex = 4;
            // 
            // panel18
            // 
            this.panel18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel18.Controls.Add(this.SelectRootFolderDialogBtn);
            this.panel18.Controls.Add(this.UpdateRootFolderBox);
            this.panel18.Controls.Add(this.UpdateRootFolderBtn);
            this.panel18.Controls.Add(this.label34);
            this.panel18.Location = new System.Drawing.Point(6, 150);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(892, 65);
            this.panel18.TabIndex = 33;
            // 
            // UpdateRootFolderBox
            // 
            this.UpdateRootFolderBox.Location = new System.Drawing.Point(98, 6);
            this.UpdateRootFolderBox.Name = "UpdateRootFolderBox";
            this.UpdateRootFolderBox.Size = new System.Drawing.Size(671, 22);
            this.UpdateRootFolderBox.TabIndex = 17;
            // 
            // UpdateRootFolderBtn
            // 
            this.UpdateRootFolderBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(142)))), ((int)(((byte)(60)))));
            this.UpdateRootFolderBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.UpdateRootFolderBtn.FlatAppearance.BorderSize = 0;
            this.UpdateRootFolderBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.UpdateRootFolderBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(117)))), ((int)(((byte)(50)))));
            this.UpdateRootFolderBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.UpdateRootFolderBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.UpdateRootFolderBtn.Location = new System.Drawing.Point(98, 34);
            this.UpdateRootFolderBtn.Name = "UpdateRootFolderBtn";
            this.UpdateRootFolderBtn.Size = new System.Drawing.Size(787, 23);
            this.UpdateRootFolderBtn.TabIndex = 12;
            this.UpdateRootFolderBtn.Text = "Update Root Folder";
            this.UpdateRootFolderBtn.UseVisualStyleBackColor = false;
            this.UpdateRootFolderBtn.Click += new System.EventHandler(this.UpdateRootFolderBtn_Click);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(2, 8);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(79, 16);
            this.label34.TabIndex = 0;
            this.label34.Text = "Root Folder";
            // 
            // panel19
            // 
            this.panel19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel19.Controls.Add(this.UpdateFileExtensionBox);
            this.panel19.Controls.Add(this.UpdateFileExtensionBtn);
            this.panel19.Controls.Add(this.label38);
            this.panel19.Location = new System.Drawing.Point(6, 79);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(892, 65);
            this.panel19.TabIndex = 30;
            // 
            // UpdateFileExtensionBox
            // 
            this.UpdateFileExtensionBox.Location = new System.Drawing.Point(98, 6);
            this.UpdateFileExtensionBox.Name = "UpdateFileExtensionBox";
            this.UpdateFileExtensionBox.Size = new System.Drawing.Size(787, 22);
            this.UpdateFileExtensionBox.TabIndex = 17;
            // 
            // UpdateFileExtensionBtn
            // 
            this.UpdateFileExtensionBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(142)))), ((int)(((byte)(60)))));
            this.UpdateFileExtensionBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.UpdateFileExtensionBtn.FlatAppearance.BorderSize = 0;
            this.UpdateFileExtensionBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.UpdateFileExtensionBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(117)))), ((int)(((byte)(50)))));
            this.UpdateFileExtensionBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.UpdateFileExtensionBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.UpdateFileExtensionBtn.Location = new System.Drawing.Point(98, 34);
            this.UpdateFileExtensionBtn.Name = "UpdateFileExtensionBtn";
            this.UpdateFileExtensionBtn.Size = new System.Drawing.Size(787, 23);
            this.UpdateFileExtensionBtn.TabIndex = 12;
            this.UpdateFileExtensionBtn.Text = "Update File Extension";
            this.UpdateFileExtensionBtn.UseVisualStyleBackColor = false;
            this.UpdateFileExtensionBtn.Click += new System.EventHandler(this.UpdateFileExtensionBtn_Click);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(2, 8);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(91, 16);
            this.label38.TabIndex = 0;
            this.label38.Text = "File Extension";
            // 
            // panel20
            // 
            this.panel20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel20.Controls.Add(this.UpdateFileJoinBtn);
            this.panel20.Controls.Add(this.UpdateFileJoinBox);
            this.panel20.Controls.Add(this.label39);
            this.panel20.Location = new System.Drawing.Point(6, 7);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(892, 65);
            this.panel20.TabIndex = 29;
            // 
            // UpdateFileJoinBtn
            // 
            this.UpdateFileJoinBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(142)))), ((int)(((byte)(60)))));
            this.UpdateFileJoinBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.UpdateFileJoinBtn.FlatAppearance.BorderSize = 0;
            this.UpdateFileJoinBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.UpdateFileJoinBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(117)))), ((int)(((byte)(50)))));
            this.UpdateFileJoinBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.UpdateFileJoinBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.UpdateFileJoinBtn.Location = new System.Drawing.Point(98, 34);
            this.UpdateFileJoinBtn.Name = "UpdateFileJoinBtn";
            this.UpdateFileJoinBtn.Size = new System.Drawing.Size(787, 23);
            this.UpdateFileJoinBtn.TabIndex = 19;
            this.UpdateFileJoinBtn.Text = "Update File Join";
            this.UpdateFileJoinBtn.UseVisualStyleBackColor = false;
            this.UpdateFileJoinBtn.Click += new System.EventHandler(this.UpdateFileJoinBtn_Click);
            // 
            // UpdateFileJoinBox
            // 
            this.UpdateFileJoinBox.Location = new System.Drawing.Point(98, 6);
            this.UpdateFileJoinBox.Name = "UpdateFileJoinBox";
            this.UpdateFileJoinBox.Size = new System.Drawing.Size(787, 22);
            this.UpdateFileJoinBox.TabIndex = 16;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(2, 8);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(58, 16);
            this.label39.TabIndex = 13;
            this.label39.Text = "File Join";
            // 
            // RouteGenerator
            // 
            this.RouteGenerator.DoWork += new System.ComponentModel.DoWorkEventHandler(this.RouteGenerator_DoWork);
            this.RouteGenerator.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.RouteGenerator_RunWorkerCompleted);
            // 
            // RoutesIterator
            // 
            this.RoutesIterator.DoWork += new System.ComponentModel.DoWorkEventHandler(this.RoutesIterator_DoWork);
            this.RoutesIterator.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.RoutesIterator_RunWorkerCompleted);
            // 
            // AddLocNameBox
            // 
            this.AddLocNameBox.Location = new System.Drawing.Point(98, 6);
            this.AddLocNameBox.Name = "AddLocNameBox";
            this.AddLocNameBox.Size = new System.Drawing.Size(786, 22);
            this.AddLocNameBox.TabIndex = 25;
            // 
            // UpdateLocationNameRBtn
            // 
            this.UpdateLocationNameRBtn.AutoSize = true;
            this.UpdateLocationNameRBtn.Checked = true;
            this.UpdateLocationNameRBtn.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.UpdateLocationNameRBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Green;
            this.UpdateLocationNameRBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LimeGreen;
            this.UpdateLocationNameRBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.ForestGreen;
            this.UpdateLocationNameRBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.UpdateLocationNameRBtn.Location = new System.Drawing.Point(99, 92);
            this.UpdateLocationNameRBtn.Name = "UpdateLocationNameRBtn";
            this.UpdateLocationNameRBtn.Size = new System.Drawing.Size(164, 20);
            this.UpdateLocationNameRBtn.TabIndex = 25;
            this.UpdateLocationNameRBtn.TabStop = true;
            this.UpdateLocationNameRBtn.Text = "Update Location Name";
            this.UpdateLocationNameRBtn.UseVisualStyleBackColor = true;
            // 
            // UpdateLocationLongitudeRBtn
            // 
            this.UpdateLocationLongitudeRBtn.AutoSize = true;
            this.UpdateLocationLongitudeRBtn.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.UpdateLocationLongitudeRBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Green;
            this.UpdateLocationLongitudeRBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LimeGreen;
            this.UpdateLocationLongitudeRBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.ForestGreen;
            this.UpdateLocationLongitudeRBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.UpdateLocationLongitudeRBtn.Location = new System.Drawing.Point(699, 92);
            this.UpdateLocationLongitudeRBtn.Name = "UpdateLocationLongitudeRBtn";
            this.UpdateLocationLongitudeRBtn.Size = new System.Drawing.Size(186, 20);
            this.UpdateLocationLongitudeRBtn.TabIndex = 26;
            this.UpdateLocationLongitudeRBtn.Text = "Update Location Longitude";
            this.UpdateLocationLongitudeRBtn.UseVisualStyleBackColor = true;
            // 
            // UpdateLocationLatitudeRBtn
            // 
            this.UpdateLocationLatitudeRBtn.AutoSize = true;
            this.UpdateLocationLatitudeRBtn.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.UpdateLocationLatitudeRBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Green;
            this.UpdateLocationLatitudeRBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LimeGreen;
            this.UpdateLocationLatitudeRBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.ForestGreen;
            this.UpdateLocationLatitudeRBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.UpdateLocationLatitudeRBtn.Location = new System.Drawing.Point(397, 93);
            this.UpdateLocationLatitudeRBtn.Name = "UpdateLocationLatitudeRBtn";
            this.UpdateLocationLatitudeRBtn.Size = new System.Drawing.Size(174, 20);
            this.UpdateLocationLatitudeRBtn.TabIndex = 27;
            this.UpdateLocationLatitudeRBtn.Text = "Update Location Latitude";
            this.UpdateLocationLatitudeRBtn.UseVisualStyleBackColor = true;
            // 
            // SelectRootFolderDialogBtn
            // 
            this.SelectRootFolderDialogBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(142)))), ((int)(((byte)(60)))));
            this.SelectRootFolderDialogBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.SelectRootFolderDialogBtn.FlatAppearance.BorderSize = 0;
            this.SelectRootFolderDialogBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.SelectRootFolderDialogBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(117)))), ((int)(((byte)(50)))));
            this.SelectRootFolderDialogBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SelectRootFolderDialogBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.SelectRootFolderDialogBtn.Location = new System.Drawing.Point(775, 6);
            this.SelectRootFolderDialogBtn.Name = "SelectRootFolderDialogBtn";
            this.SelectRootFolderDialogBtn.Size = new System.Drawing.Size(110, 23);
            this.SelectRootFolderDialogBtn.TabIndex = 18;
            this.SelectRootFolderDialogBtn.Text = "Select Folder";
            this.SelectRootFolderDialogBtn.UseVisualStyleBackColor = false;
            this.SelectRootFolderDialogBtn.Click += new System.EventHandler(this.SelectRootFolderDialogBtn_Click);
            // 
            // MainForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.ClientSize = new System.Drawing.Size(917, 475);
            this.Controls.Add(this.Tabs);
            this.Controls.Add(this.MainMenu);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MainMenuStrip = this.MainMenu;
            this.Name = "MainForm";
            this.Text = "Ride";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.MainMenu.ResumeLayout(false);
            this.MainMenu.PerformLayout();
            this.Tabs.ResumeLayout(false);
            this.VehicleRouteTab.ResumeLayout(false);
            this.MainPanel.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.RoutesTab.ResumeLayout(false);
            this.ProcessPanel.ResumeLayout(false);
            this.ProcessPanel.PerformLayout();
            this.FilesGridPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.FilesGridView)).EndInit();
            this.VehiclesTab.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.LocationsTab.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.SettingsTab.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem menu1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menu2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menu3ToolStripMenuItem;
        private System.Windows.Forms.MenuStrip MainMenu;
        private System.Windows.Forms.TabControl Tabs;
        private System.Windows.Forms.TabPage VehicleRouteTab;
        private System.Windows.Forms.Panel MainPanel;
        private System.Windows.Forms.Button AddBusStopBtn;
        private System.Windows.Forms.TextBox BusStopLongitudeBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox BusStopLatitudeBox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox BusStopComboBox;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.RichTextBox RoutesRichBox;
        private System.Windows.Forms.Button GenerateRoutesXMLBtn;
        private System.Windows.Forms.Button GenerateVehicleXMLBtn;
        private System.Windows.Forms.TabPage RoutesTab;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button AddStartPointBtn;
        private System.Windows.Forms.TextBox StartPointLongBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox StartPointLatBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox StartPointNameComboBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.ComboBox VehicleNameComboBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox VehicleTypeComboBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button AddEndPointBtn;
        private System.Windows.Forms.TextBox EndPointLongBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox EndPointLatBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox EndPointNameComboBox;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel ProcessPanel;
        private System.Windows.Forms.Button FormatXMLBtn;
        private System.Windows.Forms.Panel FilesGridPanel;
        internal System.Windows.Forms.DataGridView FilesGridView;
        private System.Windows.Forms.Label RouteCombinationsLabel;
        private System.Windows.Forms.Label label6;
        private System.ComponentModel.BackgroundWorker RouteGenerator;
        private System.Windows.Forms.DataGridViewCheckBoxColumn SelectAllColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn StartPointColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn EndPointColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn RouteDataColumn;
        private System.Windows.Forms.DataGridViewButtonColumn StatusColumn;
        private System.Windows.Forms.DataGridViewButtonColumn UploadedColumn;
        private System.Windows.Forms.Button StartCreatingFilesButton;
        private System.ComponentModel.BackgroundWorker RoutesIterator;
        private System.Windows.Forms.Label FilesNotCreatedLabel;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label FilesCreatedLabel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ToolStripMenuItem addNewVehicleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewVehicleTypeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewLocationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setFileJoinToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setFileExtensionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setRootFolderToolStripMenuItem;
        private System.Windows.Forms.TabPage VehiclesTab;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button AddNewVehicleBtn;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Button DeleteSelectedVehicleTypeBtn;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox DeleteVehicleTypeCBox;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Button AddSelectedVehicleTypeBtn;
        private System.Windows.Forms.TextBox AddVehicleTypeBox;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox AddNewVehicleNameBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox AddNewVehicleVehicleTypeCBox;
        private System.Windows.Forms.TextBox AddNewVehicleEndPointBox;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox AddNewVehicleStartPointBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox DeleteVehicleNameCBox;
        private System.Windows.Forms.Button DeleteSelectedVehicleBtn;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox DeleteVehicleVehicleTypeCBox;
        private System.Windows.Forms.TabPage SettingsTab;
        private System.Windows.Forms.TabPage LocationsTab;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.TextBox AddLocLongitudeBox;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox AddLocLatitudeBox;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button AddNewLocBtn;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.TextBox UpdateLocLongitudeBox;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox UpdateLocLatitudeBox;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox UpdateLocNameCBox;
        private System.Windows.Forms.Button UpdateSelectedLocBtn;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TextBox DeleteLocLongitudeBox;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox DeleteLocLatitudeBox;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox DeleteLocNameCBox;
        private System.Windows.Forms.Button DeleteSelectedLocBtn;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Button UpdateFileExtensionBtn;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Button UpdateFileJoinBtn;
        private System.Windows.Forms.TextBox UpdateFileJoinBox;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Button UpdateRootFolderBtn;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox UpdateRootFolderBox;
        private System.Windows.Forms.TextBox UpdateFileExtensionBox;
        private System.Windows.Forms.ToolStripMenuItem deleteVehicleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteVehicleTypeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteLocationToolStripMenuItem;
        private System.Windows.Forms.TextBox AddLocNameBox;
        private System.Windows.Forms.RadioButton UpdateLocationLatitudeRBtn;
        private System.Windows.Forms.RadioButton UpdateLocationLongitudeRBtn;
        private System.Windows.Forms.RadioButton UpdateLocationNameRBtn;
        private System.Windows.Forms.Button SelectRootFolderDialogBtn;

    }
}