﻿using System;

namespace TransitTool
{
    class Locations
    {
        /// <summary>
        /// DataHandler is our class that we are using to get Data from Database
        /// </summary>
        DataHandler dataHandler;

        /// <summary>
        /// default constructor
        /// </summary>
        public Locations()
        {
            //InitilizeVariables will initilize our variables
            _InitilizeVariables();
        }

        /// <summary>
        /// Initilizing our important variables in this InitilizeVariables
        /// </summary>
        private void _InitilizeVariables()
        {
            dataHandler = new DataHandler();
            dataHandler.GetAllLocationsInfo(out LocationNames, out LocationLatitudes, out LocationLongitudes);
        }

        /// <summary>
        /// data is filled in these via InitilizeVariables() via Constructor
        /// </summary>
        string[] LocationNames;
        string[] LocationLatitudes;
        string[] LocationLongitudes;

        /// <summary>
        /// Returns only Location names via single dimensional array
        /// </summary>
        /// <returns>String array of Location names</returns>
        public string[] GetLocationNames()
        {
            return _GetLocationNames();
        }
        private string[] _GetLocationNames()
        {
            return LocationNames;
        }

        /// <summary>
        /// Returns only co-ordinates of given Location Name
        /// </summary>
        /// <param name="LocationName">Location Name</param>
        /// <param name="Latitude">Latitude of Location Name</param>
        /// <param name="Longitude">Longitude of Location Name</param>
        public void GetCoordinates(string LocationName, out decimal Latitude, out decimal Longitude)
        {
            _GetCoordinates(LocationName, out Latitude, out Longitude);
        }
        private void _GetCoordinates(string LocationName, out decimal Latitude, out decimal Longitude)
        {
            decimal ReturnLatitude = 0;
            decimal ReturnLongitude = 0;

            for (int i = 0; i < LocationNames.Length; i++)
            {
                string LocationFromArray = LocationNames[i];
                if (LocationName == LocationFromArray)
                {
                    //name is matched so get its other dimensions in our coordinates
                    //column 1 is latitudes & column 2 is longitudes
                    ReturnLatitude = Convert.ToDecimal(LocationLatitudes[i]);
                    ReturnLongitude = Convert.ToDecimal(LocationLongitudes[i]);

                    //match complete. no need for further loop. 
                    //so set it to array's length
                    i = LocationNames.Length;
                }
            }

            Latitude = ReturnLatitude;
            Longitude = ReturnLongitude;
        }

        public bool AddNewLocation(string LocationName, decimal Latitude, decimal Longitude)
        {
            return _AddNewLocation(LocationName, Latitude, Longitude);
        }
        private bool _AddNewLocation(string LocationName, decimal Latitude, decimal Longitude)
        {
            return dataHandler.AddNewLocation(LocationName, Latitude, Longitude);
        }

        public bool UpdateLocation(string LocationName, decimal Latitude, decimal Longitude, int WhoShouldBeUpdated)
        {
            return _UpdateLocation(LocationName, Latitude, Longitude, WhoShouldBeUpdated);
        }
        private bool _UpdateLocation(string LocationName, decimal Latitude, decimal Longitude, int WhoShouldBeUpdated)
        {
            if (WhoShouldBeUpdated == 1)
            {
                return dataHandler.UpdateLocationName(LocationName, Latitude, Longitude);
            }
            else if (WhoShouldBeUpdated == 2)
            {
                return dataHandler.UpdateLocationLatitude(dataHandler.GetLocationID(LocationName, Latitude, Longitude), Latitude);
            }
            else if (WhoShouldBeUpdated == 3)
            {
                return dataHandler.UpdateLocationLongitude(dataHandler.GetLocationID(LocationName, Latitude, Longitude), Longitude);
            }
            else return false;
        }

        public bool DeleteLocation(string LocationName, decimal Latitude, decimal Longitude)
        {
            return _DeleteLocation(LocationName, Latitude, Longitude);
        }
        private bool _DeleteLocation(string LocationName, decimal Latitude, decimal Longitude)
        {
            return dataHandler.DeleteLocation(dataHandler.GetLocationID(LocationName, Latitude, Longitude));
        }
    }
}
