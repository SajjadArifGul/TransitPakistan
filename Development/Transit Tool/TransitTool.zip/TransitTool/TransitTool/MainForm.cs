﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace TransitTool
{
    public partial class MainForm : Form
    {
        Vehicles vehicles; //Object of Vehicle Class
        Locations locations; //Object of Locations Class
        XMLHandler xmlHandler; //object of XMLHandler class
        Filer filer; //Object of Filer class
        Settings settings;  //Object of Settings class
        ServerFTP sftp;
        ArrayList globaldetails;


        public MainForm()
        {
            InitializeComponent();

            _InitilizeVariables();
        }

        private void _InitilizeVariables()
        {
            vehicles = new Vehicles();
            locations = new Locations();
            xmlHandler = new XMLHandler();
            filer = new Filer();
            settings = new Settings();
            sftp = new ServerFTP();
            globaldetails = new ArrayList();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            //method for Loading data in comoboboxes
            LoadComboBoxes();
        }

        //Load data in Comoboxes
        public void LoadComboBoxes()
        {
            //First clear all items in combo boxes if there are any.
            VehicleTypeComboBox.Items.Clear();
            StartPointNameComboBox.Items.Clear();
            EndPointNameComboBox.Items.Clear();
            DeleteVehicleTypeCBox.Items.Clear();
            AddNewVehicleVehicleTypeCBox.Items.Clear();
            DeleteVehicleVehicleTypeCBox.Items.Clear();
            UpdateLocNameCBox.Items.Clear();
            DeleteLocNameCBox.Items.Clear();

            //Add Data in Vehicle Type Comobobox
            VehicleTypeComboBox.Items.AddRange(vehicles.GetVehicleTypes());

            //Creating an array of Location Name.
            //Not doing it directly in comoboboxes because that would take extra iterations
            string[] LocationsArray = locations.GetLocationNames();

            //StartPoints Combobox Populating
            StartPointNameComboBox.Items.AddRange(LocationsArray);

            //BusStops Combobox Populating
            BusStopComboBox.Items.AddRange(LocationsArray);

            //EndPoints Combobox Populating
            EndPointNameComboBox.Items.AddRange(LocationsArray);

            DeleteVehicleTypeCBox.Items.AddRange(vehicles.GetVehicleTypes());
            AddNewVehicleVehicleTypeCBox.Items.AddRange(vehicles.GetVehicleTypes());
            DeleteVehicleVehicleTypeCBox.Items.AddRange(vehicles.GetVehicleTypes());

            UpdateLocNameCBox.Items.AddRange(locations.GetLocationNames());
            DeleteLocNameCBox.Items.AddRange(locations.GetLocationNames());

            UpdateFileJoinBox.Text = settings.GetFileJoin();
            UpdateFileExtensionBox.Text = settings.GetFileExtension();
            UpdateRootFolderBox.Text = settings.GetRootFolder();
            UpdateFTPUsernameBox.Text = settings.GetFTPUsername();
            UpdateFTPPasswordBox.Text = settings.GetFTPPassword();
        }

        //This method will be used to send back statuses according to its severity
        public void Status(string Message, int Severity)
        {
            //Severity should be from between 1-5
            //1-Success 2-Warning 3-Error 4-Remember 5-Important
            //tailor the message box according to severity

            MessageBox.Show(Message);
        }

        //To scroll down the routes richbox when new text added.
        public void ScrollDown()
        {
            RoutesRichBox.ScrollToCaret();
        }

        private void addNewVehicleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Tabs.SelectedTab = VehiclesTab;
        }

        private void addNewVehicleTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Tabs.SelectedTab = VehiclesTab;
        }

        private void addNewLocationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Tabs.SelectedTab = LocationsTab;
        }

        private void deleteVehicleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Tabs.SelectedTab = VehiclesTab;
        }

        private void deleteVehicleTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Tabs.SelectedTab = VehiclesTab;
        }

        private void deleteLocationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Tabs.SelectedTab = LocationsTab;
        }

        private void setFileJoinToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Tabs.SelectedTab = SettingsTab;
        }

        private void setFileExtensionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Tabs.SelectedTab = SettingsTab;
        }

        private void setRootFolderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Tabs.SelectedTab = SettingsTab;
        }

        private void VehicleTypeComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Clear if already populated data from Vehicle Name comobobox
            VehicleNameComboBox.Items.Clear();

            //Populate Vehicle Name comobobox with new selected vehicle type
            VehicleNameComboBox.Items.AddRange(vehicles.GetVehiclesByTypeName(VehicleTypeComboBox.Text));

            try
            {
                VehicleNameComboBox.Text = string.Empty;
                //Now Select a new first value by default becuase the previous vehicle type name is selected in combobox
                VehicleNameComboBox.SelectedIndex = 0;
            }
            catch
            {
                //This means there are no vehicles added to this vehcicle type in Database
                Status("No vehicle data available for " + VehicleTypeComboBox.SelectedItem.ToString() + ".", 3);
            }

            RoutesRichBox.Text = xmlHandler.SetVehicleType(RoutesRichBox.Text, VehicleTypeComboBox.SelectedItem.ToString());
            ScrollDown();
        }

        private void VehicleNameComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            RoutesRichBox.Text = xmlHandler.SetVehicleName(RoutesRichBox.Text, VehicleNameComboBox.SelectedItem.ToString());

            //check if this vehicle xml is already in database

            DataHandler dh = new DataHandler();

            string VehicleRouteXML = dh.GetVehicleRoute(VehicleNameComboBox.SelectedItem.ToString(), VehicleTypeComboBox.SelectedItem.ToString());

            if (VehicleRouteXML.Length > 2)
            {
                RoutesRichBox.Text = VehicleRouteXML;
            }

            ScrollDown();
        }

        private void AddFairsButton_Click(object sender, EventArgs e)
        {
            RoutesRichBox.Text = xmlHandler.SetRouteFair(RoutesRichBox.Text, RouteFairBox.Text, StopFairBox.Text);

            ScrollDown();
        }

        private void StartPointNameComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            decimal StartPointLatitude, StartPointLongitude;

            locations.GetCoordinates(StartPointNameComboBox.SelectedItem.ToString(), out StartPointLatitude, out StartPointLongitude);

            StartPointLatBox.Text = StartPointLatitude.ToString();
            StartPointLongBox.Text = StartPointLongitude.ToString();
        }

        private void AddStartPointBtn_Click(object sender, EventArgs e)
        {
            RoutesRichBox.Text = xmlHandler.SetStartPoint(RoutesRichBox.Text, StartPointNameComboBox.SelectedItem.ToString(), StartPointLatBox.Text, StartPointLongBox.Text);
        }

        private void BusStopComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            decimal BusStopLatitude, BusStopLongitude;

            locations.GetCoordinates(BusStopComboBox.SelectedItem.ToString(), out BusStopLatitude, out BusStopLongitude);

            BusStopLatitudeBox.Text = BusStopLatitude.ToString();
            BusStopLongitudeBox.Text = BusStopLongitude.ToString();
        }

        private void AddBusStopBtn_Click(object sender, EventArgs e)
        {
            //this variable is taken separately because we need to scroll down
            //the route rich box. Which doesnt work without AppenText method.
            //So i took this separetely, then empty the rich box & send this value to our bus stop method.
            string RichTextBoxText = RoutesRichBox.Text;
            RoutesRichBox.Text = null;
            RoutesRichBox.AppendText(xmlHandler.SetBusStop(RichTextBoxText, BusStopComboBox.SelectedItem.ToString(), BusStopLatitudeBox.Text, BusStopLongitudeBox.Text));
            ScrollDown();
        }

        private void EndPointNameComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            decimal EndPointLatitude, EndPointLongitude;

            locations.GetCoordinates(EndPointNameComboBox.SelectedItem.ToString(), out EndPointLatitude, out EndPointLongitude);

            EndPointLatBox.Text = EndPointLatitude.ToString();
            EndPointLongBox.Text = EndPointLongitude.ToString();
        }

        private void AddEndPointBtn_Click(object sender, EventArgs e)
        {
            //this variable is taken separately because we need to scroll down
            //the route rich box. Which doesnt work without AppendText method.
            //So i took this separetely, then empty the rich box & send this value to our bus stop method.
            string RichTextBoxText = RoutesRichBox.Text;
            RoutesRichBox.Text = null;
            RoutesRichBox.AppendText(xmlHandler.SetEndPoint(RichTextBoxText, EndPointNameComboBox.SelectedItem.ToString(), EndPointLatBox.Text, EndPointLongBox.Text));
            ScrollDown();
        }

        private void FormatXMLBtn_Click(object sender, EventArgs e)
        {
            try
            {
                RoutesRichBox.Text = xmlHandler.IdentateXML(xmlHandler.FormatVehicleXML(RoutesRichBox.Text));
            }
            catch (Exception ee)
            {
                Status(ee.Message, 3);
            }
        }

        private void GenerateVehicleXMLBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (vehicles.HandleVehicleRouteXML(RoutesRichBox.Text, xmlHandler.GetStartPointName(RoutesRichBox.Text), xmlHandler.GetEndPointName(RoutesRichBox.Text), xmlHandler.GetVehicleName(RoutesRichBox.Text), xmlHandler.GetVehicleType(RoutesRichBox.Text)))
                {
                    if (filer.CreateVehicleFile(RoutesRichBox.Text, xmlHandler.GetVehicleName(RoutesRichBox.Text), settings.GetFileExtension()))
                    {
                        Status("Vehicle Data Added to Database", 1);
                    }
                    else
                    {
                        Status("Sorry! Unable to Add Vehicle Route to Database.", 1);
                    }
                }
                else
                {
                    Status("Sorry! Unable to Add Vehicle Route to Database.", 1);
                }
            }
            catch (Exception ee)
            {
                Status(ee.Message, 3);
            }
        }

        private void GenerateRoutesXMLBtn_Click(object sender, EventArgs e)
        {
            FilesGridView.Rows.Clear();

            Tabs.SelectedTab = RoutesTab;

            string VehicleType = xmlHandler.GetVehicleType(RoutesRichBox.Text);
            string VehicleName = xmlHandler.GetVehicleName(RoutesRichBox.Text);
            string StopFair = xmlHandler.GetStopFair(RoutesRichBox.Text);

            RichBoxLines = RoutesRichBox.Lines;

            RouteGenerator.RunWorkerAsync(new Details() { VehicleType = VehicleType, VehicleName = VehicleName, StopFair = StopFair });
        }

        string[] RichBoxLines;

        private void RouteGenerator_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            Details details = (Details)e.Argument;

            string VehicleType = details.VehicleType;
            string VehicleName = details.VehicleName;
            string StopFair = details.StopFair;

            e.Result = xmlHandler.GenerateRoutes(RichBoxLines, VehicleType, VehicleName, StopFair);
        }

        private void RouteGenerator_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                // handle the error

                Status(e.Error.Message + e.Error.StackTrace, 1);
            }
            else if (e.Cancelled)
            {
                // handle cancellation
            }
            else
            {
                ArrayList DataList = (ArrayList)e.Result;

                RouteCombinationsLabel.Text = DataList.Count.ToString();

                foreach (Details details in DataList)
                {
                    FilesGridView.Rows.Add(true, details.StartPoint, details.EndPoint, details.Content);
                }
            }
        }

        private void FilesGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                if (FilesGridView.Columns[e.ColumnIndex].Name == "RouteDataColumn")
                {
                    Status(FilesGridView.Rows[e.RowIndex].Cells["RouteDataColumn"].Value.ToString(), 1);
                }
                else if (FilesGridView.Columns[e.ColumnIndex].Name == "StatusColumn")
                {
                    BackgroundWorker RouteFileCreator = new BackgroundWorker();
                    RouteFileCreator.DoWork += new DoWorkEventHandler(RouteFileCreator_DoWork);
                    RouteFileCreator.RunWorkerCompleted += (RouteFileCreator_RunWorkerCompleted);
                    RouteFileCreator.RunWorkerAsync(new Details() { RowNumber = e.RowIndex, VehicleName = xmlHandler.GetVehicleName(FilesGridView.Rows[e.RowIndex].Cells["RouteDataColumn"].Value.ToString()), Content = FilesGridView.Rows[e.RowIndex].Cells["RouteDataColumn"].Value.ToString(), StartPoint = FilesGridView.Rows[e.RowIndex].Cells["StartPointColumn"].Value.ToString(), EndPoint = FilesGridView.Rows[e.RowIndex].Cells["EndPointColumn"].Value.ToString(), RootFolder = settings.GetRootFolder(), Join = settings.GetFileJoin(), Extension = settings.GetFileExtension() });
                }
                if (FilesGridView.Columns[e.ColumnIndex].Name == "UploadedColumn")
                {
                    BackgroundWorker RouteFileUploader = new BackgroundWorker();
                    RouteFileUploader.DoWork += new DoWorkEventHandler(RouteFileUploader_DoWork);
                    RouteFileUploader.RunWorkerCompleted += (RouteFileUploader_RunWorkerCompleted);
                    RouteFileUploader.RunWorkerAsync(new Details() { RowNumber = e.RowIndex, VehicleName = xmlHandler.GetVehicleName(FilesGridView.Rows[e.RowIndex].Cells["RouteDataColumn"].Value.ToString()), Content = FilesGridView.Rows[e.RowIndex].Cells["RouteDataColumn"].Value.ToString(), StartPoint = FilesGridView.Rows[e.RowIndex].Cells["StartPointColumn"].Value.ToString(), EndPoint = FilesGridView.Rows[e.RowIndex].Cells["EndPointColumn"].Value.ToString(), RootFolder = settings.GetRootFolder(), Join = settings.GetFileJoin(), Extension = settings.GetFileExtension() });
                }
            }
        }

        private void RouteFileUploader_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            Details details = (Details)e.Argument;

            sftp.createDirectory("transit.pk" + "//" + "api" + "//" + "karachi" + "//" + "routes" + "//" + details.StartPoint.Standard());
            sftp.createDirectory("transit.pk" + "//" + "api" + "//" + "karachi" + "//" + "routes" + "//" + details.StartPoint.Standard() + "//" + details.EndPoint.Standard());

            string LocalFile = details.RootFolder + "\\" + details.StartPoint.Standard() + "\\" + details.EndPoint.Standard() + "\\" + details.StartPoint.Standard() + details.Join + details.EndPoint.Standard() + details.Extension;
            string RemoteFile = "transit.pk" + "//" + "api" + "//" + "karachi" + "//" + "routes" + "//" + details.StartPoint.Standard() + "//" + details.EndPoint.Standard() + "//" + details.StartPoint.Standard() + details.Join + details.EndPoint.Standard() + details.Extension;

            string LocalPHPFile = details.RootFolder + "\\" + details.StartPoint.Standard() + "\\" + details.EndPoint.Standard() + "\\" + "index.php";
            string RemotePHPFile = "transit.pk" + "//" + "api" + "//" + "karachi" + "//" + "routes" + "//" + details.StartPoint.Standard() + "//" + details.EndPoint.Standard() + "//" + "index.php";

            //first i want to upload the index.php file
            sftp.upload(RemotePHPFile, LocalPHPFile);

            e.Result = (new Details() { FileUploadedStatus = sftp.upload(RemoteFile, LocalFile), RowNumber = details.RowNumber });
        }
        private void RouteFileUploader_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                // handle the error

                Status(e.Error.Message + e.Error.StackTrace, 1);
            }
            else if (e.Cancelled)
            {
                // handle cancellation
            }
            else
            {
                Details details = (Details)e.Result;

                if (details.FileUploadedStatus)
                {
                    FilesGridView.Rows[details.RowNumber].Cells["UploadedColumn"].Value = "Uploaded";

                    if (FilesGridView.Rows[details.RowNumber].DefaultCellStyle.BackColor == Color.Red)
                    {
                        FilesGridView.Rows[details.RowNumber].DefaultCellStyle.BackColor = Color.FromArgb(76, 175, 80);
                    }
                }
                else
                {
                    FilesGridView.Rows[details.RowNumber].Cells["UploadedColumn"].Value = "Not Uploaded";
                    FilesGridView.Rows[details.RowNumber].DefaultCellStyle.BackColor = Color.Red;
                }
            }
        }

        private void RouteFileCreator_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            Details details = (Details)e.Argument;

            e.Result = (new Details() { FileCreatedStatus = filer.CreateRouteFile(details.VehicleName, details.Content, details.StartPoint, details.EndPoint, details.RootFolder, details.Join, details.Extension), RowNumber = details.RowNumber });
        }
        private void RouteFileCreator_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                // handle the error

                Status(e.Error.Message + e.Error.StackTrace, 1);
            }
            else if (e.Cancelled)
            {
                // handle cancellation
            }
            else
            {
                Details details = (Details)e.Result;

                FilesGridView.Rows[details.RowNumber].Cells["StatusColumn"].Value = details.FileCreatedStatus;

                if (details.FileCreatedStatus == "Not Created")
                {
                    FilesGridView.Rows[details.RowNumber].DefaultCellStyle.BackColor = Color.Red;
                }
                else if ((details.FileCreatedStatus == "Created") || (details.FileCreatedStatus == "Merged"))
                {
                    if (FilesGridView.Rows[details.RowNumber].DefaultCellStyle.BackColor == Color.Red)
                    {
                        FilesGridView.Rows[details.RowNumber].DefaultCellStyle.BackColor = Color.FromArgb(76, 175, 80);
                    }
                }
            }
        }

        private void StartCreatingFilesButton_Click(object sender, EventArgs e)
        {
            RoutesIterator.RunWorkerAsync();
        }

        private void RoutesIterator_DoWork(object sender, DoWorkEventArgs e)
        {
            foreach (DataGridViewRow Row in FilesGridView.Rows)
            {
                if (Convert.ToBoolean(FilesGridView.Rows[Row.Index].Cells["SelectAllColumn"].Value))
                {
                    BackgroundWorker RouteFileCreator = new BackgroundWorker();
                    RouteFileCreator.DoWork += new DoWorkEventHandler(RouteFileCreator_DoWork);
                    RouteFileCreator.RunWorkerCompleted += (RouteFileCreator_RunWorkerCompleted);
                    RouteFileCreator.RunWorkerAsync(new Details() { RowNumber = Row.Index, VehicleName = xmlHandler.GetVehicleName(Row.Cells["RouteDataColumn"].Value.ToString()), Content = Row.Cells["RouteDataColumn"].Value.ToString(), StartPoint = Row.Cells["StartPointColumn"].Value.ToString(), EndPoint = Row.Cells["EndPointColumn"].Value.ToString(), RootFolder = settings.GetRootFolder(), Join = settings.GetFileJoin(), Extension = settings.GetFileExtension() });
                }
            }
        }

        private void RoutesIterator_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                // handle the error

                Status(e.Error.Message + e.Error.StackTrace, 1);
            }
            else if (e.Cancelled)
            {
                // handle cancellation
            }
        }

        private void RoutesFileUploaderIterator_DoWork(object sender, DoWorkEventArgs e)
        {
            Details details = (Details)e.Argument;

            int RowNumber = details.FileUploadRowNumber;

            if (RowNumber < details.NumberOfRows)
            {
                if (Convert.ToBoolean(FilesGridView.Rows[RowNumber].Cells["SelectAllColumn"].Value))
                {
                    FilesGridView.Rows[RowNumber].Cells["UploadedColumn"].Value = "Working";

                    string StartPointName = FilesGridView.Rows[RowNumber].Cells["StartPointColumn"].Value.ToString().Standard();
                    string EndPointName = FilesGridView.Rows[RowNumber].Cells["EndPointColumn"].Value.ToString().Standard();

                    sftp.createDirectory("transit.pk" + "//" + "api" + "//" + "karachi" + "//" + "routes" + "//" + StartPointName);
                    sftp.createDirectory("transit.pk" + "//" + "api" + "//" + "karachi" + "//" + "routes" + "//" + StartPointName + "//" + EndPointName);

                    string LocalFile = details.RootFolder + "\\" + StartPointName + "\\" + EndPointName + "\\" + StartPointName + details.Join + EndPointName + details.Extension;
                    string RemoteFile = "transit.pk" + "//" + "api" + "//" + "karachi" + "//" + "routes" + "//" + StartPointName + "//" + EndPointName + "//" + StartPointName + details.Join + EndPointName + details.Extension;

                    string LocalPHPFile = details.RootFolder + "\\" + StartPointName + "\\" + EndPointName + "\\" + "index.php";
                    string RemotePHPFile = "transit.pk" + "//" + "api" + "//" + "karachi" + "//" + "routes" + "//" + StartPointName + "//" + EndPointName + "//" + "index.php";

                    //first i want to upload the index.php file
                    sftp.upload(RemotePHPFile, LocalPHPFile);

                    e.Result = (new Details() { FileUploadedStatus = sftp.upload(RemoteFile, LocalFile), FileUploadRowNumber = RowNumber, NumberOfRows = details.NumberOfRows });
                }
            }
            else
            {
                e.Result = (new Details() { FileUploadedStatus = false, FileUploadRowNumber = RowNumber, NumberOfRows = details.NumberOfRows });
            }
        }

        private void RoutesFileUploaderIterator_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                // handle the error

                Status(e.Error.Message + e.Error.StackTrace, 1);
            }
            else if (e.Cancelled)
            {
                // handle cancellation
            }
            else
            {
                Details details = (Details)e.Result;

                if (details.FileUploadRowNumber < details.NumberOfRows)
                {
                    if (details.FileUploadedStatus)
                    {
                        FilesGridView.Rows[details.FileUploadRowNumber].Cells["UploadedColumn"].Value = "Uploaded";

                        if (FilesGridView.Rows[details.FileUploadRowNumber].DefaultCellStyle.BackColor == Color.Red)
                        {
                            FilesGridView.Rows[details.FileUploadRowNumber].DefaultCellStyle.BackColor = Color.FromArgb(76, 175, 80);
                        }

                        BackgroundWorker RoutesFileUploaderIterator = new BackgroundWorker();
                        RoutesFileUploaderIterator.DoWork += new DoWorkEventHandler(RoutesFileUploaderIterator_DoWork);
                        RoutesFileUploaderIterator.RunWorkerCompleted += (RoutesFileUploaderIterator_RunWorkerCompleted);
                        RoutesFileUploaderIterator.RunWorkerAsync(new Details() { FileUploadRowNumber = details.FileUploadRowNumber + 1, RootFolder = settings.GetRootFolder(), Join = settings.GetFileJoin(), Extension = settings.GetFileExtension(), NumberOfRows = details.NumberOfRows });
                    }
                    else
                    {
                        FilesGridView.Rows[details.FileUploadRowNumber].Cells["UploadedColumn"].Value = "Not Uploaded";
                        FilesGridView.Rows[details.FileUploadRowNumber].DefaultCellStyle.BackColor = Color.Red;

                        if (details.FileUploadRowNumber < details.NumberOfRows)
                        {
                            BackgroundWorker RoutesFileUploaderIterator = new BackgroundWorker();
                            RoutesFileUploaderIterator.DoWork += new DoWorkEventHandler(RoutesFileUploaderIterator_DoWork);
                            RoutesFileUploaderIterator.RunWorkerCompleted += (RoutesFileUploaderIterator_RunWorkerCompleted);
                            RoutesFileUploaderIterator.RunWorkerAsync(new Details() { FileUploadRowNumber = details.FileUploadRowNumber + 1, RootFolder = settings.GetRootFolder(), Join = settings.GetFileJoin(), Extension = settings.GetFileExtension(), NumberOfRows = details.NumberOfRows });
                        }
                    }
                }
            }
        }

        private void AddSelectedVehicleTypeBtn_Click(object sender, EventArgs e)
        {
            if (vehicles.AddNewVehicleType(AddVehicleTypeBox.Text))
            {
                Status("Vehicle Type Added to Database.", 1);

                _InitilizeVariables();
                LoadComboBoxes();
            }
        }

        private void DeleteSelectedVehicleTypeBtn_Click(object sender, EventArgs e)
        {
            if (vehicles.DeleteVehicleType(DeleteVehicleTypeCBox.SelectedItem.ToString()))
            {
                Status("Vehicle Type Deleted from Database.", 1);

                _InitilizeVariables();
                LoadComboBoxes();
            }
        }

        private void AddNewVehicleBtn_Click(object sender, EventArgs e)
        {
            if (vehicles.AddNewVehicle(AddNewVehicleNameBox.Text, vehicles.GetVehicleTypeID(AddNewVehicleVehicleTypeCBox.SelectedItem.ToString())))
            {
                Status("New Vehicle added to Database.", 1);

                _InitilizeVariables();
                LoadComboBoxes();
            }
        }

        private void DeleteVehicleVehicleTypeCBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            DeleteVehicleNameCBox.Items.AddRange(vehicles.GetVehiclesByTypeName(DeleteVehicleVehicleTypeCBox.SelectedItem.ToString()));
        }

        private void DeleteSelectedVehicleBtn_Click(object sender, EventArgs e)
        {
            DeleteVehicle DeleteVehicleForm = new DeleteVehicle(DeleteVehicleNameCBox.SelectedItem.ToString(), DeleteVehicleVehicleTypeCBox.SelectedItem.ToString());

            DeleteVehicleForm.ShowDialog();

            //if (vehicles.DeleteVehicle(vehicles.GetVehicleTypeID(DeleteVehicleVehicleTypeCBox.SelectedItem.ToString()), DeleteVehicleNameCBox.SelectedItem.ToString()))
            //{
            //    Status("Selected Vehicle deleted from Database.", 1);

            //    _InitilizeVariables();
            //    LoadComboBoxes();
            //}
        }

        private void AddNewLocBtn_Click(object sender, EventArgs e)
        {
            if (locations.AddNewLocation(AddLocNameBox.Text, Convert.ToDecimal(AddLocLatitudeBox.Text), Convert.ToDecimal(AddLocLongitudeBox.Text)))
            {
                Status("New Location Details added to Database.", 1);

                _InitilizeVariables();
                LoadComboBoxes();
            }
        }

        private void UpdateLocNameCBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            decimal LocationLatitude, LocationLongitude;

            locations.GetCoordinates(UpdateLocNameCBox.SelectedItem.ToString(), out LocationLatitude, out LocationLongitude);

            UpdateLocLatitudeBox.Text = LocationLatitude.ToString();
            UpdateLocLongitudeBox.Text = LocationLongitude.ToString();
        }

        private void UpdateSelectedLocBtn_Click(object sender, EventArgs e)
        {
            int WhoShouldBeUpdated = 0;

            if (UpdateLocationNameRBtn.Checked)
            {
                WhoShouldBeUpdated = 1;
            }
            else if (UpdateLocationLatitudeRBtn.Checked)
            {
                WhoShouldBeUpdated = 2;
            }
            else if (UpdateLocationLongitudeRBtn.Checked)
            {
                WhoShouldBeUpdated = 3;
            }

            if (locations.UpdateLocation(UpdateLocNameCBox.Text, Convert.ToDecimal(UpdateLocLatitudeBox.Text), Convert.ToDecimal(UpdateLocLongitudeBox.Text), WhoShouldBeUpdated))
            {
                Status("Selected Location Details Updated.", 1);

                _InitilizeVariables();
                LoadComboBoxes();
            }
        }

        private void DeleteLocNameCBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            decimal LocationLatitude, LocationLongitude;

            locations.GetCoordinates(DeleteLocNameCBox.SelectedItem.ToString(), out LocationLatitude, out LocationLongitude);

            DeleteLocLatitudeBox.Text = LocationLatitude.ToString();
            DeleteLocLongitudeBox.Text = LocationLongitude.ToString();
        }

        private void DeleteSelectedLocBtn_Click(object sender, EventArgs e)
        {
            decimal LocationLatitude, LocationLongitude;

            locations.GetCoordinates(DeleteLocNameCBox.SelectedItem.ToString(), out LocationLatitude, out LocationLongitude);

            if (locations.DeleteLocation(DeleteLocNameCBox.SelectedItem.ToString(), LocationLatitude, LocationLongitude))
            {
                Status("Selected Location Details Deleted.", 1);

                _InitilizeVariables();
                LoadComboBoxes();
            }
        }

        private void CreateLocXMLFile_Click(object sender, EventArgs e)
        {
            if (filer.CreateLocationFile())
            {
                string LocationsLocalFile = "Locations\\Locations.xml";
                string LocationsRemoteFile = "transit.pk" + "//" + "api" + "//" + "karachi" + "//" + "locations//locations.xml";


                BackgroundWorker LocationsFileUploader = new BackgroundWorker();
                LocationsFileUploader.DoWork += new DoWorkEventHandler(LocationsFileUploader_DoWork);
                LocationsFileUploader.RunWorkerCompleted += (LocationsFileUploader_RunWorkerCompleted);
                LocationsFileUploader.RunWorkerAsync(new Details() { LocationsLocalFile = LocationsLocalFile, LocationsRemoteFile = LocationsRemoteFile });
            }
        }

        private void LocationsFileUploader_DoWork(object sender, DoWorkEventArgs e)
        {
            Details details = (Details)e.Argument;
            e.Result = (new Details() { LocationsFileUploadedStatus = sftp.upload(details.LocationsRemoteFile, details.LocationsLocalFile) });
        }

        private void LocationsFileUploader_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                // handle the error

                Status(e.Error.Message + e.Error.StackTrace, 1);
            }
            else if (e.Cancelled)
            {
                // handle cancellation
            }
            else
            {
                Details details = (Details)e.Result;

                if (details.LocationsFileUploadedStatus)
                {
                    Status("Locations file created & uploaded.", 1);
                }
                else Status("Locations file did not uploaded uploaded.", 1);
            }
        }

        private void UpdateFileJoinBtn_Click(object sender, EventArgs e)
        {
            if (settings.SetFileJoin(UpdateFileJoinBox.Text))
            {
                Status("File Join Setting Updated.", 1);

                _InitilizeVariables();
                LoadComboBoxes();
            }
        }

        private void UpdateFileExtensionBtn_Click(object sender, EventArgs e)
        {
            if (settings.SetFileExtension(UpdateFileExtensionBox.Text))
            {
                Status("File Extension Setting Updated.", 1);

                _InitilizeVariables();
                LoadComboBoxes();
            }
        }

        private void SelectRootFolderDialogBtn_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();

            if (fbd.ShowDialog() == DialogResult.OK)
            {
                UpdateRootFolderBox.Text = fbd.SelectedPath;
            }
        }

        private void UpdateRootFolderBtn_Click(object sender, EventArgs e)
        {
            if (settings.SetRootFolder(UpdateRootFolderBox.Text))
            {
                Status("Root Folder Setting Updated.", 1);

                _InitilizeVariables();
                LoadComboBoxes();
            }
        }

        private void UploadFilesButton_Click(object sender, EventArgs e)
        {
            int NumberOfRows = FilesGridView.RowCount;

            FilesGridView.Rows[0].Cells["UploadedColumn"].Value = "Working";

            BackgroundWorker RoutesFileUploaderIterator = new BackgroundWorker();
            RoutesFileUploaderIterator.DoWork += new DoWorkEventHandler(RoutesFileUploaderIterator_DoWork);
            RoutesFileUploaderIterator.RunWorkerCompleted += (RoutesFileUploaderIterator_RunWorkerCompleted);
            RoutesFileUploaderIterator.RunWorkerAsync(new Details() { FileUploadRowNumber = 0, RootFolder = settings.GetRootFolder(), Join = settings.GetFileJoin(), Extension = settings.GetFileExtension(), NumberOfRows = NumberOfRows });
        }

        private void UpdateFTPUsernameBtn_Click(object sender, EventArgs e)
        {

        }

        private void UpdateFTPPasswordBtn_Click(object sender, EventArgs e)
        {

        }
    }
}
