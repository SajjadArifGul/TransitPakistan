﻿using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace TransitTool
{
    class DataHandler
    {
        /// <summary>
        /// it is connection of our database. initilized in InitilizeVariables()
        /// </summary>
        string ConnectionString;

        /// <summary>
        /// default constructor
        /// </summary>
        public DataHandler()
        {
            _InitilizeVariables();
        }

        /// <summary>
        /// method to initilize important variables
        /// </summary>
        private void _InitilizeVariables()
        {
            ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["TransitDatabaseConnectionString"].ConnectionString;
        }

        /// <summary>
        /// will return arrays of Location Info with name & coordinates
        /// </summary>
        /// <param name="LocationNames">Location Names Array</param>
        /// <param name="LocationLatitudes">Location Latutudes Array</param>
        /// <param name="LocationLongitudes">Location Longitudes Array</param>
        public void GetAllLocationsInfo(out string[] LocationNames, out string[] LocationLatitudes, out string[] LocationLongitudes)
        {
            _GetAllLocationsInfo(out LocationNames, out LocationLatitudes, out LocationLongitudes);
        }
        //private : will return arrays of Location Info with name & coordinates
        private void _GetAllLocationsInfo(out string[] LocationNames, out string[] LocationLatitudes, out string[] LocationLongitudes)
        {
            List<string> LocationNamesList = new List<string>();
            List<string> LocationLatitudesList = new List<string>();
            List<string> LocationLongitudesList = new List<string>();

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();
                //Table name is Locations
                using (SqlCommand command = new SqlCommand("SelectAllLocations", con))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            //since Columns 0 is ID, Column 1 is Name, Column 2 is Latitude, Column 3 is Longitude
                            LocationNamesList.Add(reader.GetString(1));
                            LocationLatitudesList.Add(reader.GetDecimal(2).ToString());
                            LocationLongitudesList.Add(reader.GetDecimal(3).ToString());
                        }
                    }
                    con.Close();
                }
            }

            LocationNames = LocationNamesList.ToArray();
            LocationLatitudes = LocationLatitudesList.ToArray();
            LocationLongitudes = LocationLongitudesList.ToArray();

        }

        /// <summary>
        /// will return all available vehicle types from database
        /// </summary>
        /// <returns>VehicleTypes array</returns>
        public string[] GetAllVehicleTypes()
        {
            return _GetAllVehicleTypes();
        }
        //private : this will return all available vehicle types from database
        private string[] _GetAllVehicleTypes()
        {
            List<string> dataList = new List<string>();

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("SelectAllVehicleTypes", con))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            //since We want to return Vehicle Type Names only
                            //therefore sending 1. because column 0 is ID and column 1 is Name
                            dataList.Add(reader.GetString(1));
                        }
                    }
                    con.Close();
                }
            }

            return dataList.ToArray();
        }

        /// <summary>
        /// will return Array of vehicle names of given VehicleType from Database
        /// </summary>
        /// <param name="VehicleTypeName">VehicleType Name</param>
        /// <returns>Returns string array of Vehicle Type Names.</returns>
        public string[] GetVehiclesByTypeName(string VehicleTypeName)
        {
            return _GetVehiclesByTypeName(VehicleTypeName);
        }
        public string[] _GetVehiclesByTypeName(string VehicleTypeName)
        {
            //Get VehicleTypeID first & then send it to GetVehiclesByTypeID 
            return GetVehiclesByTypeID(GetVehicleTypeID(VehicleTypeName));
        }

        /// <summary>
        /// will return an Integer as ID of given VehicleType
        /// </summary>
        /// <param name="VehicleTypeName">Vehicle Type Name for which TypeID is required.</param>
        /// <returns>Integer TypeID of VehicleType Name</returns>
        public int GetVehicleTypeID(string VehicleTypeName)
        {
            return _GetVehicleTypeID(VehicleTypeName);
        }
        private int _GetVehicleTypeID(string VehicleTypeName)
        {
            //if there isnt any matching vehicle Type in DB
            //it will return 0 which is of Bus
            int ID = 0;

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("SELECT * FROM VehicleTypes where Name='" + VehicleTypeName + "'", con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        //column 0 is ID, column1 is Name
                        ID = reader.GetInt32(0);
                    }
                }
                con.Close();
            }

            return ID;
        }

        public int GetVehicleID(string VehicleName)
        {
            return _GetVehicleID(VehicleName);
        }
        private int _GetVehicleID(string VehicleName)
        {
            int ID = 0;

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("SELECT ID FROM Vehicles where Name='" + VehicleName + "'", con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        //column 0 is ID, column1 is Name
                        ID = reader.GetInt32(0);
                    }
                }
                con.Close();
            }

            return ID;
        }

        /// <summary>
        /// will return array of Vehicles name of given Vehicle TypeID
        /// </summary>
        /// <param name="TypeID">TypeID for which Vehicles are required.</param>
        /// <returns>Will return string array of Vehicle</returns>
        public string[] GetVehiclesByTypeID(int TypeID)
        {
            return _GetVehiclesByTypeID(TypeID);
        }
        private string[] _GetVehiclesByTypeID(int TypeID)
        {
            List<string> dataList = new List<string>();

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("SELECT * FROM Vehicles where TypeID='" + TypeID + "'", con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        //coulmn 0 is ID, coulmn 1 is TypeID & column 2 is Name.
                        //we need vehicle names thatswhy sending 2.
                        dataList.Add(reader.GetString(2));
                    }
                }
                con.Close();
            }

            return dataList.ToArray();
        }

        public int GetVehicleID(string VehicleName, string VehicleType)
        {
            return _GetVehicleID(VehicleName, VehicleType);
        }
        private int _GetVehicleID(string VehicleName, string VehicleType)
        {
            int ID = 0;

            int VehicleTypeID = _GetVehicleTypeID(VehicleType);

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("SELECT ID FROM Vehicles where Name='" + VehicleName + "'  and TypeID='" + VehicleTypeID + "'", con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        //column 0 is ID, column1 is Name
                        ID = reader.GetInt32(0);
                    }
                }
                con.Close();
            }

            return ID;
        }

        /// <summary>
        /// Will return settings from Database
        /// </summary>
        /// <param name="FileJoin">Join between 2 names of Locations for File Naming</param>
        /// <param name="FileExtension">Extension for the files to be created</param>
        /// <param name="RootFolder">Root folder is where all the files will be saved</param>
        public void GetSettings(out string FileJoin, out string FileExtension, out string RootFolder, out string FTPUsername, out string FTPPassword)
        {
            _GetSettings(out FileJoin, out FileExtension, out RootFolder, out FTPUsername, out FTPPassword);
        }
        private void _GetSettings(out string FileJoin, out string FileExtension, out string RootFolder, out string FTPUsername, out string FTPPassword)
        {
            int ID = 0;

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("SELECT MAX(ID) FROM Settings", con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        //column 0 is ID, column1 is Name
                        ID = reader.GetInt32(0);
                    }
                }
                con.Close();
            }

            //we now have Max ID. send it to get all other records
            string TempFileJoin = "", TempFileExtension = "", TempRootFolder = "", TempFTPUsername = "", TempFTPPassword="";

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("SELECT * FROM Settings where ID=" + ID + "", con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        TempFileJoin = reader.GetString(1);
                        TempFileExtension = reader.GetString(2);
                        TempRootFolder = reader.GetString(3);
                        TempFTPUsername = reader.GetString(4);
                        TempFTPPassword = reader.GetString(5);
                    }
                }
                con.Close();
            }

            FileJoin = TempFileJoin;
            FileExtension = TempFileExtension;
            RootFolder = TempRootFolder;
            FTPUsername = TempFTPUsername;
            FTPPassword = TempFTPPassword;
        }

        public bool AddVehicleType(string VehicleType)
        {
            return _AddVehicleType(VehicleType);
        }
        private bool _AddVehicleType(string VehicleType)
        {
            int NumberOfRowsAffected = 0;
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("Insert into VehicleTypes (Name) values ('" + VehicleType + "')", con))
                {
                    NumberOfRowsAffected = command.ExecuteNonQuery();
                }
                con.Close();
            }

            if (NumberOfRowsAffected > 0)
            {
                return true;
            }
            else return false;
        }

        public bool DeleteVehicleType(string VehicleType)
        {
            return _DeleteVehicleType(VehicleType);
        }
        private bool _DeleteVehicleType(string VehicleType)
        {
            int NumberOfRowsAffected = 0;
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("Delete from VehicleTypes where Name='" + VehicleType + "'", con))
                {
                    NumberOfRowsAffected = command.ExecuteNonQuery();
                }
                con.Close();
            }

            if (NumberOfRowsAffected > 0)
            {
                return true;
            }
            else return false;
        }

        public bool AddNewVehicle(string VehicleName, int TypeID)
        {
            return _AddNewVehicle(VehicleName, TypeID);
        }
        private bool _AddNewVehicle(string VehicleName, int TypeID)
        {
            int NumberOfRowsAffected = 0;
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("Insert into Vehicles (TypeID, Name) values ('" + TypeID + "','" + VehicleName + "')", con))
                {
                    NumberOfRowsAffected = command.ExecuteNonQuery();
                }
                con.Close();
            }

            if (NumberOfRowsAffected > 0)
            {
                return true;
            }
            else return false;
        }

        public bool AddRoute(string RouteXML, string StartPointName, string EndPointName, int VehicleID)
        {
            return _AddRoute(RouteXML, StartPointName, EndPointName, VehicleID);
        }
        private bool _AddRoute(string RouteXML, string StartPointName, string EndPointName, int VehicleID)
        {
            int NumberOfRowsAffected = 0;
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("update Routes set RouteXML = '" + RouteXML + "', StartPointName= '" + StartPointName + "', EndPointName='" + EndPointName + "' where VehicleID = '" + VehicleID + "'", con))
                {
                    NumberOfRowsAffected = command.ExecuteNonQuery();
                }
                con.Close();
            }

            if (NumberOfRowsAffected <= 0)
            {//this mean above query didnt update at that VehicleID because it is not in Table. so we add it.
                using (SqlConnection con = new SqlConnection(ConnectionString))
                {
                    con.Open();

                    using (SqlCommand command = new SqlCommand("Insert into Routes (RouteXML, StartPointName, EndPointName, VehicleID) values ('" + RouteXML + "','" + StartPointName + "','" + EndPointName + "', '" + VehicleID + "')", con))
                    {
                        NumberOfRowsAffected = command.ExecuteNonQuery();
                    }
                    con.Close();
                }
            }
            if (NumberOfRowsAffected > 0)
            {
                return true;
            }
            else return false;
        }

        public string GetVehicleRoute(string VehicleName, string VehicleType)
        {
            return _GetVehicleRoute(VehicleName, VehicleType);
        }
        public string _GetVehicleRoute(string VehicleName, string VehicleType)
        {
            string RouteXML = string.Empty;

            int VehicleID = _GetVehicleID(VehicleName, VehicleType);

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("SELECT RouteXML FROM Routes where VehicleID='" + VehicleID + "'", con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        RouteXML = reader.GetString(0);
                    }
                }
                con.Close();
            }

            return RouteXML;
        }

        public bool DeleteVehicle(string VehicleType, string VehicleName)
        {
            return _DeleteVehicle(VehicleType, VehicleName);
        }
        private bool _DeleteVehicle(string VehicleType, string VehicleName)
        {
            //giving error because of  foreign key of vehicles in routes table. so we will
            //first delete records from Routes Table.

            int VehicleID = _GetVehicleID(VehicleName, VehicleType);
            int TypeID = _GetVehicleTypeID(VehicleType);

            int NumberOfRowsAffected = 0;

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("Delete from Routes where VehicleID='" + VehicleID + "'", con))
                {
                    NumberOfRowsAffected = command.ExecuteNonQuery();
                }
                con.Close();
            }
            if (NumberOfRowsAffected > 0)
            {
                using (SqlConnection con = new SqlConnection(ConnectionString))
                {
                    con.Open();

                    using (SqlCommand command = new SqlCommand("Delete from Vehicles where TypeID='" + TypeID + "' and Name='" + VehicleName + "'", con))
                    {
                        NumberOfRowsAffected = command.ExecuteNonQuery();
                    }
                    con.Close();
                }
            }
            else return false;

            if (NumberOfRowsAffected > 0)
            {
                return true;
            }
            else return false;
        }

        public int GetLocationID(string LocationName, decimal Latitude, decimal Longitude)
        {
            return _GetLocationID(LocationName, Latitude, Longitude);
        }
        private int _GetLocationID(string LocationName, decimal Latitude, decimal Longitude)
        {
            int ID = 0;

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("SELECT * FROM Locations where Name='" + LocationName + "'  and Latitude='" + Latitude + "' and Longitude='" + Longitude + "' ", con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        //column 0 is ID, column1 is Name
                        ID = reader.GetInt32(0);
                    }
                }
                con.Close();
            }

            return ID;
        }

        public bool AddNewLocation(string LocationName, decimal Latitude, decimal Longitude)
        {
            return _AddNewLocation(LocationName, Latitude, Longitude);
        }
        private bool _AddNewLocation(string LocationName, decimal Latitude, decimal Longitude)
        {
            int NumberOfRowsAffected = 0;
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("Insert into Locations (Name, Latitude, Longitude) values ('" + LocationName + "', '" + Latitude + "', '" + Longitude + "')", con))
                {
                    NumberOfRowsAffected = command.ExecuteNonQuery();
                }
                con.Close();
            }

            if (NumberOfRowsAffected > 0)
            {
                return true;
            }
            else return false;
        }

        public bool UpdateLocationName(string LocationName, decimal Latitude, decimal Longitude)
        {
            return _UpdateLocationName(LocationName, Latitude, Longitude);
        }
        private bool _UpdateLocationName(string LocationName, decimal Latitude, decimal Longitude)
        {
            int NumberOfRowsAffected = 0;
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("Update Locations set Name='" + LocationName + "' where Latitude='" + Latitude + "' and Longitude='" + Longitude + "'", con))
                {
                    NumberOfRowsAffected = command.ExecuteNonQuery();
                }
                con.Close();
            }

            if (NumberOfRowsAffected > 0)
            {
                return true;
            }
            else return false;
        }

        public bool UpdateLocationLatitude(int LocationID, decimal Latitude)
        {
            return _UpdateLocationLatitude(LocationID, Latitude);
        }
        private bool _UpdateLocationLatitude(int LocationID, decimal Latitude)
        {
            int NumberOfRowsAffected = 0;
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("Update Locations set Latitude='" + Latitude + "' where ID='" + LocationID + "'", con))
                {
                    NumberOfRowsAffected = command.ExecuteNonQuery();
                }
                con.Close();
            }

            if (NumberOfRowsAffected > 0)
            {
                return true;
            }
            else return false;
        }

        public bool UpdateLocationLongitude(int LocationID, decimal Longitude)
        {
            return _UpdateLocationLongitude(LocationID, Longitude);
        }
        private bool _UpdateLocationLongitude(int LocationID, decimal Longitude)
        {
            int NumberOfRowsAffected = 0;
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("Update Locations set Longitude='" + Longitude + "' where ID='" + LocationID + "'", con))
                {
                    NumberOfRowsAffected = command.ExecuteNonQuery();
                }
                con.Close();
            }

            if (NumberOfRowsAffected > 0)
            {
                return true;
            }
            else return false;
        }

        public bool DeleteLocation(int LocationID)
        {
            return _DeleteLocation(LocationID);
        }
        private bool _DeleteLocation(int LocationID)
        {
            int NumberOfRowsAffected = 0;
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("Delete from Locations where ID='" + LocationID + "'", con))
                {
                    NumberOfRowsAffected = command.ExecuteNonQuery();
                }
                con.Close();
            }

            if (NumberOfRowsAffected > 0)
            {
                return true;
            }
            else return false;
        }

        public bool SetFileJoin(string FileJoin)
        {
            return _SetFileJoin(FileJoin);
        }
        private bool _SetFileJoin(string FileJoin)
        {
            int SettingsID = 0;

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("SELECT MAX(ID) FROM Settings", con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        //column 0 is ID, column1 is Name
                        SettingsID = reader.GetInt32(0);
                    }
                }
                con.Close();
            }

            int NumberOfRowsAffected = 0;
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("Update Settings set FileJoin='" + FileJoin + "' where ID='" + SettingsID + "'", con))
                {
                    NumberOfRowsAffected = command.ExecuteNonQuery();
                }
                con.Close();
            }

            if (NumberOfRowsAffected > 0)
            {
                return true;
            }
            else return false;
        }

        public bool SetFileExtension(string FileExtension)
        {
            return _SetFileExtension(FileExtension);
        }
        private bool _SetFileExtension(string FileExtension)
        {
            int SettingsID = 0;

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("SELECT MAX(ID) FROM Settings", con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        //column 0 is ID, column1 is Name
                        SettingsID = reader.GetInt32(0);
                    }
                }
                con.Close();
            }

            int NumberOfRowsAffected = 0;
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("Update Settings set FileExtension='" + FileExtension + "' where ID='" + SettingsID + "'", con))
                {
                    NumberOfRowsAffected = command.ExecuteNonQuery();
                }
                con.Close();
            }

            if (NumberOfRowsAffected > 0)
            {
                return true;
            }
            else return false;
        }

        public bool SetRootFolder(string RootFolder)
        {
            return _SetRootFolder(RootFolder);
        }
        private bool _SetRootFolder(string RootFolder)
        {
            int SettingsID = 0;

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("SELECT MAX(ID) FROM Settings", con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        //column 0 is ID, column1 is Name
                        SettingsID = reader.GetInt32(0);
                    }
                }
                con.Close();
            }

            int NumberOfRowsAffected = 0;
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("Update Settings set RootFolder='" + RootFolder + "' where ID='" + SettingsID + "'", con))
                {
                    NumberOfRowsAffected = command.ExecuteNonQuery();
                }
                con.Close();
            }

            if (NumberOfRowsAffected > 0)
            {
                return true;
            }
            else return false;
        }

        public bool AddRouteCombination(string StartPointName, string EndPointName, int VehicleID, string RouteXML, bool Override)
        {
            return _AddRouteCombination(StartPointName, EndPointName, VehicleID, RouteXML, Override);
        }
        private bool _AddRouteCombination(string StartPointName, string EndPointName, int VehicleID, string RouteXML, bool Override)
        {
            Locations _locations = new Locations();

            decimal StartPointLat, StartPointLong;
            decimal EndPointLat, EndPointLong;

            _locations.GetCoordinates(StartPointName, out StartPointLat, out StartPointLong);
            _locations.GetCoordinates(EndPointName, out EndPointLat, out EndPointLong);

            int StartPointID = _GetLocationID(StartPointName, StartPointLat, StartPointLong);
            int EndPointID = _GetLocationID(EndPointName, EndPointLat, EndPointLong);

            bool RecordExist = _RouteCombinationExists(StartPointID, EndPointID, VehicleID);

            int NumberOfRowsAffected = 0;

            if (RecordExist)
            {
                //this mean this record exist. We need to update it

                using (SqlConnection con = new SqlConnection(ConnectionString))
                {
                    con.Open();

                    using (SqlCommand command = new SqlCommand("update RouteCombinations set RouteXML = '" + RouteXML + "' where StartLocationID= '" + StartPointID + "' AND EndLocationID='" + EndPointID + "' AND VehicleID = '" + VehicleID + "'", con))
                    {
                        NumberOfRowsAffected = command.ExecuteNonQuery();
                    }
                    con.Close();
                }

                return true;
            }
            else if (!RecordExist)
            {
                //this record does not exist. We need to insert it
                using (SqlConnection con = new SqlConnection(ConnectionString))
                {
                    con.Open();

                    using (SqlCommand command = new SqlCommand("Insert into RouteCombinations (StartLocationID, EndLocationID, VehicleID, RouteXML) values ('" + StartPointID + "','" + EndPointID + "','" + VehicleID + "', '" + RouteXML + "')", con))
                    {
                        //remember this will always return -1 : set it if you want to use it in future : NumberOfRowsAffected
                        //https://msdn.microsoft.com/en-us/library/system.data.sqlclient.sqlcommand.executenonquery(v=vs.110).aspx
                        NumberOfRowsAffected = command.ExecuteNonQuery();
                    }
                    con.Close();
                }

                return true;
            }
            
            return false;
        }

        public bool RouteCombinationExists(int StartPointID, int EndPointID, int VehicleID)
        {
            return _RouteCombinationExists(StartPointID, EndPointID, VehicleID);
        }
        private bool _RouteCombinationExists(int StartPointID, int EndPointID, int VehicleID)
        {
            int NumberOfRecords = 0;

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("Select * from RouteCombinations where StartLocationID= '" + StartPointID + "' AND EndLocationID='" + EndPointID + "' AND VehicleID = '" + VehicleID + "'", con))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            NumberOfRecords++;
                        }
                    }
                }
                con.Close();
            }

            if (NumberOfRecords > 0)
            {
                return true;
            }

            else return false;
        }

        public ArrayList GetRouteData(int StartPointID, int EndPointID)
        {
            return _GetRouteData(StartPointID, EndPointID);
        }
        private ArrayList _GetRouteData(int StartPointID, int EndPointID)
        {
            ArrayList RouteData = new ArrayList();

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();
                using (SqlCommand command = new SqlCommand("Select RouteXML from RouteCombinations where StartLocationID= '" + StartPointID + "' AND EndLocationID='" + EndPointID + "'", con))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            RouteData.Add(reader.GetString(0));
                        }
                    }
                    con.Close();
                }
            }

            return RouteData;
        }

        public string FinalRouteData(ArrayList RouteData)
        {
            return _FinalRouteData(RouteData);
        }
        private string _FinalRouteData(ArrayList RouteData)
        {
            string RouteXML = string.Empty;

            foreach (string Node in RouteData)
            {
                //we have to remove Prolog XML etc from this node

                string NodeXML = Node;

                //first remove XML Prolog.
                NodeXML = NodeXML.Replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "");
                //Now remove Openning Route node
                NodeXML = NodeXML.Replace("<Route>", "");
                //Now remove Closing Route node
                NodeXML = NodeXML.Replace("</Route>", "");

                RouteXML = RouteXML + NodeXML + "\n";
            }

            //we now have RouteXML that we can write in the file but first we have to add XML Prolog etc

            XMLHandler xmlHandler = new XMLHandler();

            RouteXML = xmlHandler.IdentateXML(xmlHandler.FormatRouteXML(RouteXML));

            return RouteXML;
        }

        public string FinalVehicleXML(string VehicleType, string VehicleName)
        {
            int VehicleID = GetVehicleID(VehicleName, VehicleType);

            string VehicleXML = string.Empty;

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();
                using (SqlCommand command = new SqlCommand("Select RouteXML from Routes where VehicleID= '" + VehicleID + "'", con))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            VehicleXML = reader.GetString(0);
                        }
                    }
                    con.Close();
                }
            }

            return VehicleXML;
        }

        public bool SetFTPUsername(string FTPUsername)
        {
            return SetFTPUsername(FTPUsername);
        }
        private bool _SetFTPUsername(string FTPUsername)
        {
            int SettingsID = 0;

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("SELECT MAX(ID) FROM Settings", con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        //column 0 is ID, column1 is Name
                        SettingsID = reader.GetInt32(0);
                    }
                }
                con.Close();
            }

            int NumberOfRowsAffected = 0;
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("Update Settings set FTPUsername='" + FTPUsername + "' where ID='" + SettingsID + "'", con))
                {
                    NumberOfRowsAffected = command.ExecuteNonQuery();
                }
                con.Close();
            }

            if (NumberOfRowsAffected > 0)
            {
                return true;
            }
            else return false;
        }

        public bool SetFTPPassword(string FTPPassword)
        {
            return _SetFTPPassword(FTPPassword);
        }
        private bool _SetFTPPassword(string FTPPassword)
        {
            int SettingsID = 0;

            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("SELECT MAX(ID) FROM Settings", con))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        //column 0 is ID, column1 is Name
                        SettingsID = reader.GetInt32(0);
                    }
                }
                con.Close();
            }

            int NumberOfRowsAffected = 0;
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                con.Open();

                using (SqlCommand command = new SqlCommand("Update Settings set FTPPassword='" + FTPPassword + "' where ID='" + SettingsID + "'", con))
                {
                    NumberOfRowsAffected = command.ExecuteNonQuery();
                }
                con.Close();
            }

            if (NumberOfRowsAffected > 0)
            {
                return true;
            }
            else return false;
        }
    }
}
