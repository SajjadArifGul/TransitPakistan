﻿using System.Collections;
using System.IO;

namespace TransitTool
{
    class Filer
    {
        /// <summary>
        /// XML Handler class object.
        /// </summary>
        XMLHandler xmlHandler;
        DataHandler dataHandler;

        /// <summary>
        /// default constructor
        /// </summary>
        public Filer()
        {
            InitilizeVariables();
        }

        /// <summary>
        /// method to initilize important variables
        /// </summary>
        private void InitilizeVariables()
        {
            //because i dont want these 2 classes to go into looping each other
            xmlHandler = new XMLHandler("Dont Create AnyThing");
            dataHandler = new DataHandler();
        }

        /// <summary>
        /// Will create Vehicle File
        /// </summary>
        /// <param name="VehicleXML">XML to write into Vehicle File</param>
        /// <param name="VehicleName">Vehicle Name for naming file.</param>
        /// <param name="Extension">Extension of file to be created</param>
        public bool CreateVehicleFile(string VehicleXML, string VehicleName, string Extension)
        {
            return _CreateVehicleFile(VehicleXML, VehicleName, Extension, true);
        }
        /// <summary>
        /// Will create Vehicle File
        /// </summary>
        /// <param name="VehicleXML">XML to write into Vehicle File</param>
        /// <param name="VehicleName">Vehicle Name for naming file.</param>
        /// <param name="Extension">Extension of file to be created</param>
        /// <param name="Override">Override if files already exists ??</param>
        public bool CreateVehicleFile(string VehicleXML, string VehicleName, string Extension, bool Override)
        {
            return _CreateVehicleFile(VehicleXML, VehicleName, Extension, Override);
        }
        private bool _CreateVehicleFile(string VehicleXML, string VehicleName, string Extension, bool Override)
        {
            try
            {
                if (Override)
                {
                    if (Directory.Exists("Vehicles" + "\\" + VehicleName))
                    {
                        File.WriteAllText("Vehicles" +"\\"+ VehicleName + "\\" + VehicleName + Extension, VehicleXML);
                    }
                    else if (!Directory.Exists("Vehicles" + "\\" + VehicleName))
                    {
                        Directory.CreateDirectory("Vehicles" + "\\" + VehicleName);
                        File.WriteAllText("Vehicles" + "\\" + VehicleName + "\\" + VehicleName + Extension, VehicleXML);
                    }
                }
                else if (!Override)
                {
                    if (Directory.Exists("Vehicles" + "\\" + VehicleName))
                    {
                        if (File.Exists("Vehicles" + "\\" + VehicleName + "\\" + VehicleName + Extension))
                        {
                            throw new System.InvalidOperationException("This Vehicle Information already exists.");
                        }
                        else File.WriteAllText("Vehicles" + "\\" + VehicleName + "\\" + VehicleName + Extension, VehicleXML);
                    }
                    else if (!Directory.Exists("Vehicles" + "\\" + VehicleName))
                    {
                        Directory.CreateDirectory("Vehicles" + "\\" + VehicleName);
                        File.WriteAllText("Vehicles" + "\\" + VehicleName + "\\" + VehicleName + Extension, VehicleXML);
                    }
                }
                return true;
            }
            catch (System.Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Will create a Route file
        /// </summary>
        /// <param name="VehicleName">Vehicle Name to enter into Route data</param>
        /// <param name="RouteXML">XML to write in Route file</param>
        /// <param name="StartPointName">Starting Location Name</param>
        /// <param name="EndPointName">Ending Location Name</param>
        /// <param name="Join">Join to use between starting & ending point names in file name</param>
        /// <param name="Extension">Extension of file</param>
        /// <returns>Return String confirmation if file is created, merged or not created via Created, Merged & Not Created keyword.</returns>
        public string CreateRouteFile(string VehicleName, string RouteXML, string StartPointName, string EndPointName, string RootFolder, string Join, string Extension)
        {
            return _CreateRouteFile(VehicleName, RouteXML, StartPointName, EndPointName, RootFolder, Join, Extension, false);
        }
        /// <summary>
        /// Will create a Route file
        /// </summary>
        /// <param name="VehicleName">Vehicle Name to enter into Route data</param>
        /// <param name="RouteXML">XML to write in Route file</param>
        /// <param name="StartPointName">Starting Location Name</param>
        /// <param name="EndPointName">Ending Location Name</param>
        /// <param name="Join">Join to use between starting & ending point names in file name</param>
        /// <param name="Extension">Extension of file</param>
        /// <param name="Override">Override the existing file</param>
        /// <returns>Return String confirmation if file is created, merged or not created via Created, Merged & Not Created keyword.</returns>
        public string CreateRouteFile(string VehicleName, string RouteXML, string StartPointName, string EndPointName, string RootFolder, string Join, string Extension, bool Override)
        {
            return _CreateRouteFile(VehicleName, RouteXML, StartPointName, EndPointName, RootFolder, Join, Extension, Override);
        }
        private string _CreateRouteFile(string VehicleName, string RouteXML, string StartPointName, string EndPointName, string RootFolder, string Join, string Extension, bool Override)
        {
            string StartPointNameDB = StartPointName, EndPointNameDB = EndPointName;

            StartPointName = StartPointName.Standard();
            EndPointName = EndPointName.Standard();
            string FileName = GetFileName(StartPointName, EndPointName, Join);

            Locations _locations = new Locations();

            decimal StartPointLat, StartPointLong;
            decimal EndPointLat, EndPointLong;

            _locations.GetCoordinates(StartPointNameDB, out StartPointLat, out StartPointLong);
            _locations.GetCoordinates(EndPointNameDB, out EndPointLat, out EndPointLong);

            int StartPointID = dataHandler.GetLocationID(StartPointNameDB, StartPointLat, StartPointLong);
            int EndPointID = dataHandler.GetLocationID(EndPointNameDB, EndPointLat, EndPointLong);

            int VehicleID = dataHandler.GetVehicleID(VehicleName);

            if (Override)
            {
                if (dataHandler.AddRouteCombination(StartPointNameDB, EndPointNameDB, VehicleID, RouteXML, true))
                {
                    if (Directory.Exists(RootFolder + "\\" + StartPointName + "\\" + EndPointName))
                    {
                        if (File.Exists(RootFolder + "\\" + StartPointName + "\\" + EndPointName + "\\" + FileName + Extension))
                        {
                            RouteXML = dataHandler.FinalRouteData(dataHandler.GetRouteData(StartPointID, EndPointID));

                            File.WriteAllText(RootFolder + "\\" + StartPointName + "\\" + EndPointName + "\\" + FileName + Extension, RouteXML);

                            if (File.Exists(RootFolder + "\\" + StartPointName + "\\" + EndPointName + "\\index.php"))
                            {
                                //do nothing
                            }
                            else if (!File.Exists(RootFolder + "\\" + StartPointName + "\\" + EndPointName + "\\index.php"))
                            {
                                _CreateRelativePHPFile(RootFolder + "\\" + StartPointName + "\\" + EndPointName, FileName, Extension);
                            }
                            return "Overrided";
                        }
                        else
                        {
                            RouteXML = dataHandler.FinalRouteData(dataHandler.GetRouteData(StartPointID, EndPointID));

                            File.WriteAllText(RootFolder + "\\" + StartPointName + "\\" + EndPointName + "\\" + FileName + Extension, RouteXML);
                            _CreateRelativePHPFile(RootFolder + "\\" + StartPointName + "\\" + EndPointName, FileName, Extension);
                            return "Created";
                        }
                    }
                    else
                    {
                        Directory.CreateDirectory(RootFolder + "\\" + StartPointName + "\\" + EndPointName);

                        RouteXML = dataHandler.FinalRouteData(dataHandler.GetRouteData(StartPointID, EndPointID));

                        File.WriteAllText(RootFolder + "\\" + StartPointName + "\\" + EndPointName + "\\" + FileName + Extension, RouteXML);
                        _CreateRelativePHPFile(RootFolder + "\\" + StartPointName + "\\" + EndPointName, FileName, Extension);
                        return "Created";
                    }
                }
                else
                {
                    return "Not Added";
                }
            }
            else if (!Override)
            {
                if (dataHandler.AddRouteCombination(StartPointNameDB, EndPointNameDB, VehicleID, RouteXML, false))
                {
                    if (Directory.Exists(RootFolder + "\\" + StartPointName + "\\" + EndPointName))
                    {
                        if (File.Exists(RootFolder + "\\" + StartPointName + "\\" + EndPointName + "\\" + FileName + Extension))
                        {
                            RouteXML = dataHandler.FinalRouteData(dataHandler.GetRouteData(StartPointID, EndPointID));

                            File.WriteAllText(RootFolder + "\\" + StartPointName + "\\" + EndPointName + "\\" + FileName + Extension, RouteXML);

                            if (File.Exists(RootFolder + "\\" + StartPointName + "\\" + EndPointName + "\\index.php"))
                            {
                                //do nothing
                            }
                            else if (!File.Exists(RootFolder + "\\" + StartPointName + "\\" + EndPointName + "\\index.php"))
                            {
                                _CreateRelativePHPFile(RootFolder + "\\" + StartPointName + "\\" + EndPointName, FileName, Extension);
                            }

                            return "Merged";
                        }
                        else
                        {
                            RouteXML = dataHandler.FinalRouteData(dataHandler.GetRouteData(StartPointID, EndPointID));

                            File.WriteAllText(RootFolder + "\\" + StartPointName + "\\" + EndPointName + "\\" + FileName + Extension, RouteXML);
                            _CreateRelativePHPFile(RootFolder + "\\" + StartPointName + "\\" + EndPointName, FileName, Extension);
                            return "Created";
                        }
                    }
                    else
                    {
                        Directory.CreateDirectory(RootFolder + "\\" + StartPointName + "\\" + EndPointName);

                        RouteXML = dataHandler.FinalRouteData(dataHandler.GetRouteData(StartPointID, EndPointID));

                        File.WriteAllText(RootFolder + "\\" + StartPointName + "\\" + EndPointName + "\\" + FileName + Extension, RouteXML);
                        _CreateRelativePHPFile(RootFolder + "\\" + StartPointName + "\\" + EndPointName, FileName, Extension);
                        return "Created";
                    }
                }
                else
                {
                    return "Not Added";
                }
            }

            return "Not Created";
        }

        /// <summary>
        /// This will create the index.php file for every route to place in that directory
        /// </summary>
        /// <param name="Path">Path where file should be created</param>
        /// <param name="XMLFileName">Name of the XML file</param>
        /// <param name="Extension">Extension of XML file</param>
        private void _CreateRelativePHPFile(string Path, string XMLFileName, string Extension)
        {
            string Content = "<?php\n$xml = file_get_contents('" + XMLFileName + Extension + "');\n$xml = trim( $xml );\nheader('Content-Type: text/xml');\necho $xml;\n?>";
            File.WriteAllText(Path + "\\index.php", Content);
        }

        /// <summary>
        /// Will return name of file for given start point, end point & join without Extension
        /// </summary>
        /// <param name="StartPointName">Starting Point Name</param>
        /// <param name="EndPointName">Ending Point Name</param>
        /// <param name="Join">Join between start point name & end point name</param>
        /// <returns>Return Name of file</returns>
        public string GetFileName(string StartPointName, string EndPointName, string Join)
        {
            return (StartPointName + Join + EndPointName).Standard();
        }

        /// <summary>
        /// Will return confirmation if file exist
        /// </summary>
        /// <param name="FileName">File name with Complete path</param>
        /// <param name="Extension">Extension of file</param>
        /// <returns>Returns boolean confirmation either true or false</returns>
        public bool CheckIfFileExists(string FileName, string Extension)
        {
            return File.Exists(FileName + Extension);
        }

        public string DeleteRouteFile(string VehicleName, string RouteXML, string StartPointName, string EndPointName, string RootFolder, string Join, string Extension)
        {
            return _DeleteRouteFile(VehicleName, RouteXML, StartPointName, EndPointName, RootFolder, Join, Extension);
        }
        private string _DeleteRouteFile(string VehicleName, string RouteXML, string StartPointName, string EndPointName, string RootFolder, string Join, string Extension)
        {
            StartPointName = StartPointName.Standard();
            EndPointName = EndPointName.Standard();
            string FileName = GetFileName(StartPointName, EndPointName, Join);

            if (Directory.Exists(RootFolder + "\\" + StartPointName))
            {
                if (Directory.Exists(RootFolder + "\\" + StartPointName + "\\" + EndPointName))
                {
                    if (File.Exists(RootFolder + "\\" + StartPointName + "\\" + EndPointName + "\\" + FileName + Extension))
                    {
                        string ExistingRouteXML = File.ReadAllText(RootFolder + "\\" + StartPointName + "\\" + EndPointName + "\\" + FileName + Extension);

                        //string NewXML = xmlHandler.AddExistingRoutesXML(ExistingRouteXML, RouteXML, VehicleName, xmlHandler.GetVehicleType(RouteXML));

                        bool AnyNodesLeft = true;
                        string NewFinalXML = string.Empty;

                        xmlHandler.DeleteExistingRoutesXML(ExistingRouteXML, RouteXML, out NewFinalXML, out AnyNodesLeft);

                        if (AnyNodesLeft)
                        {
                            File.WriteAllText(RootFolder + "\\" + StartPointName + "\\" + EndPointName + "\\" + FileName + Extension, xmlHandler.IdentateXML(NewFinalXML)); //weird error. testing
                            return "Route Deleted";
                        }
                        else if (!AnyNodesLeft)
                        {
                            File.Delete(RootFolder + "\\" + StartPointName + "\\" + EndPointName + "\\" + FileName + Extension);

                            if (!File.Exists(RootFolder + "\\" + StartPointName + "\\" + EndPointName + "\\index.php"))
                            {
                                File.Delete(RootFolder + "\\" + StartPointName + "\\" + EndPointName + "\\index.php");
                            }

                            return "File Deleted";
                        }
                    }
                    else if (!File.Exists(RootFolder + "\\" + StartPointName + "\\" + EndPointName + "\\" + FileName + Extension))
                    {
                        return "Not Exists";
                    }
                }
                else if (!Directory.Exists(RootFolder + "\\" + StartPointName + "\\" + EndPointName))
                {
                    return "Not Exists";
                }
            }
            return "Not Exists";
        }

        public bool CreateLocationFile()
        {
            return _CreateLocationFile();
        }
        private bool _CreateLocationFile()
        {
            Locations locations = new Locations();

            string LocationNames = string.Empty;

            foreach (string LocationName in locations.GetLocationNames())
            {
                LocationNames = LocationNames + "<LocationName>" + LocationName + "</LocationName>" + "\n";
            }

            LocationNames = "<Locations>" + "\n"  +LocationNames + "\n" + "</Locations>";

            LocationNames = xmlHandler.IdentateXML(LocationNames);

            if (Directory.Exists("Locations"))
            {
                File.WriteAllText("Locations" + "\\" + "Locations.xml", LocationNames);
            }
            else if (!Directory.Exists("Locations"))
            {
                Directory.CreateDirectory("Locations");
                File.WriteAllText("Locations" + "\\" + "Locations.xml", LocationNames);
            }

            return true;
        }

        
    }
}
