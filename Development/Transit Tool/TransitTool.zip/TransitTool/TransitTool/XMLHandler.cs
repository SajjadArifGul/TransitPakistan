﻿using System.Collections;
using System.IO;
using System.Text;
using System.Xml;

namespace TransitTool
{
    class XMLHandler
    {
        /// <summary>
        /// Object of filer class
        /// </summary>
        Filer filer;

        /// <summary>
        /// default constructor
        /// </summary>
        public XMLHandler()
        {
            _InitilizeVariables();
        }

        /// <summary>
        /// parametrized constructor
        /// </summary>
        public XMLHandler(string Empty)
        {
            //dont initilize any variables.
        }

        /// <summary>
        /// method to iniilize important variables
        /// </summary>
        public void _InitilizeVariables()
        {
            filer = new Filer();
        }

        /// <summary>
        /// This will Format the whole Vehicle XML with given Vehicle Type & Name
        /// </summary>
        /// <param name="XML">XML to format</param>
        /// <returns>Returns Final Formated XML for Vehicle including XML Prolog</returns>
        public string FormatVehicleXML(string XML)
        {
            return _SetXMLProlog(_SetVehicleRootNode(XML)); //Prolog is same for every XML document
        }

        /// <summary>
        /// This will Format the whole Route XML with given Vehicle Type & Name
        /// </summary>
        /// <param name="XML">XML to be formated</param>
        /// <returns>Returns Final Formated XML for Route including XML Prolog & Vehicle Data</returns>
        public string FormatRouteXML(string XML)
        {
            return _SetXMLProlog(_SetRouteRootNode(XML));
        }

        /// <summary>
        /// public this will Identate XML to an XML Tree
        /// </summary>
        /// <param name="XML">XML to be identated</param>
        /// <returns>Returns Identated XML</returns>
        public string IdentateXML(string XML)
        {
            return _IdentateXML(XML);
        }
        private string _IdentateXML(string XML)
        {
            try
            {
                string Result = "";

                MemoryStream MS = new MemoryStream();
                XmlTextWriter W = new XmlTextWriter(MS, Encoding.Unicode);
                XmlDocument D = new XmlDocument();

                //Load the XmlDocument with the XML.
                D.LoadXml(XML);

                W.Formatting = Formatting.Indented;

                // Write the XML into a formatting XmlTextWriter
                D.WriteContentTo(W);
                W.Flush();
                MS.Flush();

                // Have to rewind the MemoryStream in order to read
                // its contents.
                MS.Position = 0;

                // Read MemoryStream contents into a StreamReader.
                StreamReader SR = new StreamReader(MS);

                // Extract the text from the StreamReader.
                string FormattedXML = SR.ReadToEnd();

                Result = FormattedXML;
                MS.Close();
                W.Close();

                return Result;
            }
            catch
            {
                return XML;
            }
        }

        /// <summary>
        /// setting openning line of every XML Document
        /// </summary>
        /// <param name="XML">XML to be set XML Prolog before</param>
        /// <returns>Returns XML with XML Prolog added</returns>
        private string _SetXMLProlog(string XML)
        {
            //stating XML version & encoding
            return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
                + XML;
        }

        /// <summary>
        /// This will set the Root node if the XML is written for vehicle. This will also be written for Route XML for separate vehicle
        /// </summary>
        /// <param name="XML">XML to write Vehicle Root Node</param>
        /// <returns>Returns XML with Vehicle Root node added</returns>
        private string _SetVehicleRootNode(string XML)
        {
            //root node is <Vehicle>
            return "<Vehicle>\n"
                   + XML +
                   "</Vehicle>\n";
        }

        /// <summary>
        /// this will set the root node if XML is written for Route
        /// </summary>
        /// <param name="XML">XML to write Route root node for</param>
        /// <returns>Returns XML with Route root node added</returns>
        private string _SetRouteRootNode(string XML)
        {
            //root node is <Route>
            return "<Route>\n"
                 + XML
                 + "</Route>\n";
        }

        /// <summary>
        /// Will set Vehicle Type in the given XML
        /// </summary>
        /// <param name="XML">XML to write Vehicle Type for</param>
        /// <param name="VehicleType">Vehicle Type info to add</param>
        /// <returns>Returns XML with Vehicle Type info added</returns>
        public string SetVehicleType(string XML, string VehicleType)
        {
            return _SetVehicleType(XML, VehicleType);
        }
        private string _SetVehicleType(string XML, string VehicleType)
        {
            if (XML.Contains("<VehicleType>"))
            {
                string VehicleTypePrevious = XML.Between("<VehicleType>", "</VehicleType>");
                XML = XML.Replace("<VehicleType>" + VehicleTypePrevious + "</VehicleType>", "<VehicleType>" + VehicleType + "</VehicleType>");

                return XML;
            }
            else
            {
                XML = "<VehicleType>" + VehicleType + "</VehicleType>\n";
                return XML;
            }
        }

        /// <summary>
        /// Will set Vehicle Name in the given XML
        /// </summary>
        /// <param name="XML">XML to write Vehicle Name for</param>
        /// <param name="VehicleName">Vehicle Name info to add</param>
        /// <returns>Returns XML with Vehicle Name info added</returns>
        public string SetVehicleName(string XML, string VehicleName)
        {
            return _SetVehicleName(XML, VehicleName);
        }
        private string _SetVehicleName(string XML, string VehicleName)
        {
            if (XML.Contains("<VehicleName>"))
            {
                string VehicleNamePrevious = XML.Between("<VehicleName>", "</VehicleName>");
                XML = XML.Replace("<VehicleName>" + VehicleNamePrevious + "</VehicleName>", "<VehicleName>" + VehicleName + "</VehicleName>");
                return XML;
            }
            else
            {
                return XML
                    + "<VehicleName>" + VehicleName + "</VehicleName>\n";
            }
        }

        public string SetRouteFair(string XML, string RouteFair, string StopFair)
        {
            return _SetRouteFair(XML, RouteFair, StopFair);
        }
        private string _SetRouteFair(string XML, string RouteFair, string StopFair)
        {
            if (XML.Contains("<RouteFair>"))
            {
                string RouteFairPrevious = XML.Between("<RouteFair>", "</RouteFair>");
                XML = XML.Replace("<RouteFair>" + RouteFairPrevious + "</RouteFair>", "<RouteFair>" + RouteFair + "</RouteFair>");
            }

            if (XML.Contains("<StopFair>"))
            {
                string StopFairPrevious = XML.Between("<StopFair>", "</StopFair>");
                XML = XML.Replace("<StopFair>" + StopFairPrevious + "</StopFair>", "<StopFair>" + StopFair + "</StopFair>");
            }

            if (!XML.Contains("<RouteFair>") & !XML.Contains("<StopFair>"))
            {
                XML = XML
                    + "<RouteFair>" + RouteFair + "</RouteFair>\n"
                    + "<StopFair>" + StopFair + "</StopFair>\n";
            }
            return XML;
        }

        /// <summary>
        /// Will return Vehicle Type info from given XML
        /// </summary>
        /// <param name="XML">XML to get Vehicle Type from</param>
        /// <returns>Return string containing Vehicle Type info</returns>
        public string GetVehicleType(string XML)
        {
            return _GetVehicleType(XML);
        }
        private string _GetVehicleType(string XML)
        {
            if (XML.Contains("<VehicleType>"))
            {
                string VehicleType = XML.Between("<VehicleType>", "</VehicleType>");
                return VehicleType;
            }
            else
            {
                throw new System.InvalidOperationException("There is no VehicleType information in XML");
            }
        }

        /// <summary>
        /// Will retun Vehicle Name info from given XML
        /// </summary>
        /// <param name="XML">XML to get Vehicle Name from</param>
        /// <returns>Returns a string containing Vehicle Name info</returns>
        public string GetVehicleName(string XML)
        {
            return _GetVehicleName(XML);
        }
        private string _GetVehicleName(string XML)
        {
            if (XML.Contains("<VehicleName>"))
            {
                string VehicleName = XML.Between("<VehicleName>", "</VehicleName>");
                return VehicleName;
            }
            else
            {
                throw new System.InvalidOperationException("There is no VehicleName information in XML");
            }
        }

        public string GetStartPointName(string XML)
        {
            return _GetStartPointName(XML);
        }
        private string _GetStartPointName(string XML)
        {
            if (XML.Contains("<StartPointName>"))
            {
                string StartPointName = XML.Between("<StartPointName>", "</StartPointName>");
                return StartPointName;
            }
            else
            {
                throw new System.InvalidOperationException("There is no StartPointName information in XML");
            }
        }

        public string GetEndPointName(string XML)
        {
            return _GetEndPointName(XML);
        }
        private string _GetEndPointName(string XML)
        {
            if (XML.Contains("<EndPointName>"))
            {
                string EndPointName = XML.Between("<EndPointName>", "</EndPointName>");
                return EndPointName;
            }
            else
            {
                throw new System.InvalidOperationException("There is no EndPointName information in XML");
            }
        }

        public string GetStopFair(string XML)
        {
            return _GetStopFair(XML);
        }
        private string _GetStopFair(string XML)
        {
            if (XML.Contains("<StopFair>"))
            {
                string StopFair = XML.Between("<StopFair>", "</StopFair>");
                return StopFair;
            }
            else
            {
                throw new System.InvalidOperationException("There is no StopFair information in XML");
            }
        }


        /// <summary>
        /// Will add Vehicle Type info in given XML
        /// </summary>
        /// <param name="XML">XML to add Vehicle Type info to</param>
        /// <param name="VehicleType">Vehicle Type info to add</param>
        /// <returns>Returns XML with Vehicle Type info</returns>
        private string _PutVehicleType(string XML, string VehicleType)
        {
            return "<VehicleType>" + VehicleType + "</VehicleType>\n"
                + XML;
        }

        /// <summary>
        /// Will add Vehicle Type info in given XML
        /// </summary>
        /// <param name="XML">XML to add Vehicle Type info to</param>
        /// <param name="VehicleType">Vehicle Type info to add</param>
        /// <returns>Returns XML with Vehicle Type info</returns>
        private string _PutVehicleName(string XML, string VehicleName)
        {
            return "<VehicleName>" + VehicleName + "</VehicleName>\n"
                + XML;
        }

        private string _PutStopFair(string XML, string StopFair)
        {
            return "<StopFair>" + StopFair + "</StopFair>\n"
                + XML;
        }

        /// <summary>
        /// It will return string with Start Point Node with given info
        /// </summary>
        /// <param name="XML">XML to add Start Point info to</param>
        /// <param name="StartPointName">Name of Start Point</param>
        /// <param name="StartPointLat">Latitude of Start Point</param>
        /// <param name="StartPointLong">Longitude of Start Point</param>
        /// <returns>Returns XML with Start Point added to it</returns>
        public string SetStartPoint(string XML, string StartPointName, string StartPointLat, string StartPointLong)
        {
            return _SetStartPoint(XML, StartPointName, StartPointLat, StartPointLong);
        }
        private string _SetStartPoint(string XML, string StartPointName, string StartPointLat, string StartPointLong)
        {
            if (XML.Contains("<StartPoint>"))
            {
                string StartPointText = XML.Between("<StartPoint>", "</StartPoint>");

                string StartPointNamePrevious = StartPointText.Between("<StartPointName>", "</StartPointName>");
                string StartPointLatPrevious = StartPointText.Between("<StartPointLat>", "</StartPointLat>");
                string StartPointLongPrevious = StartPointText.Between("<StartPointLong>", "</StartPointLong>");

                string NewStartPointText = StartPointText.Replace("<StartPointName>" + StartPointNamePrevious + "</StartPointName>", "<StartPointName>" + StartPointName + "</StartPointName>");
                NewStartPointText = NewStartPointText.Replace("<StartPointLat>" + StartPointLatPrevious + "</StartPointLat>", "<StartPointLat>" + StartPointLat + "</StartPointLat>");
                NewStartPointText = NewStartPointText.Replace("<StartPointLong>" + StartPointLongPrevious + "</StartPointLong>", "<StartPointLong>" + StartPointLong + "</StartPointLong>");

                XML = XML.Replace(StartPointText, NewStartPointText);

                return XML;
            }
            else
            {
                return XML
                    + "<StartPoint>\n"
                    + "<StartPointName>" + StartPointName + "</StartPointName>\n"
                    + "<StartPointLat>" + StartPointLat + "</StartPointLat>\n"
                    + "<StartPointLong>" + StartPointLong + "</StartPointLong>\n"
                    + "</StartPoint>\n";
            }
        }

        /// <summary>
        /// It will return String with Bus Stop Node with given info
        /// </summary>
        /// <param name="XML">XML to add Bus Stop info to</param>
        /// <param name="StartPointName">Name of Bus Stop</param>
        /// <param name="StartPointLat">Latitude of Bus Stop</param>
        /// <param name="StartPointLong">Longitude of Bus Stop</param>
        /// <returns>Returns XML with Bus Stop info added to it</returns>
        public string SetBusStop(string XML, string BusStopName, string BusStopLat, string BusStopLong)
        {
            return _SetBusStop(XML, BusStopName, BusStopLat, BusStopLong);
        }
        private string _SetBusStop(string XML, string BusStopName, string BusStopLat, string BusStopLong)
        {
            return XML
                + "<BusStop>\n"
                + "<BusStopName>" + BusStopName + "</BusStopName>\n"
                + "<BusStopLat>" + BusStopLat + "</BusStopLat>\n"
                + "<BusStopLong>" + BusStopLong + "</BusStopLong>\n"
                + "</BusStop>\n";
        }

        /// <summary>
        /// It will return string with End Point Node with given info
        /// </summary>
        /// <param name="XML">XML to add End Point info to</param>
        /// <param name="StartPointName">Name of End Point</param>
        /// <param name="StartPointLat">Latitude of End Point</param>
        /// <param name="StartPointLong">Longitude of End Point</param>
        /// <returns>Returns XML with End Point added to it</returns>
        public string SetEndPoint(string XML, string EndPointName, string EndPointLat, string EndPointLong)
        {
            return _SetEndPoint(XML, EndPointName, EndPointLat, EndPointLong);
        }
        private string _SetEndPoint(string XML, string EndPointName, string EndPointLat, string EndPointLong)
        {
            if (XML.Contains("<EndPoint>"))
            {
                string EndPointText = XML.Between("<EndPoint>", "</EndPoint>");

                string EndPointNamePrevious = EndPointText.Between("<EndPointName>", "</EndPointName>");
                string EndPointLatPrevious = EndPointText.Between("<EndPointLat>", "</EndPointLat>");
                string EndPointLongPrevious = EndPointText.Between("<EndPointLong>", "</EndPointLong>");

                string NewEndPointText = EndPointText.Replace("<EndPointName>" + EndPointNamePrevious + "</EndPointName>", "<EndPointName>" + EndPointName + "</EndPointName>");
                NewEndPointText = NewEndPointText.Replace("<EndPointLat>" + EndPointLatPrevious + "</EndPointLat>", "<EndPointLat>" + EndPointLat + "</EndPointLat>");
                NewEndPointText = NewEndPointText.Replace("<EndPointLong>" + EndPointLongPrevious + "</EndPointLong>", "<EndPointLong>" + EndPointLong + "</EndPointLong>");

                XML = XML.Replace(EndPointText, NewEndPointText);

                return XML;
            }
            else
            {
                return XML
                    + "<EndPoint>\n"
                    + "<EndPointName>" + EndPointName + "</EndPointName>\n"
                    + "<EndPointLat>" + EndPointLat + "</EndPointLat>\n"
                    + "<EndPointLong>" + EndPointLong + "</EndPointLong>\n"
                    + "</EndPoint>\n";
            }
        }

        /// <summary>
        /// It will set Start Point & End Point nodes for the given Route XML Nodes List
        /// </summary>
        /// <param name="XMLNodesList">XML Nodes List</param>
        /// <param name="FinalXML">Final XML to be return with Start Point and End Point settled</param>
        /// <param name="StartPointName">Start Point Name to be returned</param>
        /// <param name="EndPointName">End Point Name to be returned</param>
        public void SetNodes(ArrayList XMLNodesList, out string FinalXML, out string StartPointName, out string EndPointName)
        {
            _SetNodes(XMLNodesList, out FinalXML, out StartPointName, out EndPointName);
        }
        private void _SetNodes(ArrayList XMLNodesList, out string FinalXML, out string StartPointName, out string EndPointName)
        {
            string[] XMLNodesArray = XMLNodesList.ToArray(typeof(string)) as string[];

            string TempStartPointName = null;
            string TempEndPointName = null;

            //for Starting Point Name
            {
                if (XMLNodesArray[0].Contains("<StartPoint>"))
                {
                    TempStartPointName = XMLNodesArray[0].Between("<StartPointName>", "</StartPointName>");
                }
                else if (XMLNodesArray[0].Contains("<BusStop>"))
                {
                    XMLNodesArray[0] = XMLNodesArray[0].Replace("BusStopName", "StartPointName");
                    XMLNodesArray[0] = XMLNodesArray[0].Replace("BusStopLat", "StartPointLat");
                    XMLNodesArray[0] = XMLNodesArray[0].Replace("BusStopLong", "StartPointLong");
                    XMLNodesArray[0] = XMLNodesArray[0].Replace("BusStop", "StartPoint");

                    TempStartPointName = XMLNodesArray[0].Between("<StartPointName>", "</StartPointName>");
                }
                else if (XMLNodesArray[0].Contains("<EndPoint>"))
                {
                    XMLNodesArray[0] = XMLNodesArray[0].Replace("EndPointName", "StartPointName");
                    XMLNodesArray[0] = XMLNodesArray[0].Replace("EndPointLat", "StartPointLat");
                    XMLNodesArray[0] = XMLNodesArray[0].Replace("EndPointLong", "StartPointLong");
                    XMLNodesArray[0] = XMLNodesArray[0].Replace("EndPoint", "StartPoint");

                    TempStartPointName = XMLNodesArray[0].Between("<StartPointName>", "</StartPointName>");
                }
            }

            int LastNodeinArray = XMLNodesArray.Length - 1;

            //for Ending Point Name
            {
                if (XMLNodesArray[LastNodeinArray].Contains("</EndPoint>"))
                {
                    TempEndPointName = XMLNodesArray[LastNodeinArray].Between("<EndPointName>", "</EndPointName>");
                }
                else if (XMLNodesArray[LastNodeinArray].Contains("</BusStop>"))
                {
                    XMLNodesArray[LastNodeinArray] = XMLNodesArray[LastNodeinArray].Replace("BusStopLong", "EndPointLong");
                    XMLNodesArray[LastNodeinArray] = XMLNodesArray[LastNodeinArray].Replace("BusStopLat", "EndPointLat");
                    XMLNodesArray[LastNodeinArray] = XMLNodesArray[LastNodeinArray].Replace("BusStopName", "EndPointName");
                    XMLNodesArray[LastNodeinArray] = XMLNodesArray[LastNodeinArray].Replace("BusStop", "EndPoint");//this is last

                    TempEndPointName = XMLNodesArray[LastNodeinArray].Between("<EndPointName>", "</EndPointName>");
                }
                else if (XMLNodesArray[LastNodeinArray].Contains("</StartPoint>"))
                {
                    XMLNodesArray[LastNodeinArray] = XMLNodesArray[LastNodeinArray].Replace("StartPointLong", "EndPointLong");
                    XMLNodesArray[LastNodeinArray] = XMLNodesArray[LastNodeinArray].Replace("StartPointLat", "EndPointLat");
                    XMLNodesArray[LastNodeinArray] = XMLNodesArray[LastNodeinArray].Replace("StartPointName", "EndPointName");
                    XMLNodesArray[LastNodeinArray] = XMLNodesArray[LastNodeinArray].Replace("StartPoint", "EndPoint");

                    TempEndPointName = XMLNodesArray[LastNodeinArray].Between("<EndPointName>", "</EndPointName>");
                }
            }

            string TempXML = null;

            foreach (var Line in XMLNodesArray)
            {
                TempXML = TempXML + Line;
            }

            StartPointName = TempStartPointName;
            EndPointName = TempEndPointName;
            FinalXML = TempXML;
        }

        /// <summary>
        /// Will return Merged XML for the 2 given XMLs
        /// </summary>
        /// <param name="ExistingRouteXML">Already Existing XML from File</param>
        /// <param name="NewRouteXML">New XML to be added</param>
        /// <returns>Returns a merged XML</returns>
        public string AddExistingRoutesXML(string ExistingRouteXML, string NewRouteXML, string NewVehicleName, string NewVehicleType)
        {
            return _AddExistingRoutesXML(ExistingRouteXML, NewRouteXML, NewVehicleName, NewVehicleType);
        }
        private string _AddExistingRoutesXML(string ExistingRouteXML, string NewRouteXML, string NewVehicleName, string NewVehicleType)
        {
            //first remove XML Prolog.
            ExistingRouteXML = ExistingRouteXML.Replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "");
            //Now remove Openning Route node
            ExistingRouteXML = ExistingRouteXML.Replace("<Route>", "");
            //Now remove Closing Route node
            ExistingRouteXML = ExistingRouteXML.Replace("</Route>", "");

            //first remove XML Prolog.
            NewRouteXML = NewRouteXML.Replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "");
            //Now remove Openning Route node
            NewRouteXML = NewRouteXML.Replace("<Route>", "");
            //Now remove Closing Route node
            NewRouteXML = NewRouteXML.Replace("</Route>", "");

            ////This will tell if this new vehicle data is already there in Existing data. If yes, return the new one because it might be updated one.
            //if ((GetVehicleNameP(ExistingRouteXML) == GetVehicleNameP(NewRouteXML)) && (GetVehicleTypeP(ExistingRouteXML) == GetVehicleTypeP(NewRouteXML)))
            //{
            //    // return newer data
            //    return NewRouteXML;
            //}
            ////I am thinking that the above logic might not work as i am thinking about it.
            ////if there are already more than 2 vehicle routes in the existing data one of which
            ////is of the vehicle that we are adding again but this vehicle info is on second in 
            ////the route data, my GetVehicleName method will only return the first one. so it might again
            ////add this data. I am now using below logic to check if both XML are same or not. If yes return new XMl.

            //new logic - 13 March 2017

            //bool AddNewRemoveOldNode = false;

            //if ((ExistingRouteXML.Contains("<VehicleName>" + NewVehicleName + "</VehicleName>")) || ExistingRouteXML.Contains("<VehicleType>" + NewVehicleType + "</VehicleType>"))
            //{
            //    //route exists in file - we need to remove this node & add new xml node
            //    AddNewRemoveOldNode = true;
            //}

            ArrayList ListOfExistingNodes = new ArrayList();

            string Node = string.Empty;

            foreach (string Word in ExistingRouteXML.Split('\n'))
            {
                if (Word.Contains("<Vehicle>"))
                {
                    Node = Word + '\n';
                }
                else if (Word.Contains("</Vehicle>"))
                {
                    Node = Node + Word;

                    ListOfExistingNodes.Add(Node);

                    Node = string.Empty;
                }
                else
                {
                    Node = Node + Word + '\n';
                }
            }

            //if (AddNewRemoveOldNode)
            //{
            //    foreach (string SingleNode in ListOfExistingNodes)
            //    {
            //        if ((SingleNode.Contains("<VehicleName>" + NewVehicleName + "</VehicleName>")) || SingleNode.Contains("<VehicleType>" + NewVehicleType + "</VehicleType>"))
            //        {
            //            ListOfExistingNodes.RemoveAt(ListOfExistingNodes.IndexOf(SingleNode));
            //            ListOfExistingNodes.Add(NewRouteXML);
            //        }
            //    }
            //}

            ArrayList CopyOfListOfExistingNodes = new ArrayList();

            foreach (string SingleNode in ListOfExistingNodes)
            {
                string SingleNodeWithoutFairAttribute = SingleNode.Replace("<StopFair>" + SingleNode.Between("<StopFair>", "</StopFair>") + "</StopFair>", string.Empty);
                SingleNodeWithoutFairAttribute = SingleNodeWithoutFairAttribute.Replace('\r', ' ');
                SingleNodeWithoutFairAttribute = SingleNodeWithoutFairAttribute.Replace('\n', ' ');
                SingleNodeWithoutFairAttribute = SingleNodeWithoutFairAttribute.Replace(" ", "");
                CopyOfListOfExistingNodes.Add(SingleNodeWithoutFairAttribute);
            }

            string NewRouteXMLWithoutFairAttribute = NewRouteXML.Replace("<StopFair>" + NewRouteXML.Between("<StopFair>", "</StopFair>") + "</StopFair>", string.Empty);
            NewRouteXMLWithoutFairAttribute = NewRouteXMLWithoutFairAttribute.Replace('\r', ' ');
            NewRouteXMLWithoutFairAttribute = NewRouteXMLWithoutFairAttribute.Replace('\n', ' ');
            NewRouteXMLWithoutFairAttribute = NewRouteXMLWithoutFairAttribute.Replace(" ", "");

            foreach (string SingleNode in CopyOfListOfExistingNodes)
            {
                if (SingleNode == NewRouteXMLWithoutFairAttribute)
                {
                    ListOfExistingNodes.RemoveAt(CopyOfListOfExistingNodes.IndexOf(SingleNode));
                    ListOfExistingNodes.Add(NewRouteXML);
                }
            }

            string NewXML = string.Empty;

            foreach (string SingleNode in ListOfExistingNodes)
            {
                NewXML = NewXML + SingleNode + '\n';
            }

            return _SetXMLProlog(_SetRouteRootNode(NewXML));

            /////*Now we have a List of Nodes that exist in the ExistingRouteXML. We will compare it with NewXML after removing its stopfair attribute*/

            ////Node = string.Empty;

            ////foreach (string Word in NewRouteXML.Split('\n'))
            ////{
            ////    if (Word.Contains("<Vehicle>"))
            ////    {
            ////        Node = Word + '\n';
            ////    }
            ////    else if (Word.Contains("</Vehicle>"))
            ////    {
            ////        Node = Node + Word;
            ////    }
            ////    else if (Word.Contains("StopFair"))
            ////    {
            ////        //ignore this shit
            ////    }
            ////    else
            ////    {
            ////        Node = Node + Word + '\n';
            ////    }
            ////}

            /////*Now lets compare Node with ListOfExisiting Nodes*/

            ////foreach (string SingleNode in ListOfVehicleNodes)
            ////{
            ////    if (SingleNode == Node)
            ////    {
            ////        ListOfVehicleNodes.RemoveAt(ListOfVehicleNodes.IndexOf(SingleNode));
            ////        ListOfVehicleNodes.Add(Node);
            ////    }
            ////}

            ////string NewXML = string.Empty;

            ////foreach (string SingleNode in ListOfVehicleNodes)
            ////{
            ////    NewXML = NewXML + SingleNode + '\n';
            ////}

            ////return _SetXMLProlog(_SetRouteRootNode(NewXML));

            //end new logic 13 March 2017

            //////if (ExistingRouteXML == NewRouteXML)
            //////{
            //////    return _SetXMLProlog(_SetRouteRootNode(NewRouteXML));
            //////}
            //////else
            //////{
            //////    //Now Add these 2 XMLs together
            //////    string MergedXML = ExistingRouteXML + "\n" + NewRouteXML;

            //////    //Now add Route root node & XML Prolog to this new MergedXML
            //////    MergedXML = _SetXMLProlog(_SetRouteRootNode(MergedXML));

            //////    //Now send it back to Filer
            //////    return MergedXML;
            //////}
        }

        public void DeleteExistingRoutesXML(string ExistingRouteXML, string DeleteRouteXML, out string NewXML, out bool AnyNodesLeft)
        {
            _DeleteExistingRoutesXML(ExistingRouteXML, DeleteRouteXML, out NewXML, out AnyNodesLeft);
        }
        private void _DeleteExistingRoutesXML(string ExistingRouteXML, string DeleteRouteXML, out string NewXML, out bool AnyNodesLeft)
        {
            //first remove XML Prolog.
            ExistingRouteXML = ExistingRouteXML.Replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "");
            //Now remove Openning Route node
            ExistingRouteXML = ExistingRouteXML.Replace("<Route>", "");
            //Now remove Closing Route node
            ExistingRouteXML = ExistingRouteXML.Replace("</Route>", "");

            //first remove XML Prolog.
            DeleteRouteXML = DeleteRouteXML.Replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "");
            //Now remove Openning Route node
            DeleteRouteXML = DeleteRouteXML.Replace("<Route>", "");
            //Now remove Closing Route node
            DeleteRouteXML = DeleteRouteXML.Replace("</Route>", "");

            ArrayList ListOfExistingNodes = new ArrayList();

            string Node = string.Empty;

            foreach (string Word in ExistingRouteXML.Split('\n'))
            {
                if (Word.Contains("<Vehicle>"))
                {
                    Node = Word + '\n';
                }
                else if (Word.Contains("</Vehicle>"))
                {
                    Node = Node + Word;

                    ListOfExistingNodes.Add(Node);

                    Node = string.Empty;
                }
                else
                {
                    Node = Node + Word + '\n';
                }
            }

            ArrayList CopyOfListOfExistingNodes = new ArrayList();

            foreach (string SingleNode in ListOfExistingNodes)
            {
                string SingleNodeWithoutFairAttribute = SingleNode.Replace("<StopFair>" + SingleNode.Between("<StopFair>", "</StopFair>") + "</StopFair>", string.Empty);
                SingleNodeWithoutFairAttribute = SingleNodeWithoutFairAttribute.Replace('\r', ' ');
                SingleNodeWithoutFairAttribute = SingleNodeWithoutFairAttribute.Replace('\n', ' ');
                SingleNodeWithoutFairAttribute = SingleNodeWithoutFairAttribute.Replace(" ", "");
                CopyOfListOfExistingNodes.Add(SingleNodeWithoutFairAttribute);
            }

            string DeleteRouteXMLWithoutFairAttribute = DeleteRouteXML.Replace("<StopFair>" + DeleteRouteXML.Between("<StopFair>", "</StopFair>") + "</StopFair>", string.Empty);
            DeleteRouteXMLWithoutFairAttribute = DeleteRouteXMLWithoutFairAttribute.Replace('\r', ' ');
            DeleteRouteXMLWithoutFairAttribute = DeleteRouteXMLWithoutFairAttribute.Replace('\n', ' ');
            DeleteRouteXMLWithoutFairAttribute = DeleteRouteXMLWithoutFairAttribute.Replace(" ", "");

            foreach (string SingleNode in CopyOfListOfExistingNodes)
            {
                if (SingleNode == DeleteRouteXMLWithoutFairAttribute)
                {
                    ListOfExistingNodes.RemoveAt(CopyOfListOfExistingNodes.IndexOf(SingleNode));
                }
            }

            if (ListOfExistingNodes.Count == 0)
            {
                AnyNodesLeft = false;

                NewXML = string.Empty;
            }
            else
            {
                AnyNodesLeft = true;
                NewXML = string.Empty;

                foreach (string SingleNode in ListOfExistingNodes)
                {
                    NewXML = NewXML + SingleNode + '\n';
                }

                NewXML = _SetXMLProlog(_SetRouteRootNode(NewXML));
            }
        }


        /// <summary>
        /// Will return an ArrayList of route combination for given Vehicle XML 
        /// </summary>
        /// <param name="XMLArray">Vehicle XML in string Array</param>
        /// <param name="VehicleType">Vehicle Type info</param>
        /// <param name="VehicleName">Vehicle Name info</param>
        /// <param name="TwoWay">Boolean confirm if Vehicle comesback on this route</param>
        /// <returns>Returns Array List containing Possible combinations of Routes</returns>
        public ArrayList GenerateRoutes(string[] XMLArray, string VehicleType, string VehicleName, string StopFair, bool TwoWay)
        {
            return _GenerateRoutes(XMLArray, VehicleType, VehicleName, StopFair, TwoWay);
        }
        public ArrayList GenerateRoutes(string[] XMLArray, string VehicleType, string VehicleName, string StopFair)
        {
            return _GenerateRoutes(XMLArray, VehicleType, VehicleName, StopFair, true);
        }
        private ArrayList _GenerateRoutes(string[] XMLArray, string VehicleType, string VehicleName, string StopFair, bool TwoWay)
        {
            ArrayList BusStopsNodes = new ArrayList();

            for (int i = 6; i < XMLArray.Length - 4; i = i + 5)
            {
                string NodeXML = XMLArray[i] + "\n"
                    + XMLArray[i + 1] + "\n"
                    + XMLArray[i + 2] + "\n"
                    + XMLArray[i + 3] + "\n"
                    + XMLArray[i + 4] + "\n";

                BusStopsNodes.Add(NodeXML);
            }

            ArrayList ListOfRoutes = new ArrayList();

            ListOfRoutes.AddRange(_GenerateForwardRoutesXML(BusStopsNodes, VehicleType, VehicleName, StopFair));

            if (TwoWay)
            {
                ListOfRoutes.AddRange(_GenerateBackwardRoutesXML(BusStopsNodes, VehicleType, VehicleName, StopFair));
            }

            return ListOfRoutes;
        }

        /// <summary>
        /// Generates forward route combinations
        /// </summary>
        /// <param name="BusStopsNodes">Array List containing Bus Stop Nodes</param>
        /// <param name="VehicleType">Vehicle Type info</param>
        /// <param name="VehicleName">Vehicle Name info</param>
        /// <returns>Returns Array List containing Possible forward combinations of Routes</returns>
        private ArrayList _GenerateForwardRoutesXML(ArrayList BusStopsNodes, string VehicleType, string VehicleName, string StopFair)
        {
            ArrayList SendBackDetails = new ArrayList();

            for (int i = 0; i < BusStopsNodes.Count - 1; i++)
            {
                ArrayList NodesList = new ArrayList();
                NodesList.Add(BusStopsNodes[i]);

                for (int j = i + 1; j < BusStopsNodes.Count; j++)
                {
                    NodesList.Add(BusStopsNodes[j]);

                    string RouteXML, StartPointName, EndPointName;

                    SetNodes(NodesList, out RouteXML, out StartPointName, out EndPointName);

                    RouteXML = _IdentateXML(_SetXMLProlog(_SetRouteRootNode(_SetVehicleRootNode(_PutVehicleType(_PutVehicleName(_PutStopFair(RouteXML, StopFair), VehicleName), VehicleType)))));

                    SendBackDetails.Add(new Details() { Content = RouteXML, StartPoint = StartPointName, EndPoint = EndPointName });
                }
            }

            return SendBackDetails;
        }
        /// <summary>
        /// Generates Backward route combinations
        /// </summary>
        /// <param name="BusStopsNodes">Array List containing Bus Stop Nodes</param>
        /// <param name="VehicleType">Vehicle Type info</param>
        /// <param name="VehicleName">Vehicle Name info</param>
        /// <returns>Returns Array List containing Possible backward combinations of Routes</returns>
        private ArrayList _GenerateBackwardRoutesXML(ArrayList BusStopsNodes, string VehicleType, string VehicleName, string StopFair)
        {
            ArrayList SendBackDetails = new ArrayList();

            for (int i = BusStopsNodes.Count - 1; i >= 0; i--)
            {
                ArrayList NodesList = new ArrayList();
                NodesList.Add(BusStopsNodes[i]);

                for (int j = i - 1; j >= 0; j--)
                {
                    NodesList.Add(BusStopsNodes[j]);

                    //here we should call SetNodes method
                    string RouteXML, StartPointName, EndPointName;

                    SetNodes(NodesList, out RouteXML, out StartPointName, out EndPointName);

                    RouteXML = _IdentateXML(_SetXMLProlog(_SetRouteRootNode(_SetVehicleRootNode(_PutVehicleType(_PutVehicleName(_PutStopFair(RouteXML, StopFair), VehicleName), VehicleType)))));

                    SendBackDetails.Add(new Details() { Content = RouteXML, StartPoint = StartPointName, EndPoint = EndPointName });
                }
            }
            return SendBackDetails;
        }
    }
}

