﻿namespace TransitTool
{
    class Details
    {
        public string FilePath;
        public string Content;
        public string Repeated;
        public string Status;
        public string Uploaded;
        public string StartPoint;
        public string EndPoint;
        public string VehicleType;
        public string VehicleName;
        public string Join;
        public string Extension;
        public bool Override;
        public int RowNumber;
        public string FileCreatedStatus;
        public int FileCreated;
        public int FileNotCreated;
        public string RootFolder;
        public string RouteFair;
        public string StopFair;
        public string RouteXML;

        public string FileDeletedStatus;
        public int FileDeleted;
        public int FileNotDeleted;


        public bool FileUploadedStatus;
        public int FileUploaded;
        public int FileNotUploaded;

        public int FileUploadRowNumber;

        public int NumberOfRows;

        public bool LocationsFileUploadedStatus;

        public string LocationsLocalFile, LocationsRemoteFile;
    }
}

