﻿namespace TransitTool
{
    class Vehicles
    {
        /// <summary>
        /// DataHandler is our class that we are using to get Data from Database
        /// </summary>
        DataHandler dataHandler;

        /// <summary>
        /// default Constructor
        /// </summary>
        public Vehicles()
        {
            //InitilizeVariables will initilize our variables
            InitilizeVariables();
        }

        /// <summary>
        /// Initilizing our important variables in this InitilizeVariables
        /// </summary>
        private void InitilizeVariables()
        {
            dataHandler = new DataHandler();
        }

        /// <summary>
        /// It will return All Names of Types of vehicles
        /// </summary>
        /// <returns>Returns string array of names of Vehicle Types</returns>
        public string[] GetVehicleTypes()
        {
            return _GetVehicleTypes();
        }
        private string[] _GetVehicleTypes()
        {
            return dataHandler.GetAllVehicleTypes();
        }

        /// <summary>
        /// it will return names of all vehicles from given Vehicle Type Name
        /// </summary>
        /// <param name="VehicleTypeName">Name of Vehicle Type to get vehicles from.</param>
        /// <returns>Returns string array of Vehicles Names for specified Vehicle Type</returns>
        public string[] GetVehiclesByTypeName(string VehicleTypeName)
        {
            return _GetVehiclesByTypeName(VehicleTypeName);
        }
        private string[] _GetVehiclesByTypeName(string VehicleTypeName)
        {
            return dataHandler.GetVehiclesByTypeName(VehicleTypeName);
        }

        /// <summary>
        /// it will return names of all vehicles from given Vehicle Type ID
        /// </summary>
        /// <param name="TypeID">Type ID to get Vehicles from</param>
        /// <returns>Returns a string array containing Vehicle Names from Specified Vehicle Type ID</returns>
        public string[] GetVehiclesByTypeID(int TypeID)
        {
            return _GetVehiclesByTypeID(TypeID);
        }
        private string[] _GetVehiclesByTypeID(int TypeID)
        {
            return dataHandler.GetVehiclesByTypeID(TypeID);
        }

        /// <summary>
        /// it will return ID of given vehicle type name
        /// </summary>
        /// <param name="VehicleTypeName">Vehicle Type Name to get its TypeID</param>
        /// <returns>Returns an integer of Vehicle TypeID</returns>
        public int GetVehicleTypeID(string VehicleTypeName)
        {
            return _GetVehicleTypeID(VehicleTypeName);
        }
        private int _GetVehicleTypeID(string VehicleTypeName)
        {
            return dataHandler.GetVehicleTypeID(VehicleTypeName);
        }

        public string GetVehicleRouteXML(string VehicleName, string VehicleType)
        {
            return _GetVehicleRouteXML(VehicleName, VehicleType);
        }
        private string _GetVehicleRouteXML(string VehicleName, string VehicleType)
        {
            return dataHandler.GetVehicleRoute(VehicleName, VehicleType);
        }

        public bool AddNewVehicleType(string VehicleType)
        {
            return _AddNewVehicleType(VehicleType);
        }
        private bool _AddNewVehicleType(string VehicleType)
        {
            return dataHandler.AddVehicleType(VehicleType);
        }

        public bool DeleteVehicleType(string VehicleType)
        {
            return _DeleteVehicleType(VehicleType);
        }
        private bool _DeleteVehicleType(string VehicleType)
        {
            return dataHandler.DeleteVehicleType(VehicleType);
        }

        public bool AddNewVehicle(string VehicleName, int TypeID)
        {
            return _AddNewVehicle(VehicleName, TypeID);
        }
        private bool _AddNewVehicle(string VehicleName, int TypeID)
        {
            return dataHandler.AddNewVehicle(VehicleName, TypeID);
        }

        public bool HandleVehicleRouteXML(string RouteXML, string StartPointName, string EndPointName, string VehicleName, string VehicleType)
        {
            return _HandleVehicleRouteXML(RouteXML, StartPointName, EndPointName, VehicleName, VehicleType);
        }
        private bool _HandleVehicleRouteXML(string RouteXML, string StartPointName, string EndPointName, string VehicleName, string VehicleType)
        {
            return dataHandler.AddRoute(RouteXML, StartPointName, EndPointName, dataHandler.GetVehicleID(VehicleName, VehicleType));
        }

        public bool DeleteVehicle(string VehicleType, string VehicleName)
        {
            return _DeleteVehicle(VehicleType, VehicleName);
        }
        private bool _DeleteVehicle(string VehicleType, string VehicleName)
        {
            return dataHandler.DeleteVehicle(VehicleType, VehicleName);
        }
    }
}

