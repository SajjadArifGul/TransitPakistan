﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace TransitTool
{
    public partial class DeleteVehicle : Form
    {
        string VehicleName, VehicleType;
        Vehicles vehicles;
        XMLHandler xmlHandler;
        Filer filer;
        Settings settings;

        public DeleteVehicle(string VehicleName, string VehicleType)
        {
            InitializeComponent();

            vehicles = new Vehicles();
            xmlHandler = new XMLHandler();
            filer = new Filer();
            settings = new Settings();

            this.VehicleName = VehicleName;
            this.VehicleType = VehicleType;
        }

        private void DeleteVehicle_Load(object sender, EventArgs e)
        {
            RoutesGridView.Rows.Clear();

            string RouteXML = vehicles.GetVehicleRouteXML(VehicleName, VehicleType);
            string StopFair = xmlHandler.GetStopFair(RouteXML);

            BackgroundWorker RouteGenerator = new BackgroundWorker();
            RouteGenerator.DoWork += new DoWorkEventHandler(RouteGenerator_DoWork);
            RouteGenerator.RunWorkerCompleted += (RouteGenerator_RunWorkerCompleted);

            RouteGenerator.RunWorkerAsync(new Details() { RouteXML = RouteXML, VehicleType = VehicleType, VehicleName = VehicleName, StopFair = StopFair });
        }

        private void RouteGenerator_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            Details details = (Details)e.Argument;

            string RouteXML = details.RouteXML;
            string VehicleType = details.VehicleType;
            string VehicleName = details.VehicleName;
            string StopFair = details.StopFair;

            e.Result = xmlHandler.GenerateRoutes(RouteXML.Split('\n'), VehicleType, VehicleName, StopFair);
        }

        private void RouteGenerator_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                // handle the error

            }
            else if (e.Cancelled)
            {
                // handle cancellation
            }
            else
            {
                ArrayList DataList = (ArrayList)e.Result;

                //RouteCombinationsLabel.Text = DataList.Count.ToString();

                foreach (Details details in DataList)
                {
                    RoutesGridView.Rows.Add(true, details.StartPoint, details.EndPoint, details.Content);
                }
            }
        }

        private void YesDeleteVehicleButton_Click(object sender, EventArgs e)
        {
            BackgroundWorker RoutesIterator = new BackgroundWorker();
            RoutesIterator.DoWork += new DoWorkEventHandler(RoutesIterator_DoWork);
            RoutesIterator.RunWorkerCompleted += (RoutesIterator_RunWorkerCompleted);

            RoutesIterator.RunWorkerAsync();

            //now delete the vehicle

            if (vehicles.DeleteVehicle(VehicleType, VehicleName))
            {
                this.Close();
            }
        }

        private void NoDontDeleteVehicleButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void RoutesIterator_DoWork(object sender, DoWorkEventArgs e)
        {
            foreach (DataGridViewRow Row in RoutesGridView.Rows)
            {
                if (Convert.ToBoolean(RoutesGridView.Rows[Row.Index].Cells["SelectAllColumn"].Value))
                {
                    BackgroundWorker RouteDeleter = new BackgroundWorker();
                    RouteDeleter.DoWork += new DoWorkEventHandler(RouteDeleter_DoWork);
                    RouteDeleter.RunWorkerCompleted += (RouteDeleter_RunWorkerCompleted);
                    RouteDeleter.RunWorkerAsync(new Details() { RowNumber = Row.Index, VehicleName = xmlHandler.GetVehicleName(Row.Cells["RouteDataColumn"].Value.ToString()), Content = Row.Cells["RouteDataColumn"].Value.ToString(), StartPoint = Row.Cells["StartPointColumn"].Value.ToString(), EndPoint = Row.Cells["EndPointColumn"].Value.ToString(), RootFolder = settings.GetRootFolder(), Join = settings.GetFileJoin(), Extension = settings.GetFileExtension() });
                }
            }
        }

        private void RoutesIterator_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                // handle the error
            }
            else if (e.Cancelled)
            {
                // handle cancellation
            }
        }

        private void RouteDeleter_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            Details details = (Details)e.Argument;

            e.Result = (new Details() { FileDeletedStatus = filer.DeleteRouteFile(details.VehicleName, details.Content, details.StartPoint, details.EndPoint, details.RootFolder, details.Join, details.Extension), RowNumber = details.RowNumber });
        }
        private void RouteDeleter_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                // handle the error
            }
            else if (e.Cancelled)
            {
                // handle cancellation
            }
            else
            {
                Details details = (Details)e.Result;

                RoutesGridView.Rows[details.RowNumber].Cells["StatusColumn"].Value = details.FileDeletedStatus;

                if ((details.FileDeletedStatus == "File Deleted") || (details.FileDeletedStatus == "Not Exists"))
                {
                    RoutesGridView.Rows[details.RowNumber].DefaultCellStyle.BackColor = Color.Red;
                }
                else if ((details.FileDeletedStatus == "Route Deleted"))
                {
                    if (RoutesGridView.Rows[details.RowNumber].DefaultCellStyle.BackColor == Color.Red)
                    {
                        RoutesGridView.Rows[details.RowNumber].DefaultCellStyle.BackColor = Color.FromArgb(76, 175, 80);
                    }
                }
            }
        }

        private void RoutesGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                if (RoutesGridView.Columns[e.ColumnIndex].Name == "RouteDataColumn")
                {
                    MessageBox.Show(RoutesGridView.Rows[e.RowIndex].Cells["RouteDataColumn"].Value.ToString());
                }
                else if (RoutesGridView.Columns[e.ColumnIndex].Name == "StatusColumn")
                {
                    BackgroundWorker RouteDeleter = new BackgroundWorker();
                    RouteDeleter.DoWork += new DoWorkEventHandler(RouteDeleter_DoWork);
                    RouteDeleter.RunWorkerCompleted += (RouteDeleter_RunWorkerCompleted);
                    RouteDeleter.RunWorkerAsync(new Details() { RowNumber = e.RowIndex, VehicleName = xmlHandler.GetVehicleName(RoutesGridView.Rows[e.RowIndex].Cells["RouteDataColumn"].Value.ToString()), Content = RoutesGridView.Rows[e.RowIndex].Cells["RouteDataColumn"].Value.ToString(), StartPoint = RoutesGridView.Rows[e.RowIndex].Cells["StartPointColumn"].Value.ToString(), EndPoint = RoutesGridView.Rows[e.RowIndex].Cells["EndPointColumn"].Value.ToString(), RootFolder = settings.GetRootFolder(), Join = settings.GetFileJoin(), Extension = settings.GetFileExtension() });
                }
            }
        }
    }
}
