﻿namespace TransitTool
{
    partial class DeleteVehicle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.RoutesGridView = new System.Windows.Forms.DataGridView();
            this.SelectAllColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.StartPointColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EndPointColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RouteDataColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StatusColumn = new System.Windows.Forms.DataGridViewButtonColumn();
            this.panel17 = new System.Windows.Forms.Panel();
            this.NoDontDeleteVehicleButton = new System.Windows.Forms.Button();
            this.YesDeleteVehicleButton = new System.Windows.Forms.Button();
            this.label33 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.RoutesGridView)).BeginInit();
            this.panel17.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // RoutesGridView
            // 
            this.RoutesGridView.AllowUserToAddRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(142)))), ((int)(((byte)(60)))));
            this.RoutesGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.RoutesGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.RoutesGridView.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.RoutesGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.RoutesGridView.CausesValidation = false;
            this.RoutesGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(142)))), ((int)(((byte)(60)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.RoutesGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.RoutesGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.RoutesGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SelectAllColumn,
            this.StartPointColumn,
            this.EndPointColumn,
            this.RouteDataColumn,
            this.StatusColumn});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(229)))), ((int)(((byte)(252)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.RoutesGridView.DefaultCellStyle = dataGridViewCellStyle3;
            this.RoutesGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RoutesGridView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke;
            this.RoutesGridView.EnableHeadersVisualStyles = false;
            this.RoutesGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(187)))), ((int)(((byte)(102)))));
            this.RoutesGridView.Location = new System.Drawing.Point(0, 0);
            this.RoutesGridView.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RoutesGridView.Name = "RoutesGridView";
            this.RoutesGridView.RowHeadersVisible = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.RoutesGridView.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.RoutesGridView.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.RoutesGridView.Size = new System.Drawing.Size(721, 308);
            this.RoutesGridView.TabIndex = 24;
            this.RoutesGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.RoutesGridView_CellContentClick);
            // 
            // SelectAllColumn
            // 
            this.SelectAllColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.SelectAllColumn.FillWeight = 35F;
            this.SelectAllColumn.HeaderText = "All";
            this.SelectAllColumn.Name = "SelectAllColumn";
            this.SelectAllColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.SelectAllColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.SelectAllColumn.Width = 35;
            // 
            // StartPointColumn
            // 
            this.StartPointColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.StartPointColumn.FillWeight = 200F;
            this.StartPointColumn.HeaderText = "Start Point";
            this.StartPointColumn.Name = "StartPointColumn";
            this.StartPointColumn.Width = 200;
            // 
            // EndPointColumn
            // 
            this.EndPointColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.EndPointColumn.FillWeight = 200F;
            this.EndPointColumn.HeaderText = "End Point";
            this.EndPointColumn.Name = "EndPointColumn";
            this.EndPointColumn.Width = 200;
            // 
            // RouteDataColumn
            // 
            this.RouteDataColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.RouteDataColumn.FillWeight = 300F;
            this.RouteDataColumn.HeaderText = "Route Data";
            this.RouteDataColumn.Name = "RouteDataColumn";
            // 
            // StatusColumn
            // 
            this.StatusColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.StatusColumn.FillWeight = 80F;
            this.StatusColumn.HeaderText = "Status";
            this.StatusColumn.Name = "StatusColumn";
            this.StatusColumn.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.StatusColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.StatusColumn.Width = 80;
            // 
            // panel17
            // 
            this.panel17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel17.Controls.Add(this.NoDontDeleteVehicleButton);
            this.panel17.Controls.Add(this.YesDeleteVehicleButton);
            this.panel17.Controls.Add(this.label33);
            this.panel17.Location = new System.Drawing.Point(5, 6);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(723, 64);
            this.panel17.TabIndex = 36;
            // 
            // NoDontDeleteVehicleButton
            // 
            this.NoDontDeleteVehicleButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(142)))), ((int)(((byte)(60)))));
            this.NoDontDeleteVehicleButton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.NoDontDeleteVehicleButton.FlatAppearance.BorderSize = 0;
            this.NoDontDeleteVehicleButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.NoDontDeleteVehicleButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(117)))), ((int)(((byte)(50)))));
            this.NoDontDeleteVehicleButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NoDontDeleteVehicleButton.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.NoDontDeleteVehicleButton.Location = new System.Drawing.Point(371, 33);
            this.NoDontDeleteVehicleButton.Name = "NoDontDeleteVehicleButton";
            this.NoDontDeleteVehicleButton.Size = new System.Drawing.Size(339, 23);
            this.NoDontDeleteVehicleButton.TabIndex = 20;
            this.NoDontDeleteVehicleButton.Text = "No Don\'t Delete Vehicle";
            this.NoDontDeleteVehicleButton.UseVisualStyleBackColor = false;
            this.NoDontDeleteVehicleButton.Click += new System.EventHandler(this.NoDontDeleteVehicleButton_Click);
            // 
            // YesDeleteVehicleButton
            // 
            this.YesDeleteVehicleButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(142)))), ((int)(((byte)(60)))));
            this.YesDeleteVehicleButton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.YesDeleteVehicleButton.FlatAppearance.BorderSize = 0;
            this.YesDeleteVehicleButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(102)))), ((int)(((byte)(44)))));
            this.YesDeleteVehicleButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(117)))), ((int)(((byte)(50)))));
            this.YesDeleteVehicleButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.YesDeleteVehicleButton.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.YesDeleteVehicleButton.Location = new System.Drawing.Point(10, 33);
            this.YesDeleteVehicleButton.Name = "YesDeleteVehicleButton";
            this.YesDeleteVehicleButton.Size = new System.Drawing.Size(339, 23);
            this.YesDeleteVehicleButton.TabIndex = 19;
            this.YesDeleteVehicleButton.Text = "Yes Delete Vehicle";
            this.YesDeleteVehicleButton.UseVisualStyleBackColor = false;
            this.YesDeleteVehicleButton.Click += new System.EventHandler(this.YesDeleteVehicleButton_Click);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label33.Location = new System.Drawing.Point(10, 9);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(703, 15);
            this.label33.TabIndex = 15;
            this.label33.Text = "Are you sure you want to delete this Vehicle? You are about to delete Data with f" +
    "ollowing Routes. This process will be irreversible.";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.RoutesGridView);
            this.panel1.Location = new System.Drawing.Point(5, 77);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(723, 310);
            this.panel1.TabIndex = 37;
            // 
            // DeleteVehicle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.ClientSize = new System.Drawing.Size(733, 392);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel17);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "DeleteVehicle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Are you sure you want to delete this Vehicle?";
            this.Load += new System.EventHandler(this.DeleteVehicle_Load);
            ((System.ComponentModel.ISupportInitialize)(this.RoutesGridView)).EndInit();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.DataGridView RoutesGridView;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Button YesDeleteVehicleButton;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button NoDontDeleteVehicleButton;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn SelectAllColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn StartPointColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn EndPointColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn RouteDataColumn;
        private System.Windows.Forms.DataGridViewButtonColumn StatusColumn;
    }
}