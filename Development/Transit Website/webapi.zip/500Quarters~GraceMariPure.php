<?php
$xml = file_get_contents('../karachi/routes/500Quarters/GraceMariPure/500Quarters~GraceMariPure.xml');
$xml = trim( $xml );
echo $xml;
?>