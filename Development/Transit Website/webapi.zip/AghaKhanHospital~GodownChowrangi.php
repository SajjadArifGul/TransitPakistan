<?php
$xml = file_get_contents('../karachi/routes/AghaKhanHospital/GodownChowrangi/AghaKhanHospital~GodownChowrangi.xml');
$xml = trim( $xml );
echo $xml;
?>