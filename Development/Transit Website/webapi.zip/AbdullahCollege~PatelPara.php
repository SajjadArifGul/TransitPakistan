<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/PatelPara/AbdullahCollege~PatelPara.xml');
$xml = trim( $xml );
echo $xml;
?>