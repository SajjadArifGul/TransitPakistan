<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/Garden/AbdullahShahGhazi~Garden.xml');
$xml = trim( $xml );
echo $xml;
?>