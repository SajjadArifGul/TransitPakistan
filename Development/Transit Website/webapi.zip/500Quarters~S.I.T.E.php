<?php
$xml = file_get_contents('../karachi/routes/500Quarters/S.I.T.E/500Quarters~S.I.T.E.xml');
$xml = trim( $xml );
echo $xml;
?>