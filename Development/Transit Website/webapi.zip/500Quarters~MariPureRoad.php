<?php
$xml = file_get_contents('../karachi/routes/500Quarters/MariPureRoad/500Quarters~MariPureRoad.xml');
$xml = trim( $xml );
echo $xml;
?>