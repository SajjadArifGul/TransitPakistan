<?php
$xml = file_get_contents('../karachi/routes/2Talwar/PoliceTrainingSchool/2Talwar~PoliceTrainingSchool.xml');
$xml = trim( $xml );
echo $xml;
?>