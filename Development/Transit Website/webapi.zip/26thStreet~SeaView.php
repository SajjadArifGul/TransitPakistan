<?php
$xml = file_get_contents('../karachi/routes/26thStreet/SeaView/26thStreet~SeaView.xml');
$xml = trim( $xml );
echo $xml;
?>