<?php
$xml = file_get_contents('../karachi/routes/3Talwar/Valika/3Talwar~Valika.xml');
$xml = trim( $xml );
echo $xml;
?>