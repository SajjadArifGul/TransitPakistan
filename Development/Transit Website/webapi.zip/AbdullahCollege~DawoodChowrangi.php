<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/DawoodChowrangi/AbdullahCollege~DawoodChowrangi.xml');
$xml = trim( $xml );
echo $xml;
?>