<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/KhawajAjmerNagri/AbdullahCollege~KhawajAjmerNagri.xml');
$xml = trim( $xml );
echo $xml;
?>