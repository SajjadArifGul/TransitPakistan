<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/AgraTajColony/AbdullahShahGhaziRoad~AgraTajColony.xml');
$xml = trim( $xml );
echo $xml;
?>