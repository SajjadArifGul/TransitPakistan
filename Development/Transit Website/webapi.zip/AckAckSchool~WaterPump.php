<?php
$xml = file_get_contents('../karachi/routes/AckAckSchool/WaterPump/AckAckSchool~WaterPump.xml');
$xml = trim( $xml );
echo $xml;
?>