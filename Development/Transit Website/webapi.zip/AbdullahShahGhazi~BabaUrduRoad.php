<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/BabaUrduRoad/AbdullahShahGhazi~BabaUrduRoad.xml');
$xml = trim( $xml );
echo $xml;
?>