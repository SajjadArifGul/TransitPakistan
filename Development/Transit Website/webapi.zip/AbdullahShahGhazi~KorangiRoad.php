<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/KorangiRoad/AbdullahShahGhazi~KorangiRoad.xml');
$xml = trim( $xml );
echo $xml;
?>