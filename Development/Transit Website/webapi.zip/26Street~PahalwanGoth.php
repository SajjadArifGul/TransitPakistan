<?php
$xml = file_get_contents('../karachi/routes/26Street/PahalwanGoth/26Street~PahalwanGoth.xml');
$xml = trim( $xml );
echo $xml;
?>