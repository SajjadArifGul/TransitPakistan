<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/Shahrah-e-Quaideen/7thDayHospital~Shahrah-e-Quaideen.xml');
$xml = trim( $xml );
echo $xml;
?>