<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/Keamari/AbdullahShahGhaziRoad~Keamari.xml');
$xml = trim( $xml );
echo $xml;
?>