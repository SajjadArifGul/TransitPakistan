<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/Karimabad/7thDayHospital~Karimabad.xml');
$xml = trim( $xml );
echo $xml;
?>