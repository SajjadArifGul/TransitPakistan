<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/Gulshan-e-Ghazi/AbdullahShahGhaziRoad~Gulshan-e-Ghazi.xml');
$xml = trim( $xml );
echo $xml;
?>