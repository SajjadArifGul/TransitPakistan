<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/Tower/AbdullahShahGhaziRoad~Tower.xml');
$xml = trim( $xml );
echo $xml;
?>