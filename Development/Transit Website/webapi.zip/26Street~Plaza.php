<?php
$xml = file_get_contents('../karachi/routes/26Street/Plaza/26Street~Plaza.xml');
$xml = trim( $xml );
echo $xml;
?>