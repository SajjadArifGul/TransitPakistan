<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/7thDayHospital/AbdullahShahGhazi~7thDayHospital.xml');
$xml = trim( $xml );
echo $xml;
?>