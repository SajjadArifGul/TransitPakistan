<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/Hyderi/AbdullahCollege~Hyderi.xml');
$xml = trim( $xml );
echo $xml;
?>