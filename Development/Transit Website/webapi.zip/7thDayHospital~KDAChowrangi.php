<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/KDAChowrangi/7thDayHospital~KDAChowrangi.xml');
$xml = trim( $xml );
echo $xml;
?>