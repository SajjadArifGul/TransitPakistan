<?php
$xml = file_get_contents('../karachi/routes/500Quarters/Tower/500Quarters~Tower.xml');
$xml = trim( $xml );
echo $xml;
?>