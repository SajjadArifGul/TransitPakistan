<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/CityPostOffice/7thDayHospital~CityPostOffice.xml');
$xml = trim( $xml );
echo $xml;
?>