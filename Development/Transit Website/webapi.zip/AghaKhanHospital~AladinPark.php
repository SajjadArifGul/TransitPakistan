<?php
$xml = file_get_contents('../karachi/routes/AghaKhanHospital/AladinPark/AghaKhanHospital~AladinPark.xml');
$xml = trim( $xml );
echo $xml;
?>