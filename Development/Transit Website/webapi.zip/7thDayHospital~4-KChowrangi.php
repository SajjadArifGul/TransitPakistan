<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/4-KChowrangi/7thDayHospital~4-KChowrangi.xml');
$xml = trim( $xml );
echo $xml;
?>