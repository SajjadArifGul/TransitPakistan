<?php
$xml = file_get_contents('../karachi/routes/2Talwar/SchonChowrangi/2Talwar~SchonChowrangi.xml');
$xml = trim( $xml );
echo $xml;
?>