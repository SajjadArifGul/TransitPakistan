<?php
$xml = file_get_contents('../karachi/routes/3Talwar/Garden/3Talwar~Garden.xml');
$xml = trim( $xml );
echo $xml;
?>