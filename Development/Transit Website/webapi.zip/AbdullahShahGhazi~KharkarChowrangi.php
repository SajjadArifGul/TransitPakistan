<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/KharkarChowrangi/AbdullahShahGhazi~KharkarChowrangi.xml');
$xml = trim( $xml );
echo $xml;
?>