<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/DefenceMor/AbdullahShahGhaziRoad~DefenceMor.xml');
$xml = trim( $xml );
echo $xml;
?>