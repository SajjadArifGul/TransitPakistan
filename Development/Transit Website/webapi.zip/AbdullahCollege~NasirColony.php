<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/NasirColony/AbdullahCollege~NasirColony.xml');
$xml = trim( $xml );
echo $xml;
?>