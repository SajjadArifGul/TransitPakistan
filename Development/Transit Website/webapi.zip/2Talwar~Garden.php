<?php
$xml = file_get_contents('../karachi/routes/2Talwar/Garden/2Talwar~Garden.xml');
$xml = trim( $xml );
echo $xml;
?>