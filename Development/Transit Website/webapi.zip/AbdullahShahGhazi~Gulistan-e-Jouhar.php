<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/Gulistan-e-Jouhar/AbdullahShahGhazi~Gulistan-e-Jouhar.xml');
$xml = trim( $xml );
echo $xml;
?>