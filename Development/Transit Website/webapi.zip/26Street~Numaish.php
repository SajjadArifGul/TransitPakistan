<?php
$xml = file_get_contents('../karachi/routes/26Street/Numaish/26Street~Numaish.xml');
$xml = trim( $xml );
echo $xml;
?>