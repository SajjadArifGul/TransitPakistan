<?php
$xml = file_get_contents('../karachi/routes/500Quarters/CityStation/500Quarters~CityStation.xml');
$xml = trim( $xml );
echo $xml;
?>