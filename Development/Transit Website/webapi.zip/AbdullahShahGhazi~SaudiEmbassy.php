<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/SaudiEmbassy/AbdullahShahGhazi~SaudiEmbassy.xml');
$xml = trim( $xml );
echo $xml;
?>