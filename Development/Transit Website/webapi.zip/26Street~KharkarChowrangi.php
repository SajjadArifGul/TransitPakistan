<?php
$xml = file_get_contents('../karachi/routes/26Street/KharkarChowrangi/26Street~KharkarChowrangi.xml');
$xml = trim( $xml );
echo $xml;
?>