<?php
$xml = file_get_contents('../karachi/routes/2Talwar/Valika/2Talwar~Valika.xml');
$xml = trim( $xml );
echo $xml;
?>