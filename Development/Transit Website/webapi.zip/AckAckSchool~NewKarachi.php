<?php
$xml = file_get_contents('../karachi/routes/AckAckSchool/NewKarachi/AckAckSchool~NewKarachi.xml');
$xml = trim( $xml );
echo $xml;
?>