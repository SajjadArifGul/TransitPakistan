<?php
$xml = file_get_contents('../karachi/routes/AbbasiShaheedHospital/IslamChowk/AbbasiShaheedHospital~IslamChowk.xml');
$xml = trim( $xml );
echo $xml;
?>