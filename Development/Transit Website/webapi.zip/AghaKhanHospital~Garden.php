<?php
$xml = file_get_contents('../karachi/routes/AghaKhanHospital/Garden/AghaKhanHospital~Garden.xml');
$xml = trim( $xml );
echo $xml;
?>