<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/SunsetBoulevard/AbdullahShahGhazi~SunsetBoulevard.xml');
$xml = trim( $xml );
echo $xml;
?>