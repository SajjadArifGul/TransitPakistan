<?php
$xml = file_get_contents('../karachi/routes/AbbasiShaheedHospital/OrangiNo11A½/AbbasiShaheedHospital~OrangiNo11A½.xml');
$xml = trim( $xml );
echo $xml;
?>