<?php
$xml = file_get_contents('../karachi/routes/26Street/BilawalHouse/26Street~BilawalHouse.xml');
$xml = trim( $xml );
echo $xml;
?>