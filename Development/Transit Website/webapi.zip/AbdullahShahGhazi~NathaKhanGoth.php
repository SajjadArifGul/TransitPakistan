<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/NathaKhanGoth/AbdullahShahGhazi~NathaKhanGoth.xml');
$xml = trim( $xml );
echo $xml;
?>