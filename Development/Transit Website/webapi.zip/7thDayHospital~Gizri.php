<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/Gizri/7thDayHospital~Gizri.xml');
$xml = trim( $xml );
echo $xml;
?>