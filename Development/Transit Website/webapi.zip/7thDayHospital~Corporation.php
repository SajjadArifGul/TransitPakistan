<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/Corporation/7thDayHospital~Corporation.xml');
$xml = trim( $xml );
echo $xml;
?>