<?php
$xml = file_get_contents('../karachi/routes/26thStreet/BoardOffice/26thStreet~BoardOffice.xml');
$xml = trim( $xml );
echo $xml;
?>