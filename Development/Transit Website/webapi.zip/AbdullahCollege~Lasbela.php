<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/Lasbela/AbdullahCollege~Lasbela.xml');
$xml = trim( $xml );
echo $xml;
?>