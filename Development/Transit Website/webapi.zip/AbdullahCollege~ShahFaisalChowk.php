<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/ShahFaisalChowk/AbdullahCollege~ShahFaisalChowk.xml');
$xml = trim( $xml );
echo $xml;
?>