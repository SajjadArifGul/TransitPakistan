<?php
$xml = file_get_contents('../karachi/routes/26thStreet/Hyderi/26thStreet~Hyderi.xml');
$xml = trim( $xml );
echo $xml;
?>