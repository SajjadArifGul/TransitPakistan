<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/BilawalHouse/AbdullahShahGhaziRoad~BilawalHouse.xml');
$xml = trim( $xml );
echo $xml;
?>