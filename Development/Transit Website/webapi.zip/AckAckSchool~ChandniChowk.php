<?php
$xml = file_get_contents('../karachi/routes/AckAckSchool/ChandniChowk/AckAckSchool~ChandniChowk.xml');
$xml = trim( $xml );
echo $xml;
?>