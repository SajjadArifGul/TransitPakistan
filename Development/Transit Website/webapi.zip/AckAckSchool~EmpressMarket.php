<?php
$xml = file_get_contents('../karachi/routes/AckAckSchool/EmpressMarket/AckAckSchool~EmpressMarket.xml');
$xml = trim( $xml );
echo $xml;
?>