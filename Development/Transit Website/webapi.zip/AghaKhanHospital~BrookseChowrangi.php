<?php
$xml = file_get_contents('../karachi/routes/AghaKhanHospital/BrookseChowrangi/AghaKhanHospital~BrookseChowrangi.xml');
$xml = trim( $xml );
echo $xml;
?>