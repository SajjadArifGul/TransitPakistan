<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/Metroville/AbdullahShahGhaziRoad~Metroville.xml');
$xml = trim( $xml );
echo $xml;
?>