<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/SultanMasjid/AbdullahShahGhaziRoad~SultanMasjid.xml');
$xml = trim( $xml );
echo $xml;
?>