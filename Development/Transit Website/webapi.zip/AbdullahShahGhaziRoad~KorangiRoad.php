<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/KorangiRoad/AbdullahShahGhaziRoad~KorangiRoad.xml');
$xml = trim( $xml );
echo $xml;
?>