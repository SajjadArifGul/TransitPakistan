<?php
$xml = file_get_contents('../karachi/routes/3Talwar/HubRiverRoad/3Talwar~HubRiverRoad.xml');
$xml = trim( $xml );
echo $xml;
?>