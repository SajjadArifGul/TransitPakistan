<?php
$xml = file_get_contents('../karachi/routes/3Talwar/Saddar/3Talwar~Saddar.xml');
$xml = trim( $xml );
echo $xml;
?>