<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/MuzaffarabadColony/7thDayHospital~MuzaffarabadColony.xml');
$xml = trim( $xml );
echo $xml;
?>