<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/FaqeerColony/7thDayHospital~FaqeerColony.xml');
$xml = trim( $xml );
echo $xml;
?>