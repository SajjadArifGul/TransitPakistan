<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/NusratBhuttoColony/AbdullahCollege~NusratBhuttoColony.xml');
$xml = trim( $xml );
echo $xml;
?>