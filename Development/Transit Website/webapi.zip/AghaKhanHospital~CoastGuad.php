<?php
$xml = file_get_contents('../karachi/routes/AghaKhanHospital/CoastGuad/AghaKhanHospital~CoastGuad.xml');
$xml = trim( $xml );
echo $xml;
?>