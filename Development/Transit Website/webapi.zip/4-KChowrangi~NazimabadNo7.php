<?php
$xml = file_get_contents('../karachi/routes/4-KChowrangi/NazimabadNo7/4-KChowrangi~NazimabadNo7.xml');
$xml = trim( $xml );
echo $xml;
?>