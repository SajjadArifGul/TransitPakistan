<?php
$xml = file_get_contents('../karachi/routes/4-KChowrangi/Lasbela/4-KChowrangi~Lasbela.xml');
$xml = trim( $xml );
echo $xml;
?>