<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/MurtazaChowrangi/7thDayHospital~MurtazaChowrangi.xml');
$xml = trim( $xml );
echo $xml;
?>