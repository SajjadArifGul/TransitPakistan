<?php
$xml = file_get_contents('../karachi/routes/2Talwar/SaeedabadNaiabadiSector-8/2Talwar~SaeedabadNaiabadiSector-8.xml');
$xml = trim( $xml );
echo $xml;
?>