<?php
$xml = file_get_contents('../karachi/routes/AghaKhanHospital/GhasMandi/AghaKhanHospital~GhasMandi.xml');
$xml = trim( $xml );
echo $xml;
?>