<?php
$xml = file_get_contents('../karachi/routes/4-KChowrangi/SakhiHassan/4-KChowrangi~SakhiHassan.xml');
$xml = trim( $xml );
echo $xml;
?>