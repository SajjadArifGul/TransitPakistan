<?php
$xml = file_get_contents('../karachi/routes/500Quarters/HabibBank/500Quarters~HabibBank.xml');
$xml = trim( $xml );
echo $xml;
?>