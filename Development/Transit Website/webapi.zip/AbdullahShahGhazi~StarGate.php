<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/StarGate/AbdullahShahGhazi~StarGate.xml');
$xml = trim( $xml );
echo $xml;
?>