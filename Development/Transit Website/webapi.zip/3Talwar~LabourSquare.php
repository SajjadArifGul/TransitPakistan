<?php
$xml = file_get_contents('../karachi/routes/3Talwar/LabourSquare/3Talwar~LabourSquare.xml');
$xml = trim( $xml );
echo $xml;
?>