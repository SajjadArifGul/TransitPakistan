<?php
$xml = file_get_contents('../karachi/routes/AckAckSchool/LiaquatabadNo10/AckAckSchool~LiaquatabadNo10.xml');
$xml = trim( $xml );
echo $xml;
?>