<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/HabibChowrangi/AbdullahShahGhaziRoad~HabibChowrangi.xml');
$xml = trim( $xml );
echo $xml;
?>