<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/BoardOffice/7thDayHospital~BoardOffice.xml');
$xml = trim( $xml );
echo $xml;
?>