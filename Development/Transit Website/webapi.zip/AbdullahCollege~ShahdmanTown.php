<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/ShahdmanTown/AbdullahCollege~ShahdmanTown.xml');
$xml = trim( $xml );
echo $xml;
?>