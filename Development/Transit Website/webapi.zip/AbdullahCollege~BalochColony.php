<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/BalochColony/AbdullahCollege~BalochColony.xml');
$xml = trim( $xml );
echo $xml;
?>