<?php
$xml = file_get_contents('../karachi/routes/26thStreet/AbdullahShahGhazi/26thStreet~AbdullahShahGhazi.xml');
$xml = trim( $xml );
echo $xml;
?>