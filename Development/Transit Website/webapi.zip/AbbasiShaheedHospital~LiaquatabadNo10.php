<?php
$xml = file_get_contents('../karachi/routes/AbbasiShaheedHospital/LiaquatabadNo10/AbbasiShaheedHospital~LiaquatabadNo10.xml');
$xml = trim( $xml );
echo $xml;
?>