<?php
$xml = file_get_contents('../karachi/routes/3Talwar/2Talwar/3Talwar~2Talwar.xml');
$xml = trim( $xml );
echo $xml;
?>