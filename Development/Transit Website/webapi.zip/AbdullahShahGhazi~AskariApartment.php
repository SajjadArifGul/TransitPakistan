<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/AskariApartment/AbdullahShahGhazi~AskariApartment.xml');
$xml = trim( $xml );
echo $xml;
?>