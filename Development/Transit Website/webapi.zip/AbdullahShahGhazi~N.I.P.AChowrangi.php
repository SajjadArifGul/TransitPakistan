<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/N.I.P.AChowrangi/AbdullahShahGhazi~N.I.P.AChowrangi.xml');
$xml = trim( $xml );
echo $xml;
?>