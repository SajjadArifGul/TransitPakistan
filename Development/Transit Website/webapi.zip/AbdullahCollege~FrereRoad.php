<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/FrereRoad/AbdullahCollege~FrereRoad.xml');
$xml = trim( $xml );
echo $xml;
?>