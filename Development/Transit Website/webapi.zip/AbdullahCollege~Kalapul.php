<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/Kalapul/AbdullahCollege~Kalapul.xml');
$xml = trim( $xml );
echo $xml;
?>