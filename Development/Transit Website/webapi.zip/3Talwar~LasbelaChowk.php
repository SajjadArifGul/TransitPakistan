<?php
$xml = file_get_contents('../karachi/routes/3Talwar/LasbelaChowk/3Talwar~LasbelaChowk.xml');
$xml = trim( $xml );
echo $xml;
?>