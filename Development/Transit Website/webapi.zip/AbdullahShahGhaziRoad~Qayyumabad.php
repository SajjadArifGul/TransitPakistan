<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/Qayyumabad/AbdullahShahGhaziRoad~Qayyumabad.xml');
$xml = trim( $xml );
echo $xml;
?>