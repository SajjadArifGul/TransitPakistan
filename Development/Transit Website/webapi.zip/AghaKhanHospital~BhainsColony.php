<?php
$xml = file_get_contents('../karachi/routes/AghaKhanHospital/BhainsColony/AghaKhanHospital~BhainsColony.xml');
$xml = trim( $xml );
echo $xml;
?>