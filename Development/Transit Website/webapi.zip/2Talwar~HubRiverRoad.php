<?php
$xml = file_get_contents('../karachi/routes/2Talwar/HubRiverRoad/2Talwar~HubRiverRoad.xml');
$xml = trim( $xml );
echo $xml;
?>