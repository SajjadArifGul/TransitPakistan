<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/N.I.P.AChowrangi/AbdullahShahGhaziRoad~N.I.P.AChowrangi.xml');
$xml = trim( $xml );
echo $xml;
?>