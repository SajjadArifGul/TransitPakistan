<?php
$xml = file_get_contents('../karachi/routes/500Quarters/CustomHouse/500Quarters~CustomHouse.xml');
$xml = trim( $xml );
echo $xml;
?>