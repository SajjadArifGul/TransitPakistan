<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/ParsiColony/7thDayHospital~ParsiColony.xml');
$xml = trim( $xml );
echo $xml;
?>