<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/LalMarket/7thDayHospital~LalMarket.xml');
$xml = trim( $xml );
echo $xml;
?>