<?php
$xml = file_get_contents('../karachi/routes/2Talwar/HabibBank/2Talwar~HabibBank.xml');
$xml = trim( $xml );
echo $xml;
?>