<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/Mazar-e-Quaid/AbdullahShahGhaziRoad~Mazar-e-Quaid.xml');
$xml = trim( $xml );
echo $xml;
?>