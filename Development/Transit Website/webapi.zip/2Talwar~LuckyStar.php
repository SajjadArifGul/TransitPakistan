<?php
$xml = file_get_contents('../karachi/routes/2Talwar/LuckyStar/2Talwar~LuckyStar.xml');
$xml = trim( $xml );
echo $xml;
?>