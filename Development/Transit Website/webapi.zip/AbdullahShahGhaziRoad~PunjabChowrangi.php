<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/PunjabChowrangi/AbdullahShahGhaziRoad~PunjabChowrangi.xml');
$xml = trim( $xml );
echo $xml;
?>