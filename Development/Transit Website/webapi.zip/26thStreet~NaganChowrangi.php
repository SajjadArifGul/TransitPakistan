<?php
$xml = file_get_contents('../karachi/routes/26thStreet/NaganChowrangi/26thStreet~NaganChowrangi.xml');
$xml = trim( $xml );
echo $xml;
?>