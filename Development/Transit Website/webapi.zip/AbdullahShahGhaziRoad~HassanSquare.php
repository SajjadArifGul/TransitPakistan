<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/HassanSquare/AbdullahShahGhaziRoad~HassanSquare.xml');
$xml = trim( $xml );
echo $xml;
?>