<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/N.I.P.A/7thDayHospital~N.I.P.A.xml');
$xml = trim( $xml );
echo $xml;
?>