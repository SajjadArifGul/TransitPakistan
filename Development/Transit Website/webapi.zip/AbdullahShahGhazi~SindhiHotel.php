<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/SindhiHotel/AbdullahShahGhazi~SindhiHotel.xml');
$xml = trim( $xml );
echo $xml;
?>