<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/QasbaColony/7thDayHospital~QasbaColony.xml');
$xml = trim( $xml );
echo $xml;
?>