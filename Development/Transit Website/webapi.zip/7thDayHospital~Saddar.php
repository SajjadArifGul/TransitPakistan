<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/Saddar/7thDayHospital~Saddar.xml');
$xml = trim( $xml );
echo $xml;
?>