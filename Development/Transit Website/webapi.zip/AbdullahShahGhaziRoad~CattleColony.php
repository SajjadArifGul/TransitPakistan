<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/CattleColony/AbdullahShahGhaziRoad~CattleColony.xml');
$xml = trim( $xml );
echo $xml;
?>