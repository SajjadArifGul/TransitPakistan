<?php
$xml = file_get_contents('../karachi/routes/AbbasiShaheedHospital/MalirCity/AbbasiShaheedHospital~MalirCity.xml');
$xml = trim( $xml );
echo $xml;
?>