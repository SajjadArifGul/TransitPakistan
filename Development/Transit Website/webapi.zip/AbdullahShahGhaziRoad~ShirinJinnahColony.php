<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/ShirinJinnahColony/AbdullahShahGhaziRoad~ShirinJinnahColony.xml');
$xml = trim( $xml );
echo $xml;
?>