<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/OrangiNo14/AbdullahCollege~OrangiNo14.xml');
$xml = trim( $xml );
echo $xml;
?>