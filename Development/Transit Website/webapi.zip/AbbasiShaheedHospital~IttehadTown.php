<?php
$xml = file_get_contents('../karachi/routes/AbbasiShaheedHospital/IttehadTown/AbbasiShaheedHospital~IttehadTown.xml');
$xml = trim( $xml );
echo $xml;
?>