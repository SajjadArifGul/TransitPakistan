<?php
$xml = file_get_contents('../karachi/routes/AbbasiShaheedHospital/NazimabadPetrolPump/AbbasiShaheedHospital~NazimabadPetrolPump.xml');
$xml = trim( $xml );
echo $xml;
?>