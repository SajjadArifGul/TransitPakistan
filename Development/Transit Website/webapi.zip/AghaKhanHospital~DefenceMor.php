<?php
$xml = file_get_contents('../karachi/routes/AghaKhanHospital/DefenceMor/AghaKhanHospital~DefenceMor.xml');
$xml = trim( $xml );
echo $xml;
?>