<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/WaterPump/AbdullahCollege~WaterPump.xml');
$xml = trim( $xml );
echo $xml;
?>