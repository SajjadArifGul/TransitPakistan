<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/Defence/AbdullahCollege~Defence.xml');
$xml = trim( $xml );
echo $xml;
?>