<?php
$xml = file_get_contents('../karachi/routes/AckAckSchool/Qabrastan/AckAckSchool~Qabrastan.xml');
$xml = trim( $xml );
echo $xml;
?>