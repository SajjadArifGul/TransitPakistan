<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/CliftonBridge/7thDayHospital~CliftonBridge.xml');
$xml = trim( $xml );
echo $xml;
?>