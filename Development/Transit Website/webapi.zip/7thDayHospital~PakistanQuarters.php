<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/PakistanQuarters/7thDayHospital~PakistanQuarters.xml');
$xml = trim( $xml );
echo $xml;
?>