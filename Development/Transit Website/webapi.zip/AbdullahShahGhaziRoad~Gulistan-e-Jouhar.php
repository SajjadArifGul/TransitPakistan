<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/Gulistan-e-Jouhar/AbdullahShahGhaziRoad~Gulistan-e-Jouhar.xml');
$xml = trim( $xml );
echo $xml;
?>