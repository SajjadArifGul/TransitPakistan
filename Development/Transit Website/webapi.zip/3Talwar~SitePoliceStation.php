<?php
$xml = file_get_contents('../karachi/routes/3Talwar/SitePoliceStation/3Talwar~SitePoliceStation.xml');
$xml = trim( $xml );
echo $xml;
?>