<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/JauharSquare/AbdullahShahGhaziRoad~JauharSquare.xml');
$xml = trim( $xml );
echo $xml;
?>