<?php
$xml = file_get_contents('../karachi/routes/26thStreet/KMCWorkshop/26thStreet~KMCWorkshop.xml');
$xml = trim( $xml );
echo $xml;
?>