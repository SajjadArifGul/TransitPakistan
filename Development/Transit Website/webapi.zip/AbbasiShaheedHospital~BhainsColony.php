<?php
$xml = file_get_contents('../karachi/routes/AbbasiShaheedHospital/BhainsColony/AbbasiShaheedHospital~BhainsColony.xml');
$xml = trim( $xml );
echo $xml;
?>