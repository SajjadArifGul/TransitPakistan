<?php
$xml = file_get_contents('../karachi/routes/500Quarters/BaraBoard/500Quarters~BaraBoard.xml');
$xml = trim( $xml );
echo $xml;
?>