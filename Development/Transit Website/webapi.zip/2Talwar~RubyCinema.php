<?php
$xml = file_get_contents('../karachi/routes/2Talwar/RubyCinema/2Talwar~RubyCinema.xml');
$xml = trim( $xml );
echo $xml;
?>