<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/LiaquatabadNo10/AbdullahCollege~LiaquatabadNo10.xml');
$xml = trim( $xml );
echo $xml;
?>