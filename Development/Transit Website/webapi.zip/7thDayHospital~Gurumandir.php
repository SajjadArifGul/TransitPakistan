<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/Gurumandir/7thDayHospital~Gurumandir.xml');
$xml = trim( $xml );
echo $xml;
?>