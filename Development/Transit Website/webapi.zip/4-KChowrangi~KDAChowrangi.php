<?php
$xml = file_get_contents('../karachi/routes/4-KChowrangi/KDAChowrangi/4-KChowrangi~KDAChowrangi.xml');
$xml = trim( $xml );
echo $xml;
?>