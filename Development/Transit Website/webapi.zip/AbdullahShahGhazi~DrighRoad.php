<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/DrighRoad/AbdullahShahGhazi~DrighRoad.xml');
$xml = trim( $xml );
echo $xml;
?>