<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/SakhiHassan/AbdullahCollege~SakhiHassan.xml');
$xml = trim( $xml );
echo $xml;
?>