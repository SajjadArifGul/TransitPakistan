<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/ShadmanTown/7thDayHospital~ShadmanTown.xml');
$xml = trim( $xml );
echo $xml;
?>