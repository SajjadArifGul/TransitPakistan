<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/Numaish/AbdullahShahGhaziRoad~Numaish.xml');
$xml = trim( $xml );
echo $xml;
?>