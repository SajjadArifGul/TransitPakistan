<?php
$xml = file_get_contents('../karachi/routes/AghaKhanHospital/IslamiaCollege/AghaKhanHospital~IslamiaCollege.xml');
$xml = trim( $xml );
echo $xml;
?>