<?php
$xml = file_get_contents('../karachi/routes/500Quarters/BismillahHotel/500Quarters~BismillahHotel.xml');
$xml = trim( $xml );
echo $xml;
?>