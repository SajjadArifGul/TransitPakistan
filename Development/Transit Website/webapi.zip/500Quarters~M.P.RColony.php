<?php
$xml = file_get_contents('../karachi/routes/500Quarters/M.P.RColony/500Quarters~M.P.RColony.xml');
$xml = trim( $xml );
echo $xml;
?>