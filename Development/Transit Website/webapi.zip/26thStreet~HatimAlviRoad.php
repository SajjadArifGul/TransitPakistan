<?php
$xml = file_get_contents('../karachi/routes/26thStreet/HatimAlviRoad/26thStreet~HatimAlviRoad.xml');
$xml = trim( $xml );
echo $xml;
?>