<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/HabibBank/AbdullahShahGhazi~HabibBank.xml');
$xml = trim( $xml );
echo $xml;
?>