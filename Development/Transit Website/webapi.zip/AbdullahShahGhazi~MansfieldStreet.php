<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/MansfieldStreet/AbdullahShahGhazi~MansfieldStreet.xml');
$xml = trim( $xml );
echo $xml;
?>