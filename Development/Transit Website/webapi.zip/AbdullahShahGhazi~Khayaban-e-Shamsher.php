<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/Khayaban-e-Shamsher/AbdullahShahGhazi~Khayaban-e-Shamsher.xml');
$xml = trim( $xml );
echo $xml;
?>