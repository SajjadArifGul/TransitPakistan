<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/LandhiNo6/AbdullahCollege~LandhiNo6.xml');
$xml = trim( $xml );
echo $xml;
?>