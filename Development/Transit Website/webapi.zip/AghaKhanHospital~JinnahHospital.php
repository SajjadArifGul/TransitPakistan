<?php
$xml = file_get_contents('../karachi/routes/AghaKhanHospital/JinnahHospital/AghaKhanHospital~JinnahHospital.xml');
$xml = trim( $xml );
echo $xml;
?>