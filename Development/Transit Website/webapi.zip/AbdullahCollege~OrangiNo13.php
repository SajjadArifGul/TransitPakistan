<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/OrangiNo13/AbdullahCollege~OrangiNo13.xml');
$xml = trim( $xml );
echo $xml;
?>