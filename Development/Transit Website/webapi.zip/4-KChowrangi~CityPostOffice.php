<?php
$xml = file_get_contents('../karachi/routes/4-KChowrangi/CityPostOffice/4-KChowrangi~CityPostOffice.xml');
$xml = trim( $xml );
echo $xml;
?>