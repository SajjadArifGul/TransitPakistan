<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/PostOffice/AbdullahCollege~PostOffice.xml');
$xml = trim( $xml );
echo $xml;
?>