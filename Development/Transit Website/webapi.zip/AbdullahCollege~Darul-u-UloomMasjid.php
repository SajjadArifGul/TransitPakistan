<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/Darul-u-UloomMasjid/AbdullahCollege~Darul-u-UloomMasjid.xml');
$xml = trim( $xml );
echo $xml;
?>