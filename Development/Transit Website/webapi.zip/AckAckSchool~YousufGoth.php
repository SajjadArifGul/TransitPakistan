<?php
$xml = file_get_contents('../karachi/routes/AckAckSchool/YousufGoth/AckAckSchool~YousufGoth.xml');
$xml = trim( $xml );
echo $xml;
?>