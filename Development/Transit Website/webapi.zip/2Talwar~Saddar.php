<?php
$xml = file_get_contents('../karachi/routes/2Talwar/Saddar/2Talwar~Saddar.xml');
$xml = trim( $xml );
echo $xml;
?>