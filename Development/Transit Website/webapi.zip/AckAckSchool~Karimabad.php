<?php
$xml = file_get_contents('../karachi/routes/AckAckSchool/Karimabad/AckAckSchool~Karimabad.xml');
$xml = trim( $xml );
echo $xml;
?>