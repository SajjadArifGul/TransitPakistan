<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/Shaheed-e-MillatRoad/AbdullahCollege~Shaheed-e-MillatRoad.xml');
$xml = trim( $xml );
echo $xml;
?>