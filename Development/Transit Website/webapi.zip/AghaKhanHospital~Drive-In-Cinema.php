<?php
$xml = file_get_contents('../karachi/routes/AghaKhanHospital/Drive-In-Cinema/AghaKhanHospital~Drive-In-Cinema.xml');
$xml = trim( $xml );
echo $xml;
?>