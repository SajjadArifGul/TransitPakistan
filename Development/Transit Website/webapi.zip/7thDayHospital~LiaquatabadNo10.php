<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/LiaquatabadNo10/7thDayHospital~LiaquatabadNo10.xml');
$xml = trim( $xml );
echo $xml;
?>