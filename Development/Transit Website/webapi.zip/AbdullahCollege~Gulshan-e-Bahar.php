<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/Gulshan-e-Bahar/AbdullahCollege~Gulshan-e-Bahar.xml');
$xml = trim( $xml );
echo $xml;
?>