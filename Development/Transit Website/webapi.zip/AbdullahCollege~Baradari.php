<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/Baradari/AbdullahCollege~Baradari.xml');
$xml = trim( $xml );
echo $xml;
?>