<?php
$xml = file_get_contents('../karachi/routes/AghaKhanHospital/DrighRoad/AghaKhanHospital~DrighRoad.xml');
$xml = trim( $xml );
echo $xml;
?>