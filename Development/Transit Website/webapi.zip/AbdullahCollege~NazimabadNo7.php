<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/NazimabadNo7/AbdullahCollege~NazimabadNo7.xml');
$xml = trim( $xml );
echo $xml;
?>