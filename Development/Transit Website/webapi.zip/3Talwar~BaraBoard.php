<?php
$xml = file_get_contents('../karachi/routes/3Talwar/BaraBoard/3Talwar~BaraBoard.xml');
$xml = trim( $xml );
echo $xml;
?>