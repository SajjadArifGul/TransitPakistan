<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/Gurumandir/AbdullahShahGhazi~Gurumandir.xml');
$xml = trim( $xml );
echo $xml;
?>