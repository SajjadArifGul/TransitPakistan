<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/GoraQabrastan/AbdullahShahGhazi~GoraQabrastan.xml');
$xml = trim( $xml );
echo $xml;
?>