<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/WellingtonStreet/AbdullahShahGhazi~WellingtonStreet.xml');
$xml = trim( $xml );
echo $xml;
?>