<?php
$xml = file_get_contents('../karachi/routes/500Quarters/Plaza/500Quarters~Plaza.xml');
$xml = trim( $xml );
echo $xml;
?>