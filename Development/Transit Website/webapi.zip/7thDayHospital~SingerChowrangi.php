<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/SingerChowrangi/7thDayHospital~SingerChowrangi.xml');
$xml = trim( $xml );
echo $xml;
?>