<?php
$xml = file_get_contents('../karachi/routes/500Quarters/Shahra-e-Liaquat/500Quarters~Shahra-e-Liaquat.xml');
$xml = trim( $xml );
echo $xml;
?>