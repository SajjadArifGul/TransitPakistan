<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/Korangi/AbdullahCollege~Korangi.xml');
$xml = trim( $xml );
echo $xml;
?>