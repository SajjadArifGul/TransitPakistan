<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/Gulshan-e-Hadeed/7thDayHospital~Gulshan-e-Hadeed.xml');
$xml = trim( $xml );
echo $xml;
?>