<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/SabziMandi/7thDayHospital~SabziMandi.xml');
$xml = trim( $xml );
echo $xml;
?>