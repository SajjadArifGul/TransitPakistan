<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/YousufGoth/7thDayHospital~YousufGoth.xml');
$xml = trim( $xml );
echo $xml;
?>