<?php
$xml = file_get_contents('../karachi/routes/3Talwar/CliftonBridge/3Talwar~CliftonBridge.xml');
$xml = trim( $xml );
echo $xml;
?>