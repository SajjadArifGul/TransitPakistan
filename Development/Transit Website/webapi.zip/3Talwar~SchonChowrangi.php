<?php
$xml = file_get_contents('../karachi/routes/3Talwar/SchonChowrangi/3Talwar~SchonChowrangi.xml');
$xml = trim( $xml );
echo $xml;
?>