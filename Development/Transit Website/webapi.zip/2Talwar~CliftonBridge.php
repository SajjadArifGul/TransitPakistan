<?php
$xml = file_get_contents('../karachi/routes/2Talwar/CliftonBridge/2Talwar~CliftonBridge.xml');
$xml = trim( $xml );
echo $xml;
?>