<?php
$xml = file_get_contents('../karachi/routes/AghaKhanHospital/AkhterColony/AghaKhanHospital~AkhterColony.xml');
$xml = trim( $xml );
echo $xml;
?>