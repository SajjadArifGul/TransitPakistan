<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/BaraMaidan/AbdullahCollege~BaraMaidan.xml');
$xml = trim( $xml );
echo $xml;
?>