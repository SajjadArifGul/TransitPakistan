<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/LuckyStar/7thDayHospital~LuckyStar.xml');
$xml = trim( $xml );
echo $xml;
?>