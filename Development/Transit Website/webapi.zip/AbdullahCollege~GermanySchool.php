<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/GermanySchool/AbdullahCollege~GermanySchool.xml');
$xml = trim( $xml );
echo $xml;
?>