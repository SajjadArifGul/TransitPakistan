<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/Shaheed-e-MillatRoad/AbdullahShahGhazi~Shaheed-e-MillatRoad.xml');
$xml = trim( $xml );
echo $xml;
?>