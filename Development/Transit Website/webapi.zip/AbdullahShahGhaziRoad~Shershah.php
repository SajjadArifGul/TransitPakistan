<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/Shershah/AbdullahShahGhaziRoad~Shershah.xml');
$xml = trim( $xml );
echo $xml;
?>