<?php
$xml = file_get_contents('../karachi/routes/AckAckSchool/Clifton/AckAckSchool~Clifton.xml');
$xml = trim( $xml );
echo $xml;
?>