<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/FrontierMor/7thDayHospital~FrontierMor.xml');
$xml = trim( $xml );
echo $xml;
?>