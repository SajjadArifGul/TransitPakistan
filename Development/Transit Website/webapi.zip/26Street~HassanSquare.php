<?php
$xml = file_get_contents('../karachi/routes/26Street/HassanSquare/26Street~HassanSquare.xml');
$xml = trim( $xml );
echo $xml;
?>