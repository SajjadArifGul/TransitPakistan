<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/GulAhmed/7thDayHospital~GulAhmed.xml');
$xml = trim( $xml );
echo $xml;
?>