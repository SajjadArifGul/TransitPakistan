<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/26Street/AbdullahShahGhaziRoad~26Street.xml');
$xml = trim( $xml );
echo $xml;
?>