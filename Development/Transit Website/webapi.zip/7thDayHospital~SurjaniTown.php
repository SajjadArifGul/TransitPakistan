<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/SurjaniTown/7thDayHospital~SurjaniTown.xml');
$xml = trim( $xml );
echo $xml;
?>