<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/Qayyumabad/AbdullahCollege~Qayyumabad.xml');
$xml = trim( $xml );
echo $xml;
?>