<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/M.AJinnahRoad/AbdullahShahGhazi~M.AJinnahRoad.xml');
$xml = trim( $xml );
echo $xml;
?>