<?php
$xml = file_get_contents('../karachi/routes/2Talwar/SawatColony/2Talwar~SawatColony.xml');
$xml = trim( $xml );
echo $xml;
?>