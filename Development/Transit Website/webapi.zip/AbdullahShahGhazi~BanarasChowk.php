<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/BanarasChowk/AbdullahShahGhazi~BanarasChowk.xml');
$xml = trim( $xml );
echo $xml;
?>