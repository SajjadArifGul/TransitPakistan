<?php
$xml = file_get_contents('../karachi/routes/26Street/KorangiRoad/26Street~KorangiRoad.xml');
$xml = trim( $xml );
echo $xml;
?>