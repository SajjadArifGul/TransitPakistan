<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/RanchoreLine/AbdullahShahGhazi~RanchoreLine.xml');
$xml = trim( $xml );
echo $xml;
?>