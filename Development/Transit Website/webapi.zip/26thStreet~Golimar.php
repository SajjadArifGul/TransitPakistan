<?php
$xml = file_get_contents('../karachi/routes/26thStreet/Golimar/26thStreet~Golimar.xml');
$xml = trim( $xml );
echo $xml;
?>