<?php
$xml = file_get_contents('../karachi/routes/AghaKhanHospital/EyeHospital/AghaKhanHospital~EyeHospital.xml');
$xml = trim( $xml );
echo $xml;
?>