<?php
$xml = file_get_contents('../karachi/routes/3Talwar/SawatColony/3Talwar~SawatColony.xml');
$xml = trim( $xml );
echo $xml;
?>