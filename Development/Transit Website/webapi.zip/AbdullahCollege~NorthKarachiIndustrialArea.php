<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/NorthKarachiIndustrialArea/AbdullahCollege~NorthKarachiIndustrialArea.xml');
$xml = trim( $xml );
echo $xml;
?>