<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/MetroCinema/AbdullahCollege~MetroCinema.xml');
$xml = trim( $xml );
echo $xml;
?>