<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/PuraniSabziMandi/AbdullahShahGhaziRoad~PuraniSabziMandi.xml');
$xml = trim( $xml );
echo $xml;
?>