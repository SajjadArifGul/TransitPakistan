<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/SeaView/AbdullahShahGhazi~SeaView.xml');
$xml = trim( $xml );
echo $xml;
?>