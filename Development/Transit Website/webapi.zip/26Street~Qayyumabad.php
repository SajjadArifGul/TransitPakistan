<?php
$xml = file_get_contents('../karachi/routes/26Street/Qayyumabad/26Street~Qayyumabad.xml');
$xml = trim( $xml );
echo $xml;
?>