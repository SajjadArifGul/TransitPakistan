<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/TariqRoad/AbdullahShahGhazi~TariqRoad.xml');
$xml = trim( $xml );
echo $xml;
?>