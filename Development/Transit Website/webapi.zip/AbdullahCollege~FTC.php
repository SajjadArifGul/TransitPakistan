<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/FTC/AbdullahCollege~FTC.xml');
$xml = trim( $xml );
echo $xml;
?>