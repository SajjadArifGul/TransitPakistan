<?php
$xml = file_get_contents('../karachi/routes/2Talwar/LabourSquare/2Talwar~LabourSquare.xml');
$xml = trim( $xml );
echo $xml;
?>