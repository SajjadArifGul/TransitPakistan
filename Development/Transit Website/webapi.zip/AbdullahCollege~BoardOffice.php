<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/BoardOffice/AbdullahCollege~BoardOffice.xml');
$xml = trim( $xml );
echo $xml;
?>