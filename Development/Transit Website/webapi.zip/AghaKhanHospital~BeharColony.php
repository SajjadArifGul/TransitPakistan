<?php
$xml = file_get_contents('../karachi/routes/AghaKhanHospital/BeharColony/AghaKhanHospital~BeharColony.xml');
$xml = trim( $xml );
echo $xml;
?>