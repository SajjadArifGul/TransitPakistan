<?php
$xml = file_get_contents('../karachi/routes/AbbasiShaheedHospital/BeharColony/AbbasiShaheedHospital~BeharColony.xml');
$xml = trim( $xml );
echo $xml;
?>