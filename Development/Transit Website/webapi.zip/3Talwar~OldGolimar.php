<?php
$xml = file_get_contents('../karachi/routes/3Talwar/OldGolimar/3Talwar~OldGolimar.xml');
$xml = trim( $xml );
echo $xml;
?>