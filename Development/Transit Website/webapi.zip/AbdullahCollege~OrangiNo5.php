<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/OrangiNo5/AbdullahCollege~OrangiNo5.xml');
$xml = trim( $xml );
echo $xml;
?>