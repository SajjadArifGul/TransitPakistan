<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/Valika/7thDayHospital~Valika.xml');
$xml = trim( $xml );
echo $xml;
?>