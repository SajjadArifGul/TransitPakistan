<?php
$xml = file_get_contents('../karachi/routes/2Talwar/MohataPalace/2Talwar~MohataPalace.xml');
$xml = trim( $xml );
echo $xml;
?>