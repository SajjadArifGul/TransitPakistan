<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/Landhi/AbdullahCollege~Landhi.xml');
$xml = trim( $xml );
echo $xml;
?>