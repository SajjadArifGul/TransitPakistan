<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/KDACowrangi/AbdullahCollege~KDACowrangi.xml');
$xml = trim( $xml );
echo $xml;
?>