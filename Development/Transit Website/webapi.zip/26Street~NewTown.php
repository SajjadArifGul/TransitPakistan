<?php
$xml = file_get_contents('../karachi/routes/26Street/NewTown/26Street~NewTown.xml');
$xml = trim( $xml );
echo $xml;
?>