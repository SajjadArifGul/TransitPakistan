<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/Metroville/7thDayHospital~Metroville.xml');
$xml = trim( $xml );
echo $xml;
?>