<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/MaiKolachiRoad/AbdullahShahGhaziRoad~MaiKolachiRoad.xml');
$xml = trim( $xml );
echo $xml;
?>