<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/SuperMarket/7thDayHospital~SuperMarket.xml');
$xml = trim( $xml );
echo $xml;
?>