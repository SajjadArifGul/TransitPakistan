<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/SuperMarket/AbdullahShahGhazi~SuperMarket.xml');
$xml = trim( $xml );
echo $xml;
?>