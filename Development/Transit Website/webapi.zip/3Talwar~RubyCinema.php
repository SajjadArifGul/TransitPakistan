<?php
$xml = file_get_contents('../karachi/routes/3Talwar/RubyCinema/3Talwar~RubyCinema.xml');
$xml = trim( $xml );
echo $xml;
?>