<?php
$xml = file_get_contents('../karachi/routes/26thStreet/SakhiHassan/26thStreet~SakhiHassan.xml');
$xml = trim( $xml );
echo $xml;
?>