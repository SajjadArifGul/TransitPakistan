<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/M.AJinnahRoad/AbdullahCollege~M.AJinnahRoad.xml');
$xml = trim( $xml );
echo $xml;
?>