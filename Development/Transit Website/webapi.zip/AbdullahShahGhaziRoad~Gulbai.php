<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/Gulbai/AbdullahShahGhaziRoad~Gulbai.xml');
$xml = trim( $xml );
echo $xml;
?>