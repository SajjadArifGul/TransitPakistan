<?php
$xml = file_get_contents('../karachi/routes/26thStreet/SurjaniTown/26thStreet~SurjaniTown.xml');
$xml = trim( $xml );
echo $xml;
?>