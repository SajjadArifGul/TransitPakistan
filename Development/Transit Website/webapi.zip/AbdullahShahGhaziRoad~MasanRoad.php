<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/MasanRoad/AbdullahShahGhaziRoad~MasanRoad.xml');
$xml = trim( $xml );
echo $xml;
?>