<?php
$xml = file_get_contents('../karachi/routes/AghaKhanHospital/Airport/AghaKhanHospital~Airport.xml');
$xml = trim( $xml );
echo $xml;
?>