<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/TeenHatti/AbdullahCollege~TeenHatti.xml');
$xml = trim( $xml );
echo $xml;
?>