<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/ChowdhryKhaliquzZamanRoad/AbdullahShahGhazi~ChowdhryKhaliquzZamanRoad.xml');
$xml = trim( $xml );
echo $xml;
?>