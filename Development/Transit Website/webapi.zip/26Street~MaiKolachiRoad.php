<?php
$xml = file_get_contents('../karachi/routes/26Street/MaiKolachiRoad/26Street~MaiKolachiRoad.xml');
$xml = trim( $xml );
echo $xml;
?>