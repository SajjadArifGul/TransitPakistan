<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/Saddar/AbdullahCollege~Saddar.xml');
$xml = trim( $xml );
echo $xml;
?>