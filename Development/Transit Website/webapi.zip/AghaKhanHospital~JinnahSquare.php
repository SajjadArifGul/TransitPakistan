<?php
$xml = file_get_contents('../karachi/routes/AghaKhanHospital/JinnahSquare/AghaKhanHospital~JinnahSquare.xml');
$xml = trim( $xml );
echo $xml;
?>