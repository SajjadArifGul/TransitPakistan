<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/LandhiNo1/AbdullahCollege~LandhiNo1.xml');
$xml = trim( $xml );
echo $xml;
?>