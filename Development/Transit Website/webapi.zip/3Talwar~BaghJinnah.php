<?php
$xml = file_get_contents('../karachi/routes/3Talwar/BaghJinnah/3Talwar~BaghJinnah.xml');
$xml = trim( $xml );
echo $xml;
?>