<?php
$xml = file_get_contents('../karachi/routes/AghaKhanHospital/BandarRoad/AghaKhanHospital~BandarRoad.xml');
$xml = trim( $xml );
echo $xml;
?>