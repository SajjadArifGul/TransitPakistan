<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/JailRoad/AbdullahCollege~JailRoad.xml');
$xml = trim( $xml );
echo $xml;
?>