<?php
$xml = file_get_contents('../karachi/routes/3Talwar/HabibBank/3Talwar~HabibBank.xml');
$xml = trim( $xml );
echo $xml;
?>