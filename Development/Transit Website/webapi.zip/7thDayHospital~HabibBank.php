<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/HabibBank/7thDayHospital~HabibBank.xml');
$xml = trim( $xml );
echo $xml;
?>