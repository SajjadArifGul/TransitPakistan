<?php
$xml = file_get_contents('../karachi/routes/3Talwar/MohataPalace/3Talwar~MohataPalace.xml');
$xml = trim( $xml );
echo $xml;
?>