<?php
$xml = file_get_contents('../karachi/routes/4-KChowrangi/Hyderi/4-KChowrangi~Hyderi.xml');
$xml = trim( $xml );
echo $xml;
?>