<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/MirKarimAliTalpurRoad/AbdullahShahGhazi~MirKarimAliTalpurRoad.xml');
$xml = trim( $xml );
echo $xml;
?>