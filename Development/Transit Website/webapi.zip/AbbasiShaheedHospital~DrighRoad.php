<?php
$xml = file_get_contents('../karachi/routes/AbbasiShaheedHospital/DrighRoad/AbbasiShaheedHospital~DrighRoad.xml');
$xml = trim( $xml );
echo $xml;
?>