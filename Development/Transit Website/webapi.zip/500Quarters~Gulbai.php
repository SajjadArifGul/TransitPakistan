<?php
$xml = file_get_contents('../karachi/routes/500Quarters/Gulbai/500Quarters~Gulbai.xml');
$xml = trim( $xml );
echo $xml;
?>