<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/M.AJinnahRoad/AbdullahShahGhaziRoad~M.AJinnahRoad.xml');
$xml = trim( $xml );
echo $xml;
?>