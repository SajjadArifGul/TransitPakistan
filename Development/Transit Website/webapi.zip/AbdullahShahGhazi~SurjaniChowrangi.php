<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/SurjaniChowrangi/AbdullahShahGhazi~SurjaniChowrangi.xml');
$xml = trim( $xml );
echo $xml;
?>