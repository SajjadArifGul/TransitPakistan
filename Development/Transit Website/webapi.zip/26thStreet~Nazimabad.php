<?php
$xml = file_get_contents('../karachi/routes/26thStreet/Nazimabad/26thStreet~Nazimabad.xml');
$xml = trim( $xml );
echo $xml;
?>