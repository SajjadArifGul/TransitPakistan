<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/PNSC/AbdullahShahGhazi~PNSC.xml');
$xml = trim( $xml );
echo $xml;
?>