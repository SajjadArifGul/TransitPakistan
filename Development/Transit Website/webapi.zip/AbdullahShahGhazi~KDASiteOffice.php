<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/KDASiteOffice/AbdullahShahGhazi~KDASiteOffice.xml');
$xml = trim( $xml );
echo $xml;
?>