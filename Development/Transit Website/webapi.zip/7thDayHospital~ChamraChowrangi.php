<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/ChamraChowrangi/7thDayHospital~ChamraChowrangi.xml');
$xml = trim( $xml );
echo $xml;
?>