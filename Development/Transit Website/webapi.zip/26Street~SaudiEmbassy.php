<?php
$xml = file_get_contents('../karachi/routes/26Street/SaudiEmbassy/26Street~SaudiEmbassy.xml');
$xml = trim( $xml );
echo $xml;
?>