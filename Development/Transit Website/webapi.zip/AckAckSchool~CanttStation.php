<?php
$xml = file_get_contents('../karachi/routes/AckAckSchool/CanttStation/AckAckSchool~CanttStation.xml');
$xml = trim( $xml );
echo $xml;
?>