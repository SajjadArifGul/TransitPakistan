<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/IslamiaCollege/AbdullahShahGhaziRoad~IslamiaCollege.xml');
$xml = trim( $xml );
echo $xml;
?>