<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/SakhiHassan/AbdullahShahGhazi~SakhiHassan.xml');
$xml = trim( $xml );
echo $xml;
?>