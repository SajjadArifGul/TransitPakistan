<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/SafariPark/7thDayHospital~SafariPark.xml');
$xml = trim( $xml );
echo $xml;
?>