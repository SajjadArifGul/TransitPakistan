<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/JailChowrangi/AbdullahShahGhaziRoad~JailChowrangi.xml');
$xml = trim( $xml );
echo $xml;
?>