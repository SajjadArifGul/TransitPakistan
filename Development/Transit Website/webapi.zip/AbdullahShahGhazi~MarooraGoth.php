<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/MarooraGoth/AbdullahShahGhazi~MarooraGoth.xml');
$xml = trim( $xml );
echo $xml;
?>