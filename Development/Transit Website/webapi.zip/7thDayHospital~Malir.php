<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/Malir/7thDayHospital~Malir.xml');
$xml = trim( $xml );
echo $xml;
?>