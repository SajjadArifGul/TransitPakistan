<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/Khayaban-e-Shanshee/AbdullahShahGhazi~Khayaban-e-Shanshee.xml');
$xml = trim( $xml );
echo $xml;
?>