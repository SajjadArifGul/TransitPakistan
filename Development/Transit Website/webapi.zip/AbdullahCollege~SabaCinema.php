<?php
$xml = file_get_contents('../karachi/routes/AbdullahCollege/SabaCinema/AbdullahCollege~SabaCinema.xml');
$xml = trim( $xml );
echo $xml;
?>