<?php
$xml = file_get_contents('../karachi/routes/2Talwar/OldGolimar/2Talwar~OldGolimar.xml');
$xml = trim( $xml );
echo $xml;
?>