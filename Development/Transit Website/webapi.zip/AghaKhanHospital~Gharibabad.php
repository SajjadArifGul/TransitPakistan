<?php
$xml = file_get_contents('../karachi/routes/AghaKhanHospital/Gharibabad/AghaKhanHospital~Gharibabad.xml');
$xml = trim( $xml );
echo $xml;
?>