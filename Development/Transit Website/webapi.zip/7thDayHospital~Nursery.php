<?php
$xml = file_get_contents('../karachi/routes/7thDayHospital/Nursery/7thDayHospital~Nursery.xml');
$xml = trim( $xml );
echo $xml;
?>