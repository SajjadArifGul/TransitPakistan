<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/BoatBasin/AbdullahShahGhaziRoad~BoatBasin.xml');
$xml = trim( $xml );
echo $xml;
?>