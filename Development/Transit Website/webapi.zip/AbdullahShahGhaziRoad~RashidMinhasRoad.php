<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhaziRoad/RashidMinhasRoad/AbdullahShahGhaziRoad~RashidMinhasRoad.xml');
$xml = trim( $xml );
echo $xml;
?>