<?php
$xml = file_get_contents('../karachi/routes/AbdullahShahGhazi/LuckyStar/AbdullahShahGhazi~LuckyStar.xml');
$xml = trim( $xml );
echo $xml;
?>