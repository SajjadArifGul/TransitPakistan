package pk.transit.app;

import java.util.ArrayList;

public class BusStopsDetails {

	public ArrayList<String> LocationNames = new ArrayList<String>();
	public ArrayList<Double> LocationLatitudes = new ArrayList<Double>();
	public ArrayList<Double> LocationLongitudes = new ArrayList<Double>();
}
