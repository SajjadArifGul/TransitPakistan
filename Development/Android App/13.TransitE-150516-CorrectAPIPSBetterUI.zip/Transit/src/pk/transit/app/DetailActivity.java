package pk.transit.app;

import java.util.ArrayList;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.IntentSender;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;


public class DetailActivity extends Activity implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, LocationListener {

	private static final int ERROR_GOOGLE_PLAY_SERVICE_AVAILABILITY = 9001;
	private final static int CONNECTION_FAILURE_RESOLUTION_REQUEST = 9002;

	public ArrayList<String> LocationNames = new ArrayList<String>();
	public ArrayList<Double> LocationLatitudes = new ArrayList<Double>();
	public ArrayList<Double> LocationLongitudes = new ArrayList<Double>();
	
	public String VehicleType;
	
	private GoogleApiClient mGoogleApiClient;
	private LocationRequest mLocationRequest;
	
	boolean gShowMap;
	GoogleMap gMap;
	
	ListView RouteDetailsListView;
	
	Marker CurrentLocationMarker;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_detail);
		
		RouteDetailsListView = (ListView) findViewById(R.id.RouteDetailsListView);
		
		LocationNames = (ArrayList<String>) getIntent().getStringArrayListExtra("LocationNames");
		LocationLatitudes = (ArrayList<Double>) getIntent().getSerializableExtra("LocationLatitudes");
		LocationLongitudes = (ArrayList<Double>) getIntent().getSerializableExtra("LocationLongitudes");
		
		PopulateRouteDetailsListView();
		
		gShowMap = IsPlayServiceAvailable(this) && initMap();
		
		DisplayMapDetails();
		
		mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();

        // Create the LocationRequest object
        mLocationRequest = LocationRequest.create()
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setInterval(10 * 1000)        // 10 seconds, in milliseconds
                .setFastestInterval(1 * 1000); // 1 second, in milliseconds
	}

	private boolean IsPlayServiceAvailable(Context context) {
		// TODO Auto-generated method stub
		int isAvailable = GooglePlayServicesUtil.isGooglePlayServicesAvailable(context);
		
		switch (isAvailable)
		{
		case ConnectionResult.SUCCESS:
			return true;
		case ConnectionResult.SERVICE_MISSING:
			break;
		case ConnectionResult.SERVICE_VERSION_UPDATE_REQUIRED:
			break;
		case ConnectionResult.SERVICE_INVALID:
			break;
		default:
			break;
		}
		Dialog dialog = GooglePlayServicesUtil.getErrorDialog(isAvailable, (Activity) context,ERROR_GOOGLE_PLAY_SERVICE_AVAILABILITY);
		dialog.show();
		return false;
	}

	private boolean initMap() {
		// TODO Auto-generated method stub
		
		if (gMap == null)
		{
			gMap = ((MapFragment) getFragmentManager().findFragmentById(R.id.map)).getMap();
			//gMap.setMyLocationEnabled(true);
		}
		return (gMap != null);
	}
	
	private void DisplayMapDetails()
	{
		if (gShowMap)
		{
			DisplayRoute();
		}
	}
	private void DisplayRoute()
	{
		PolylineOptions polylineoptions = new PolylineOptions();
		LatLng ll = null;
		
		for (int i=0; i<LocationNames.size(); i++)
		{
			ll = new LatLng(LocationLatitudes.get(i), LocationLongitudes.get(i));
			
			String MarkerTitle = LocationNames.get(i);
			
			gMap.addMarker(new MarkerOptions()
					.position(ll)
					.icon(BitmapDescriptorFactory.fromResource(R.drawable.iconstop32))
					.title(MarkerTitle));
			
			polylineoptions.add(ll);
		}
		polylineoptions.color(Color.rgb(0, 179, 253));
		
		gMap.addPolyline(polylineoptions);
	}
	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.detail, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.RoadMapMenuItem) {
			gMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
			return true;
		}
		if (id == R.id.HybridMapMenuItem) {
			gMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
			return true;
		}
		if (id == R.id.SatelliteMapMenuItem) {
			gMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
			return true;
		}
		if (id == R.id.TerrainMapMenuItem) {
			gMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		initMap();
	    mGoogleApiClient.connect();
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		
		if (mGoogleApiClient.isConnected()) {
            LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, this);
            mGoogleApiClient.disconnect();
        }
	}
	
	private void PopulateRouteDetailsListView() {
		RouteDetailsListView.setAdapter(new MyStopAdapter(this, LocationNames, LocationLatitudes, LocationLongitudes));
	}

	@Override
	public void onConnectionFailed(ConnectionResult connectionResult) {
		// TODO Auto-generated method stub
		if (connectionResult.hasResolution()) {
            try {
                // Start an Activity that tries to resolve the error
                connectionResult.startResolutionForResult(this, CONNECTION_FAILURE_RESOLUTION_REQUEST);
                /*
                 * Thrown if Google Play services canceled the original
                 * PendingIntent
                 */
            } catch (IntentSender.SendIntentException e) {
                // Log the error
                e.printStackTrace();
            }
        } else {
            /*
             * If no resolution is available, display a dialog to the
             * user with the error.
             */
        }
	}

	@Override
	public void onConnected(Bundle arg0) {
		// TODO Auto-generated method stub
		Location location = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
        if (location == null) {
            LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);
        }
        else {
            handleNewLocation(location);
        }
	}
	private void handleNewLocation(Location location) {
        
        double currentLatitude = location.getLatitude();
        double currentLongitude = location.getLongitude();

        LatLng latLng = new LatLng(currentLatitude, currentLongitude);

        //mMap.addMarker(new MarkerOptions().position(new LatLng(currentLatitude, currentLongitude)).title("Current Location"));
        MarkerOptions options = new MarkerOptions()
                .position(latLng)
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.iconyou32))
				.title("You are here!");
        
        if (CurrentLocationMarker == null)
        {
        	CurrentLocationMarker = gMap.addMarker(options);
        }
        else
        {
        	CurrentLocationMarker.remove();
        	CurrentLocationMarker = gMap.addMarker(options);
        }
        
        CurrentLocationMarker.showInfoWindow();
      
        CameraUpdate update = CameraUpdateFactory.newLatLngZoom(latLng, 11);
		gMap.moveCamera(update);
		
    }

	@Override
	public void onConnectionSuspended(int arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onLocationChanged(Location location) {
		// TODO Auto-generated method stub
		handleNewLocation(location);
	}
}

class MyStopAdapter extends BaseAdapter {

	ArrayList<String> LocationNames = new ArrayList<String>();
	ArrayList<Double> LocationLatitudes = new ArrayList<Double>();
	ArrayList<Double> LocationLongitudes = new ArrayList<Double>();
	
	Context context;
	LayoutInflater layoutInflater;

	public MyStopAdapter(Context context, ArrayList<String> LocationNames, ArrayList<Double> LocationLatitudes, ArrayList<Double> LocationLongitudes) {
		this.LocationNames = LocationNames;
		this.LocationLatitudes = LocationLatitudes;
		this.LocationLongitudes = LocationLongitudes;
		
		this.context = context;
		layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}

	@Override
	public int getCount() {
		return LocationNames.size();
	}

	@Override
	public Object getItem(int position) {
		return LocationNames.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View row = convertView;
		MyStopsHolder myStopsHolder = null;
		if (row == null) {

			row = layoutInflater.inflate(R.layout.activity_single_stop_view, parent, false);
			myStopsHolder = new MyStopsHolder(row);
			row.setTag(myStopsHolder);

		} else {
			myStopsHolder = (MyStopsHolder) row.getTag();
		}
		
		myStopsHolder.StopName.setText(LocationNames.get(position).toString());
		return row;
	}
}

class MyStopsHolder {
	TextView StopName;

	public MyStopsHolder(View view) {
		StopName = (TextView) view.findViewById(R.id.StopName);
	}
}