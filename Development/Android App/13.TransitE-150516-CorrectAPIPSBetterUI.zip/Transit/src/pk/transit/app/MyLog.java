package pk.transit.app;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

public class MyLog {
	public static void m(String Tag, String Message)
	{
		Log.d(Tag, Message);
	}
	public static void s(Context context, String Message)
	{
		Toast.makeText(context, Message, Toast.LENGTH_SHORT).show();
	}
}
