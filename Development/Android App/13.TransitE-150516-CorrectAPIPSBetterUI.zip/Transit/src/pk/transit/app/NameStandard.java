package pk.transit.app;

public class NameStandard {
	public String Standardize(String Name)
	{
		Name = Name.replace(" ", "");
		Name = Name.replace(",", "");
		
		return Name;
	}
}
