package pk.transit.app;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements LocationsCallBack, RoutesCallBack {

	NameStandard nameStandard = null;

	AutoCompleteTextView LocationAutoCompleteTextView = null;
	AutoCompleteTextView DestinationAutoCompleteTextView = null;
	ArrayAdapter<String> adapter = null;
	PlaceHolderFragment taskFragment;

	RouteHolderFragment routeFragment;

	String StartLocation = null;
	String EndDestination = null;

	static String RouteURL = null;

	ListView RoutesSuggestionsListView;

	ConnectionDetector connectionDetector;
	Boolean isConnected = false;

	ImageView InternetConnectionIcon = null;
	TextView InternetConnectionText = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		InternetConnectionIcon = (ImageView) findViewById(R.id.InternetConnectionIcon);
		InternetConnectionText = (TextView) findViewById(R.id.InternetConnectionText);

		isConnected = connectionDetector.isConnectedToInternet(getApplicationContext());

		if (isConnected) {
			InternetConnectionText.setText("Internet Access");
			InternetConnectionIcon.setImageResource(R.drawable.iconinternetconnect48);
		} else {

			InternetConnectionText.setText("No Internet Access");
			InternetConnectionIcon.setImageResource(R.drawable.iconinternetdisconnect48);
		}

		if (savedInstanceState == null) {
			nameStandard = new NameStandard();

			LocationAutoCompleteTextView = (AutoCompleteTextView) findViewById(R.id.LocationAutoCompleteTextView);
			DestinationAutoCompleteTextView = (AutoCompleteTextView) findViewById(R.id.DestinationAutoCompleteTextView);

			taskFragment = new PlaceHolderFragment();
			getFragmentManager().beginTransaction().add(taskFragment, "MytaskFragment").commit();

			routeFragment = new RouteHolderFragment();
			getFragmentManager().beginTransaction().add(routeFragment, "MyrouteFragment").commit();
		} else {
			taskFragment = (PlaceHolderFragment) getFragmentManager().findFragmentByTag("MytaskFragment");
			routeFragment = (RouteHolderFragment) getFragmentManager().findFragmentByTag("MyrouteFragment");
		}

		LocationAutoCompleteTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				// TODO Auto-generated method stub
				StartLocation = nameStandard.Standardize(LocationAutoCompleteTextView.getText().toString());

				if (EndDestination != null)
				{
					EndDestination = nameStandard.Standardize(DestinationAutoCompleteTextView.getText().toString());

					RouteURL = "http://api.transit.pk/karachi/routes/" + StartLocation + "/" + EndDestination + "/";
					routeFragment.startTask();
				}
			}
		});
		DestinationAutoCompleteTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				EndDestination = nameStandard.Standardize(DestinationAutoCompleteTextView.getText().toString());
				if (StartLocation != null)
				{
					StartLocation = nameStandard.Standardize(LocationAutoCompleteTextView.getText().toString());

					RouteURL = "http://api.transit.pk/karachi/routes/" + StartLocation + "/" + EndDestination + "/";
					routeFragment.startTask();
				}
			}
		});
		RoutesSuggestionsListView = (ListView) findViewById(R.id.RoutesSuggestionsListView);
		taskFragment.startTask();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.RefreshActivityMenuItem) {
			LocationAutoCompleteTextView.setText(null);
			DestinationAutoCompleteTextView.setText(null);
			
			StartLocation = null;
			EndDestination = null;

			RoutesSuggestionsListView.removeAllViewsInLayout();
			RoutesSuggestionsListView.refreshDrawableState();
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	public static class PlaceHolderFragment extends Fragment {
		LocationsAsyncTask GetLocationsXMLTask;

		LocationsCallBack locationsCallBack;

		public PlaceHolderFragment() {
		}

		@Override
		public void onAttach(Activity activity) {
			// TODO Auto-generated method stub
			super.onAttach(activity);

			locationsCallBack = (LocationsCallBack) activity;

			if (GetLocationsXMLTask != null) {
				GetLocationsXMLTask.onAttach(locationsCallBack);
			}
		}

		@Override
		public void onActivityCreated(Bundle savedInstanceState) {
			// TODO Auto-generated method stub
			super.onActivityCreated(savedInstanceState);
			setRetainInstance(true);
		}

		public void startTask() {
			if (GetLocationsXMLTask != null) {
				GetLocationsXMLTask.cancel(true);
			} else {
				GetLocationsXMLTask = new LocationsAsyncTask(locationsCallBack);
				GetLocationsXMLTask.execute();
			}
		}

		@Override
		public void onDetach() {
			// TODO Auto-generated method stub
			super.onDetach();
			locationsCallBack = null;

			if (GetLocationsXMLTask != null) {
				GetLocationsXMLTask.onDetach();
			}
		}
	}

	public static class RouteHolderFragment extends Fragment {
		RoutesAsyncTask GetRouteXMLTask = null;
		RoutesCallBack routesCallBack;

		public RouteHolderFragment() {

		}

		@Override
		public void onAttach(Activity activity) {
			// TODO Auto-generated method stub
			super.onAttach(activity);

			routesCallBack = (RoutesCallBack) activity;

			if (GetRouteXMLTask != null) {
				GetRouteXMLTask.onAttach(routesCallBack);
			}
		}

		@Override
		public void onActivityCreated(Bundle savedInstanceState) {
			// TODO Auto-generated method stub
			super.onActivityCreated(savedInstanceState);
			setRetainInstance(true);
		}

		public void startTask() {
			/*if (GetRouteXMLTask != null) {
				GetRouteXMLTask.cancel(true);
			} else {
			 */
			GetRouteXMLTask = new RoutesAsyncTask(routesCallBack);
			GetRouteXMLTask.execute();
			//}
		}

		@Override
		public void onDetach() {
			// TODO Auto-generated method stub
			super.onDetach();
			routesCallBack = null;

			if (GetRouteXMLTask != null) {
				GetRouteXMLTask.onDetach();
			}
		}
	}

	public static class LocationsAsyncTask extends AsyncTask<Void, Void, ArrayList<String>> {
		LocationsCallBack locationsCallBack = null;

		public LocationsAsyncTask(LocationsCallBack locationsCallBack) {
			// TODO Auto-generated constructor stub

			this.locationsCallBack = locationsCallBack;
		}

		public void onAttach(LocationsCallBack locationsCallBack) {
			this.locationsCallBack = locationsCallBack;
		}

		public void onDetach() {
			locationsCallBack = null;
		}

		@Override
		protected ArrayList<String> doInBackground(Void... params) {
			// TODO Auto-generated method stub

			String LocationsXMLURL = "http://api.transit.pk/karachi/locations/";

			ArrayList<String> LocationsArrayList = new ArrayList<String>();

			try {
				URL url = new URL(LocationsXMLURL);

				HttpURLConnection connection = (HttpURLConnection) url.openConnection();

				connection.setRequestMethod("GET");

				InputStream inputStream = connection.getInputStream();

				LocationsArrayList = ProcessLocationXML(inputStream);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				MyLog.m("Exception at doInBackground in LocationsTask", e + "");
			}

			return LocationsArrayList;
		}

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();

			if (locationsCallBack != null) {
				locationsCallBack.onPreExecute();
			}
		}

		@Override
		protected void onPostExecute(ArrayList<String> result) {
			// TODO Auto-generated method stub

			if (locationsCallBack != null) {
				locationsCallBack.onPostExecute(result);
			}
		}

		public ArrayList<String> ProcessLocationXML(InputStream inputStream) throws Exception {
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();

			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();

			Document xmlDocument = documentBuilder.parse(inputStream);

			Element rootElement = xmlDocument.getDocumentElement();

			NodeList LocationsList = rootElement.getElementsByTagName("LocationName");

			ArrayList<String> LocationsArrayList = new ArrayList<String>();

			if (LocationsList != null && LocationsList.getLength() != 0) {
				Node CurrentNode = null;

				for (int i = 0; i < LocationsList.getLength(); i++) {
					CurrentNode = LocationsList.item(i);

					LocationsArrayList.add(CurrentNode.getTextContent());
				}
			}
			return LocationsArrayList;
		}
	}

	public static class RoutesAsyncTask extends AsyncTask<Void, Void, ArrayList<HashMap<String, String>>> {
		RoutesCallBack routesCallBack = null;

		ArrayList<BusStopsDetails> busStopsDetails = new ArrayList<BusStopsDetails>();

		public RoutesAsyncTask(RoutesCallBack routesCallBack) {
			// TODO Auto-generated constructor stub

			this.routesCallBack = routesCallBack;
		}

		public void onAttach(RoutesCallBack routesCallBack) {
			// TODO Auto-generated method stub
			this.routesCallBack = routesCallBack;
		}

		public void onDetach() {
			// TODO Auto-generated method stub
			routesCallBack = null;
		}

		@Override
		protected ArrayList<HashMap<String, String>> doInBackground(Void... params) {

			ArrayList<HashMap<String, String>> RouteBusStopsArrayList = new ArrayList<HashMap<String, String>>();

			try {
				URL url = new URL(RouteURL);

				HttpURLConnection connection = (HttpURLConnection) url.openConnection();

				connection.setRequestMethod("GET");

				InputStream inputStream = connection.getInputStream();

				RouteBusStopsArrayList = ProcessRouteXML(inputStream);

			} catch (Exception e) {
				// TODO Auto-generated catch block
				MyLog.m("Exception at doInBackground in RoutesTask", e + "");
			}

			return RouteBusStopsArrayList;
		}

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();

			if (routesCallBack != null) {
				routesCallBack.onRoutesPreExecute();
			}
		}

		@Override
		protected void onPostExecute(ArrayList<HashMap<String, String>> result) {
			// TODO Auto-generated method stub

			if (routesCallBack != null) {
				routesCallBack.onRoutesPostExecute(result, busStopsDetails);
			}
		}

		public ArrayList<HashMap<String, String>> ProcessRouteXML(InputStream inputStream) throws Exception {
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document xmlDocument = documentBuilder.parse(inputStream);
			Element rootElement = xmlDocument.getDocumentElement();
			MyLog.m("Route Element Found", rootElement.getNodeName());

			NodeList VehicleList = rootElement.getElementsByTagName("Vehicle");

			NodeList VehicleChildren = null;

			Node currentVehicle = null;

			Node currentVehicleChildren = null;

			ArrayList<HashMap<String, String>> RouteVehicles = new ArrayList<HashMap<String, String>>();

			HashMap<String, String> currentMap = null;

			for (int i = 0; i < VehicleList.getLength(); i++) {

				BusStopsDetails singleRouteBusStopsDetails = new BusStopsDetails();
				MyLog.m("singleRouteBusStopsDetails init : ", "" + singleRouteBusStopsDetails.LocationNames.size() + " lat" + singleRouteBusStopsDetails.LocationLongitudes.size());

				currentVehicle = VehicleList.item(i);

				VehicleChildren = currentVehicle.getChildNodes();

				currentMap = new HashMap<String, String>();

				for (int j = 1; j < VehicleChildren.getLength(); j = j + 2) {

					currentVehicleChildren = VehicleChildren.item(j);

					if (currentVehicleChildren.getNodeName().equals("VehicleType")) {
						currentMap.put("VehicleType", currentVehicleChildren.getTextContent());
						MyLog.m("VehicleType Element Found", currentVehicleChildren.getTextContent().toString());
					}

					else if (currentVehicleChildren.getNodeName().equals("VehicleName")) {
						currentMap.put("VehicleName", currentVehicleChildren.getTextContent());
						MyLog.m("VehicleName Element Found", currentVehicleChildren.getTextContent().toString());
					}

					else if (currentVehicleChildren.getNodeName().equals("StopFair")) {
						currentMap.put("StopFair", currentVehicleChildren.getTextContent());
						MyLog.m("StopFair Element Found", currentVehicleChildren.getTextContent().toString());
					}

					else if (currentVehicleChildren.getNodeName().equals("StartPoint")) {

						NodeList StartPointAttributes = currentVehicleChildren.getChildNodes();
						for (int k = 1; k < StartPointAttributes.getLength(); k = k + 2) {
							Node StartPointAttribute = StartPointAttributes.item(k);
							if (StartPointAttribute.getNodeName().equals("StartPointName")) {
								MyLog.m("StartPointName Element Found",
										StartPointAttribute.getTextContent().toString());

								singleRouteBusStopsDetails.LocationNames.add(StartPointAttribute.getTextContent().toString());

							} else if (StartPointAttribute.getNodeName().equals("StartPointLat")) {
								MyLog.m("StartPointLat Element Found", StartPointAttribute.getTextContent().toString());

								singleRouteBusStopsDetails.LocationLatitudes.add(Double.parseDouble(StartPointAttribute.getTextContent()));

							} else if (StartPointAttribute.getNodeName().equals("StartPointLong")) {
								MyLog.m("StartPointLong Element Found",
										StartPointAttribute.getTextContent().toString());
								singleRouteBusStopsDetails.LocationLongitudes.add(Double.parseDouble(StartPointAttribute.getTextContent().toString()));
							}
						}
					}

					else if (currentVehicleChildren.getNodeName().equals("BusStop")) {

						NodeList BusStopAttributes = currentVehicleChildren.getChildNodes();
						for (int k = 1; k < BusStopAttributes.getLength(); k = k + 2) {
							Node BusStopAttribute = BusStopAttributes.item(k);
							if (BusStopAttribute.getNodeName().equals("BusStopName")) {
								MyLog.m("BusStopName Element Found", BusStopAttribute.getTextContent().toString());
								singleRouteBusStopsDetails.LocationNames.add(BusStopAttribute.getTextContent().toString());

							} else if (BusStopAttribute.getNodeName().equals("BusStopLat")) {
								MyLog.m("BusStopLat Element Found", BusStopAttribute.getTextContent().toString());
								singleRouteBusStopsDetails.LocationLatitudes.add(Double.parseDouble(BusStopAttribute.getTextContent()));

							} else if (BusStopAttribute.getNodeName().equals("BusStopLong")) {
								MyLog.m("BusStopLong Element Found", BusStopAttribute.getTextContent().toString());
								singleRouteBusStopsDetails.LocationLongitudes.add(Double.parseDouble(BusStopAttribute.getTextContent()));
							}
						}
					}

					else if (currentVehicleChildren.getNodeName().equals("EndPoint")) {

						NodeList EndPointAttributes = currentVehicleChildren.getChildNodes();
						for (int k = 1; k < EndPointAttributes.getLength(); k = k + 2) {
							Node EndPointAttribute = EndPointAttributes.item(k);
							if (EndPointAttribute.getNodeName().equals("EndPointName")) {
								singleRouteBusStopsDetails.LocationNames.add(EndPointAttribute.getTextContent().toString());
								MyLog.m("EndPointName Element Found", EndPointAttribute.getTextContent().toString());
							} else if (EndPointAttribute.getNodeName().equals("EndPointLat")) {
								singleRouteBusStopsDetails.LocationLatitudes.add(Double.parseDouble(EndPointAttribute.getTextContent()));
								MyLog.m("EndPointLat Element Found", EndPointAttribute.getTextContent().toString());
							} else if (EndPointAttribute.getNodeName().equals("EndPointLong")) {
								MyLog.m("EndPointLong Element Found", EndPointAttribute.getTextContent().toString());
								singleRouteBusStopsDetails.LocationLongitudes.add(Double.parseDouble(EndPointAttribute.getTextContent()));
							}
						}
					}
				}
				if (currentMap != null && !currentMap.isEmpty()) {
					RouteVehicles.add(currentMap);
					busStopsDetails.add(singleRouteBusStopsDetails);
				}
			}
			return RouteVehicles;
		}
	}

	@Override
	public void onPreExecute() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onPostExecute(ArrayList<String> result) {
		// TODO Auto-generated method stub

		adapter = new ArrayAdapter<String>(getBaseContext(), android.R.layout.select_dialog_singlechoice, result);

		LocationAutoCompleteTextView.setAdapter(adapter);
		DestinationAutoCompleteTextView.setAdapter(adapter);
	}

	@Override
	public void onRoutesPreExecute() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onRoutesPostExecute(ArrayList<HashMap<String, String>> result, final ArrayList<BusStopsDetails> busStopsDetails) {
		// TODO Auto-generated method stub

		MyAdapter myAdapter = new MyAdapter(this,  result);

		RoutesSuggestionsListView.setAdapter(myAdapter);

		myAdapter.notifyDataSetChanged();

		Toast.makeText(getBaseContext(), result.size() + " results.", Toast.LENGTH_SHORT).show();

		RoutesSuggestionsListView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(getBaseContext(),DetailActivity.class);

				BusStopsDetails myBusStopsDetails = busStopsDetails.get(position);

				ArrayList<String> LocationNames = myBusStopsDetails.LocationNames;
				ArrayList<Double> LocationLatitudes = myBusStopsDetails.LocationLatitudes;
				ArrayList<Double> LocationLongitudes = myBusStopsDetails.LocationLongitudes;


				MyLog.m("myBusStopsDetails Lengths", "Names : "+myBusStopsDetails.LocationNames.size() + "Lats : "+myBusStopsDetails.LocationLatitudes.size() + "longs : "+myBusStopsDetails.LocationLongitudes.size());

				intent.putExtra("LocationNames", LocationNames);
				intent.putExtra("LocationLatitudes", LocationLatitudes);
				intent.putExtra("LocationLongitudes", LocationLongitudes);

				MyLog.m("Intent Put Extra", "Intent Put Extra");

				startActivity(intent);
			}
		});
	}
}

interface LocationsCallBack {
	public void onPreExecute();

	public void onPostExecute(ArrayList<String> result);
}

interface RoutesCallBack {
	public void onRoutesPreExecute();

	public void onRoutesPostExecute(ArrayList<HashMap<String, String>> result, ArrayList<BusStopsDetails> busStopsDetails);
}

class MyAdapter extends BaseAdapter {

	ArrayList<HashMap<String, String>> dataSource = new ArrayList<HashMap<String, String>>();
	Context context;
	LayoutInflater layoutInflater;

	public MyAdapter(Context context, ArrayList<HashMap<String, String>> dataSource) {
		this.dataSource = dataSource;
		this.context = context;
		layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}

	@Override
	public int getCount() {
		return dataSource.size();
	}

	@Override
	public Object getItem(int position) {
		return dataSource.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View row = convertView;
		MyHolder holder = null;
		if (row == null) {

			row = layoutInflater.inflate(R.layout.single_suggestion_view, parent, false);
			holder = new MyHolder(row);
			row.setTag(holder);

		} else {
			holder = (MyHolder) row.getTag();
		}
		HashMap<String, String> currentItem = dataSource.get(position);
		if (currentItem.get("VehicleType").equals("Bus")) {
			holder.VehicleIcon.setImageResource(R.drawable.iconbus48);
		} else if (currentItem.get("VehicleType").equals("Mini Bus")) {
			holder.VehicleIcon.setImageResource(R.drawable.iconminibus48);
		} else if (currentItem.get("VehicleType").equals("Rickshaw")) {
			holder.VehicleIcon.setImageResource(R.drawable.iconrickshaw48);
		} else if (currentItem.get("VehicleType").equals("Chingche")) {
			holder.VehicleIcon.setImageResource(R.drawable.iconrickshaw48);	
		} else if (currentItem.get("VehicleType").equals("Airplane")) {
			holder.VehicleIcon.setImageResource(R.drawable.iconairplane48);
		} else if (currentItem.get("VehicleType").equals("Train")) {
			holder.VehicleIcon.setImageResource(R.drawable.iconbtrain48);
		} else if (currentItem.get("VehicleType").equals("Cruise Ship")) {
			holder.VehicleIcon.setImageResource(R.drawable.iconcruiseship48);
		} else if (currentItem.get("VehicleType").equals("Motor Bike")) {
			holder.VehicleIcon.setImageResource(R.drawable.iconmotorbike48);
		} else if (currentItem.get("VehicleType").equals("Taxi")) {
			holder.VehicleIcon.setImageResource(R.drawable.icontaxi48);
		} else if (currentItem.get("VehicleType").equals("Tram")) {
			holder.VehicleIcon.setImageResource(R.drawable.icontram48);
		}
		holder.VehicleName.setText(currentItem.get("VehicleName"));
		holder.VehicleFair.setText(currentItem.get("StopFair") + " Rs.");
		holder.VehicleTime.setText("25" + " Min");
		return row;
	}
}

class MyHolder {
	ImageView VehicleIcon;
	TextView VehicleName;
	TextView VehicleFair;
	TextView VehicleTime;

	public MyHolder(View view) {
		VehicleIcon = (ImageView) view.findViewById(R.id.VehicleIcon);
		VehicleName = (TextView) view.findViewById(R.id.VehicleName);
		VehicleFair = (TextView) view.findViewById(R.id.VehicleFair);
		VehicleTime = (TextView) view.findViewById(R.id.VehicleTime);
	}
}